--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: lysobacter; Type: SCHEMA; Schema: -; Owner: lysobacter_user
--

CREATE SCHEMA lysobacter;


ALTER SCHEMA lysobacter OWNER TO lysobacter_user;

--
-- Name: bulk_import_strain_results(character varying, jsonb); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.bulk_import_strain_results(p_strain_identifier character varying, p_test_results jsonb) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_strain_id INTEGER;
    test_result JSONB;
    v_test_id INTEGER;
    v_value_id INTEGER;
BEGIN
    -- Get strain ID
    SELECT strain_id INTO v_strain_id 
    FROM lysobacter.strains 
    WHERE strain_identifier = p_strain_identifier AND is_active = TRUE;
    
    IF v_strain_id IS NULL THEN
        RAISE EXCEPTION 'Strain not found: %', p_strain_identifier;
    END IF;
    
    -- Process each test result
    FOR test_result IN SELECT jsonb_array_elements(p_test_results)
    LOOP
        -- Get test ID
        SELECT test_id INTO v_test_id
        FROM lysobacter.tests
        WHERE test_code = test_result->>'test_code' AND is_active = TRUE;
        
        IF v_test_id IS NULL THEN
            CONTINUE; -- Skip unknown tests
        END IF;
        
        -- Handle boolean results
        IF test_result->>'test_type' = 'boolean' THEN
            SELECT value_id INTO v_value_id
            FROM lysobacter.test_values
            WHERE test_id = v_test_id AND value_code = test_result->>'value';
            
            IF v_value_id IS NOT NULL THEN
                INSERT INTO lysobacter.test_results_boolean 
                (strain_id, test_id, value_id, notes, confidence_level)
                VALUES (v_strain_id, v_test_id, v_value_id, 
                       test_result->>'notes', 
                       COALESCE(test_result->>'confidence_level', 'high'))
                ON CONFLICT (strain_id, test_id) 
                DO UPDATE SET 
                    value_id = EXCLUDED.value_id,
                    notes = EXCLUDED.notes,
                    confidence_level = EXCLUDED.confidence_level,
                    updated_at = CURRENT_TIMESTAMP;
            END IF;
            
        -- Handle numeric results
        ELSIF test_result->>'test_type' = 'numeric' THEN
            INSERT INTO lysobacter.test_results_numeric 
            (strain_id, test_id, value_type, numeric_value, measurement_unit, notes, confidence_level)
            VALUES (v_strain_id, v_test_id, 
                   test_result->>'value_type',
                   (test_result->>'numeric_value')::DECIMAL,
                   test_result->>'measurement_unit',
                   test_result->>'notes', 
                   COALESCE(test_result->>'confidence_level', 'high'))
            ON CONFLICT (strain_id, test_id, value_type) 
            DO UPDATE SET 
                numeric_value = EXCLUDED.numeric_value,
                measurement_unit = EXCLUDED.measurement_unit,
                notes = EXCLUDED.notes,
                confidence_level = EXCLUDED.confidence_level,
                updated_at = CURRENT_TIMESTAMP;
                
        -- Handle text results
        ELSIF test_result->>'test_type' = 'text' THEN
            INSERT INTO lysobacter.test_results_text 
            (strain_id, test_id, text_value, notes, confidence_level)
            VALUES (v_strain_id, v_test_id, 
                   test_result->>'text_value',
                   test_result->>'notes', 
                   COALESCE(test_result->>'confidence_level', 'high'))
            ON CONFLICT (strain_id, test_id) 
            DO UPDATE SET 
                text_value = EXCLUDED.text_value,
                notes = EXCLUDED.notes,
                confidence_level = EXCLUDED.confidence_level,
                updated_at = CURRENT_TIMESTAMP;
        END IF;
    END LOOP;
    
    RETURN TRUE;
END;
$$;


ALTER FUNCTION lysobacter.bulk_import_strain_results(p_strain_identifier character varying, p_test_results jsonb) OWNER TO lysobacter_user;

--
-- Name: get_strain_test_profile(integer); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.get_strain_test_profile(p_strain_id integer) RETURNS TABLE(category_name character varying, test_name character varying, test_type character varying, result_value text, confidence_level character varying, tested_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tc.category_name,
        t.test_name,
        t.test_type,
        CASE 
            WHEN t.test_type = 'boolean' THEN tv.value_name
            WHEN t.test_type = 'numeric' THEN 
                trn.value_type || ': ' || trn.numeric_value::text || 
                COALESCE(' ' || trn.measurement_unit, '')
            WHEN t.test_type = 'text' THEN trt.text_value
        END as result_value,
        COALESCE(trb.confidence_level, trn.confidence_level, trt.confidence_level) as confidence_level,
        COALESCE(trb.tested_date, trn.tested_date, trt.tested_date) as tested_date
    FROM lysobacter.tests t
    JOIN lysobacter.test_categories tc ON t.category_id = tc.category_id
    LEFT JOIN lysobacter.test_results_boolean trb ON t.test_id = trb.test_id AND trb.strain_id = p_strain_id
    LEFT JOIN lysobacter.test_values tv ON trb.value_id = tv.value_id
    LEFT JOIN lysobacter.test_results_numeric trn ON t.test_id = trn.test_id AND trn.strain_id = p_strain_id
    LEFT JOIN lysobacter.test_results_text trt ON t.test_id = trt.test_id AND trt.strain_id = p_strain_id
    WHERE (trb.result_id IS NOT NULL OR trn.result_id IS NOT NULL OR trt.result_id IS NOT NULL)
    AND t.is_active = TRUE
    ORDER BY tc.sort_order, t.sort_order;
END;
$$;


ALTER FUNCTION lysobacter.get_strain_test_profile(p_strain_id integer) OWNER TO lysobacter_user;

--
-- Name: search_strains_with_tolerance(jsonb, integer); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.search_strains_with_tolerance(p_criteria jsonb, p_tolerance integer DEFAULT 0) RETURNS TABLE(strain_id integer, strain_identifier character varying, scientific_name character varying, match_score integer, total_criteria integer, matching_criteria integer, conflicting_criteria integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    criterion JSONB;
    test_name_key TEXT;
    expected_value TEXT;
    total_criteria_count INTEGER;
BEGIN
    -- Create temporary table for results
    CREATE TEMP TABLE temp_strain_matches (
        strain_id INTEGER,
        match_count INTEGER DEFAULT 0,
        conflict_count INTEGER DEFAULT 0
    );
    
    -- Initialize with all strains
    INSERT INTO temp_strain_matches (strain_id)
    SELECT s.strain_id FROM lysobacter.strains s WHERE s.is_active = TRUE;
    
    -- Count total criteria
    total_criteria_count := jsonb_array_length(p_criteria);
    
    -- Process each criterion
    FOR criterion IN SELECT jsonb_array_elements(p_criteria)
    LOOP
        test_name_key := criterion->>'test_name';
        expected_value := criterion->>'expected_value';
        
        -- Update matches for boolean tests
        UPDATE temp_strain_matches 
        SET match_count = match_count + 1
        WHERE strain_id IN (
            SELECT trb.strain_id
            FROM lysobacter.test_results_boolean trb
            JOIN lysobacter.tests t ON trb.test_id = t.test_id
            JOIN lysobacter.test_values tv ON trb.value_id = tv.value_id
            WHERE t.test_code = test_name_key 
            AND tv.value_code = expected_value
        );
        
        -- Update conflicts for boolean tests
        UPDATE temp_strain_matches 
        SET conflict_count = conflict_count + 1
        WHERE strain_id IN (
            SELECT trb.strain_id
            FROM lysobacter.test_results_boolean trb
            JOIN lysobacter.tests t ON trb.test_id = t.test_id
            JOIN lysobacter.test_values tv ON trb.value_id = tv.value_id
            WHERE t.test_code = test_name_key 
            AND tv.value_code != expected_value
            AND tv.value_code != 'n.d.'
        );
    END LOOP;
    
    -- Return results within tolerance
    RETURN QUERY
    SELECT 
        s.strain_id,
        s.strain_identifier,
        s.scientific_name,
        tsm.match_count as match_score,
        total_criteria_count as total_criteria,
        tsm.match_count as matching_criteria,
        tsm.conflict_count as conflicting_criteria
    FROM temp_strain_matches tsm
    JOIN lysobacter.strains s ON tsm.strain_id = s.strain_id
    WHERE tsm.conflict_count <= p_tolerance
    ORDER BY tsm.match_count DESC, tsm.conflict_count ASC;
    
    -- Clean up
    DROP TABLE temp_strain_matches;
END;
$$;


ALTER FUNCTION lysobacter.search_strains_with_tolerance(p_criteria jsonb, p_tolerance integer) OWNER TO lysobacter_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION lysobacter.update_updated_at_column() OWNER TO lysobacter_user;

--
-- Name: validate_strain_data(); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.validate_strain_data() RETURNS TABLE(validation_type character varying, strain_id integer, strain_identifier character varying, issue_description text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check for strains without any test results
    RETURN QUERY
    SELECT 
        'NO_TEST_RESULTS'::VARCHAR(50),
        s.strain_id,
        s.strain_identifier,
        'Strain has no test results recorded'::TEXT
    FROM lysobacter.strains s
    WHERE s.is_active = TRUE
    AND NOT EXISTS (
        SELECT 1 FROM lysobacter.test_results_boolean trb WHERE trb.strain_id = s.strain_id
        UNION
        SELECT 1 FROM lysobacter.test_results_numeric trn WHERE trn.strain_id = s.strain_id
        UNION
        SELECT 1 FROM lysobacter.test_results_text trt WHERE trt.strain_id = s.strain_id
    );
    
    -- Check for inconsistent numeric ranges
    RETURN QUERY
    SELECT 
        'INVALID_NUMERIC_RANGE'::VARCHAR(50),
        s.strain_id,
        s.strain_identifier,
        'Invalid numeric range: minimum > maximum for test: ' || t.test_name
    FROM lysobacter.strains s
    JOIN lysobacter.test_results_numeric trn_min ON s.strain_id = trn_min.strain_id AND trn_min.value_type = 'minimum'
    JOIN lysobacter.test_results_numeric trn_max ON s.strain_id = trn_max.strain_id AND trn_max.value_type = 'maximum'
    JOIN lysobacter.tests t ON trn_min.test_id = t.test_id AND trn_max.test_id = t.test_id
    WHERE trn_min.numeric_value > trn_max.numeric_value;
    
    -- Check for duplicate test results
    RETURN QUERY
    SELECT 
        'DUPLICATE_BOOLEAN_RESULTS'::VARCHAR(50),
        s.strain_id,
        s.strain_identifier,
        'Duplicate boolean test results for test: ' || t.test_name
    FROM lysobacter.strains s
    JOIN lysobacter.test_results_boolean trb ON s.strain_id = trb.strain_id
    JOIN lysobacter.tests t ON trb.test_id = t.test_id
    GROUP BY s.strain_id, s.strain_identifier, t.test_name, trb.test_id
    HAVING COUNT(*) > 1;
    
END;
$$;


ALTER FUNCTION lysobacter.validate_strain_data() OWNER TO lysobacter_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.audit_log (
    log_id integer NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id integer NOT NULL,
    operation character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_by character varying(100),
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.audit_log OWNER TO lysobacter_user;

--
-- Name: audit_log_log_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.audit_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.audit_log_log_id_seq OWNER TO lysobacter_user;

--
-- Name: audit_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.audit_log_log_id_seq OWNED BY lysobacter.audit_log.log_id;


--
-- Name: collection_numbers; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.collection_numbers (
    collection_number_id integer NOT NULL,
    collection_code character varying(50) NOT NULL,
    collection_number character varying(100) NOT NULL,
    collection_name character varying(200),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.collection_numbers OWNER TO lysobacter_user;

--
-- Name: collection_numbers_collection_number_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.collection_numbers_collection_number_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.collection_numbers_collection_number_id_seq OWNER TO lysobacter_user;

--
-- Name: collection_numbers_collection_number_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.collection_numbers_collection_number_id_seq OWNED BY lysobacter.collection_numbers.collection_number_id;


--
-- Name: data_sources; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.data_sources (
    source_id integer NOT NULL,
    source_name character varying(200) NOT NULL,
    source_type character varying(50),
    contact_info text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.data_sources OWNER TO lysobacter_user;

--
-- Name: data_sources_source_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.data_sources_source_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.data_sources_source_id_seq OWNER TO lysobacter_user;

--
-- Name: data_sources_source_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.data_sources_source_id_seq OWNED BY lysobacter.data_sources.source_id;


--
-- Name: strain_collections; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.strain_collections (
    strain_id integer NOT NULL,
    collection_number_id integer NOT NULL,
    is_primary boolean DEFAULT false,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.strain_collections OWNER TO lysobacter_user;

--
-- Name: strains; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.strains (
    strain_id integer NOT NULL,
    strain_identifier character varying(100) NOT NULL,
    scientific_name character varying(200),
    common_name character varying(200),
    description text,
    isolation_source text,
    isolation_location text,
    isolation_date date,
    source_id integer,
    gc_content_min numeric(5,2),
    gc_content_max numeric(5,2),
    gc_content_optimal numeric(5,2),
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.strains OWNER TO lysobacter_user;

--
-- Name: strains_strain_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.strains_strain_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.strains_strain_id_seq OWNER TO lysobacter_user;

--
-- Name: strains_strain_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.strains_strain_id_seq OWNED BY lysobacter.strains.strain_id;


--
-- Name: test_categories; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_categories (
    category_id integer NOT NULL,
    category_name character varying(100) NOT NULL,
    description text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.test_categories OWNER TO lysobacter_user;

--
-- Name: test_categories_category_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_categories_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_categories_category_id_seq OWNER TO lysobacter_user;

--
-- Name: test_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_categories_category_id_seq OWNED BY lysobacter.test_categories.category_id;


--
-- Name: test_results_boolean; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_results_boolean (
    result_id integer NOT NULL,
    strain_id integer NOT NULL,
    test_id integer NOT NULL,
    value_id integer NOT NULL,
    notes text,
    confidence_level character varying(20) DEFAULT 'high'::character varying,
    tested_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.test_results_boolean OWNER TO lysobacter_user;

--
-- Name: test_results_boolean_result_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_results_boolean_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_results_boolean_result_id_seq OWNER TO lysobacter_user;

--
-- Name: test_results_boolean_result_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_results_boolean_result_id_seq OWNED BY lysobacter.test_results_boolean.result_id;


--
-- Name: test_results_numeric; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_results_numeric (
    result_id integer NOT NULL,
    strain_id integer NOT NULL,
    test_id integer NOT NULL,
    value_type character varying(20) NOT NULL,
    numeric_value numeric(10,4) NOT NULL,
    measurement_unit character varying(20),
    notes text,
    confidence_level character varying(20) DEFAULT 'high'::character varying,
    tested_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT test_results_numeric_value_type_check CHECK (((value_type)::text = ANY ((ARRAY['minimum'::character varying, 'maximum'::character varying, 'optimal'::character varying, 'single'::character varying])::text[])))
);


ALTER TABLE lysobacter.test_results_numeric OWNER TO lysobacter_user;

--
-- Name: test_results_numeric_result_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_results_numeric_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_results_numeric_result_id_seq OWNER TO lysobacter_user;

--
-- Name: test_results_numeric_result_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_results_numeric_result_id_seq OWNED BY lysobacter.test_results_numeric.result_id;


--
-- Name: test_results_text; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_results_text (
    result_id integer NOT NULL,
    strain_id integer NOT NULL,
    test_id integer NOT NULL,
    text_value text NOT NULL,
    notes text,
    confidence_level character varying(20) DEFAULT 'high'::character varying,
    tested_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.test_results_text OWNER TO lysobacter_user;

--
-- Name: test_results_text_result_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_results_text_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_results_text_result_id_seq OWNER TO lysobacter_user;

--
-- Name: test_results_text_result_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_results_text_result_id_seq OWNED BY lysobacter.test_results_text.result_id;


--
-- Name: test_values; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_values (
    value_id integer NOT NULL,
    test_id integer NOT NULL,
    value_code character varying(10) NOT NULL,
    value_name character varying(50) NOT NULL,
    description text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.test_values OWNER TO lysobacter_user;

--
-- Name: test_values_value_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_values_value_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_values_value_id_seq OWNER TO lysobacter_user;

--
-- Name: test_values_value_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_values_value_id_seq OWNED BY lysobacter.test_values.value_id;


--
-- Name: tests; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.tests (
    test_id integer NOT NULL,
    category_id integer NOT NULL,
    test_name character varying(150) NOT NULL,
    test_code character varying(50),
    test_type character varying(20) NOT NULL,
    description text,
    measurement_unit character varying(20),
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tests_test_type_check CHECK (((test_type)::text = ANY ((ARRAY['boolean'::character varying, 'numeric'::character varying, 'text'::character varying])::text[])))
);


ALTER TABLE lysobacter.tests OWNER TO lysobacter_user;

--
-- Name: tests_test_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.tests_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.tests_test_id_seq OWNER TO lysobacter_user;

--
-- Name: tests_test_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.tests_test_id_seq OWNED BY lysobacter.tests.test_id;


--
-- Name: v_category_statistics; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_category_statistics AS
SELECT
    NULL::character varying(100) AS category_name,
    NULL::text AS description,
    NULL::bigint AS total_tests,
    NULL::bigint AS active_tests,
    NULL::bigint AS strains_with_data;


ALTER TABLE lysobacter.v_category_statistics OWNER TO lysobacter_user;

--
-- Name: v_strain_completeness; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_strain_completeness AS
 SELECT s.strain_id,
    s.strain_identifier,
    s.scientific_name,
    count(DISTINCT t.test_id) AS total_available_tests,
    count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.test_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.test_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.test_id
            ELSE NULL::integer
        END) AS completed_tests,
    round((((count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.test_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.test_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.test_id
            ELSE NULL::integer
        END))::numeric * 100.0) / (NULLIF(count(DISTINCT t.test_id), 0))::numeric), 2) AS completeness_percentage
   FROM ((((lysobacter.strains s
     CROSS JOIN lysobacter.tests t)
     LEFT JOIN lysobacter.test_results_boolean trb ON (((s.strain_id = trb.strain_id) AND (t.test_id = trb.test_id))))
     LEFT JOIN lysobacter.test_results_numeric trn ON (((s.strain_id = trn.strain_id) AND (t.test_id = trn.test_id))))
     LEFT JOIN lysobacter.test_results_text trt ON (((s.strain_id = trt.strain_id) AND (t.test_id = trt.test_id))))
  WHERE ((s.is_active = true) AND (t.is_active = true))
  GROUP BY s.strain_id, s.strain_identifier, s.scientific_name
  ORDER BY (round((((count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.test_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.test_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.test_id
            ELSE NULL::integer
        END))::numeric * 100.0) / (NULLIF(count(DISTINCT t.test_id), 0))::numeric), 2)) DESC;


ALTER TABLE lysobacter.v_strain_completeness OWNER TO lysobacter_user;

--
-- Name: v_strains_complete; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_strains_complete AS
SELECT
    NULL::integer AS strain_id,
    NULL::character varying(100) AS strain_identifier,
    NULL::character varying(200) AS scientific_name,
    NULL::character varying(200) AS common_name,
    NULL::text AS description,
    NULL::text AS isolation_source,
    NULL::text AS isolation_location,
    NULL::date AS isolation_date,
    NULL::character varying(200) AS source_name,
    NULL::character varying(50) AS source_type,
    NULL::numeric(5,2) AS gc_content_min,
    NULL::numeric(5,2) AS gc_content_max,
    NULL::numeric(5,2) AS gc_content_optimal,
    NULL::text AS notes,
    NULL::boolean AS is_active,
    NULL::timestamp without time zone AS created_at,
    NULL::timestamp without time zone AS updated_at,
    NULL::text[] AS collection_numbers;


ALTER TABLE lysobacter.v_strains_complete OWNER TO lysobacter_user;

--
-- Name: v_test_completion; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_test_completion AS
 SELECT t.test_id,
    t.test_name,
    t.test_type,
    tc.category_name,
    count(DISTINCT s.strain_id) AS total_strains,
    count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.strain_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.strain_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.strain_id
            ELSE NULL::integer
        END) AS tested_strains,
    round((((count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.strain_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.strain_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.strain_id
            ELSE NULL::integer
        END))::numeric * 100.0) / (NULLIF(count(DISTINCT s.strain_id), 0))::numeric), 2) AS completion_percentage
   FROM (((((lysobacter.tests t
     JOIN lysobacter.test_categories tc ON ((t.category_id = tc.category_id)))
     CROSS JOIN lysobacter.strains s)
     LEFT JOIN lysobacter.test_results_boolean trb ON (((t.test_id = trb.test_id) AND (s.strain_id = trb.strain_id))))
     LEFT JOIN lysobacter.test_results_numeric trn ON (((t.test_id = trn.test_id) AND (s.strain_id = trn.strain_id))))
     LEFT JOIN lysobacter.test_results_text trt ON (((t.test_id = trt.test_id) AND (s.strain_id = trt.strain_id))))
  WHERE ((t.is_active = true) AND (s.is_active = true))
  GROUP BY t.test_id, t.test_name, t.test_type, tc.category_name
  ORDER BY tc.category_name, t.test_name;


ALTER TABLE lysobacter.v_test_completion OWNER TO lysobacter_user;

--
-- Name: v_test_results_summary; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_test_results_summary AS
 SELECT s.strain_id,
    s.strain_identifier,
    tc.category_name,
    t.test_name,
    t.test_type,
    t.measurement_unit,
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN tv.value_name
            ELSE NULL::character varying
        END AS boolean_result,
        CASE
            WHEN ((t.test_type)::text = 'numeric'::text) THEN
            CASE trn.value_type
                WHEN 'minimum'::text THEN ('Min: '::text || (trn.numeric_value)::text)
                WHEN 'maximum'::text THEN ('Max: '::text || (trn.numeric_value)::text)
                WHEN 'optimal'::text THEN ('Opt: '::text || (trn.numeric_value)::text)
                ELSE (trn.numeric_value)::text
            END
            ELSE NULL::text
        END AS numeric_result,
        CASE
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.text_value
            ELSE NULL::text
        END AS text_result,
    COALESCE(trb.confidence_level, trn.confidence_level, trt.confidence_level) AS confidence_level,
    COALESCE(trb.tested_date, trn.tested_date, trt.tested_date) AS tested_date
   FROM ((((((lysobacter.strains s
     CROSS JOIN lysobacter.tests t)
     JOIN lysobacter.test_categories tc ON ((t.category_id = tc.category_id)))
     LEFT JOIN lysobacter.test_results_boolean trb ON (((s.strain_id = trb.strain_id) AND (t.test_id = trb.test_id))))
     LEFT JOIN lysobacter.test_values tv ON ((trb.value_id = tv.value_id)))
     LEFT JOIN lysobacter.test_results_numeric trn ON (((s.strain_id = trn.strain_id) AND (t.test_id = trn.test_id))))
     LEFT JOIN lysobacter.test_results_text trt ON (((s.strain_id = trt.strain_id) AND (t.test_id = trt.test_id))))
  WHERE ((s.is_active = true) AND (t.is_active = true) AND ((trb.result_id IS NOT NULL) OR (trn.result_id IS NOT NULL) OR (trt.result_id IS NOT NULL)));


ALTER TABLE lysobacter.v_test_results_summary OWNER TO lysobacter_user;

--
-- Name: audit_log log_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.audit_log ALTER COLUMN log_id SET DEFAULT nextval('lysobacter.audit_log_log_id_seq'::regclass);


--
-- Name: collection_numbers collection_number_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.collection_numbers ALTER COLUMN collection_number_id SET DEFAULT nextval('lysobacter.collection_numbers_collection_number_id_seq'::regclass);


--
-- Name: data_sources source_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.data_sources ALTER COLUMN source_id SET DEFAULT nextval('lysobacter.data_sources_source_id_seq'::regclass);


--
-- Name: strains strain_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains ALTER COLUMN strain_id SET DEFAULT nextval('lysobacter.strains_strain_id_seq'::regclass);


--
-- Name: test_categories category_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_categories ALTER COLUMN category_id SET DEFAULT nextval('lysobacter.test_categories_category_id_seq'::regclass);


--
-- Name: test_results_boolean result_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean ALTER COLUMN result_id SET DEFAULT nextval('lysobacter.test_results_boolean_result_id_seq'::regclass);


--
-- Name: test_results_numeric result_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric ALTER COLUMN result_id SET DEFAULT nextval('lysobacter.test_results_numeric_result_id_seq'::regclass);


--
-- Name: test_results_text result_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text ALTER COLUMN result_id SET DEFAULT nextval('lysobacter.test_results_text_result_id_seq'::regclass);


--
-- Name: test_values value_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_values ALTER COLUMN value_id SET DEFAULT nextval('lysobacter.test_values_value_id_seq'::regclass);


--
-- Name: tests test_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests ALTER COLUMN test_id SET DEFAULT nextval('lysobacter.tests_test_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.audit_log (log_id, table_name, record_id, operation, old_values, new_values, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: collection_numbers; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.collection_numbers (collection_number_id, collection_code, collection_number, collection_name, notes, created_at) FROM stdin;
1	DSM	EXAMPLE-001	Deutsche Sammlung von Mikroorganismen	Example collection number	2025-06-25 02:09:22.04018
2	ATCC	EXAMPLE-001	American Type Culture Collection	Example collection number	2025-06-25 02:09:22.04018
3	CCUG	EXAMPLE-001	Culture Collection University of Gothenburg	Example collection number	2025-06-25 02:09:22.04018
\.


--
-- Data for Name: data_sources; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.data_sources (source_id, source_name, source_type, contact_info, notes, created_at) FROM stdin;
1	Laboratory Research Data	laboratory	Internal laboratory testing	Primary research data from laboratory experiments	2025-06-25 02:09:22.038451
2	Literature Review	publication	Various scientific publications	Data collected from published research papers	2025-06-25 02:09:22.038451
3	Culture Collection Database	database	International culture collections	Data from established culture collection databases	2025-06-25 02:09:22.038451
4	Laboratory Research Data	laboratory	Internal laboratory testing	Primary research data from laboratory experiments	2025-06-25 02:09:49.84759
5	Literature Review	publication	Various scientific publications	Data collected from published research papers	2025-06-25 02:09:49.84759
6	Culture Collection Database	database	International culture collections	Data from established culture collection databases	2025-06-25 02:09:49.84759
\.


--
-- Data for Name: strain_collections; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.strain_collections (strain_id, collection_number_id, is_primary, notes, created_at) FROM stdin;
1	1	t	Primary collection deposit	2025-06-25 02:09:22.121578
2	2	f	Secondary collection deposit	2025-06-25 02:09:22.121578
\.


--
-- Data for Name: strains; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.strains (strain_id, strain_identifier, scientific_name, common_name, description, isolation_source, isolation_location, isolation_date, source_id, gc_content_min, gc_content_max, gc_content_optimal, notes, is_active, created_at, updated_at) FROM stdin;
1	LYS-001	Lysobacter antibioticus	Antibiotic-producing lysobacter	Strain isolated from agricultural soil with strong antibiotic activity	Agricultural soil	Moscow region, Russia	2023-01-15	1	\N	\N	\N	Primary research strain for antibiotic studies	t	2025-06-25 02:09:22.115922	2025-06-25 02:09:22.115922
2	LYS-002	Lysobacter enzymogenes	Enzyme-producing lysobacter	Strain with high enzymatic activity, particularly cellulase production	Forest soil	Leningrad region, Russia	2023-02-20	1	\N	\N	\N	High cellulase activity observed	t	2025-06-25 02:09:22.115922	2025-06-25 02:09:22.115922
3	LYS-003	Lysobacter brunescens	Brown-pigmented lysobacter	Strain characterized by brown pigment production	Lake sediment	Baikal region, Russia	2023-03-10	2	\N	\N	\N	Notable for brown pigmentation	t	2025-06-25 02:09:22.115922	2025-06-25 02:09:22.115922
\.


--
-- Data for Name: test_categories; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_categories (category_id, category_name, description, sort_order, created_at) FROM stdin;
1	morphological	Morphological Properties	1	2025-06-25 02:09:22.009949
2	physiological	Physiological Properties	2	2025-06-25 02:09:22.009949
3	biochemical_enzymes	Biochemical Properties - Enzymes	3	2025-06-25 02:09:22.009949
4	biochemical_breakdown	Biochemical Properties - Sugar and Polysaccharide Breakdown	4	2025-06-25 02:09:22.009949
5	biochemical_utilization	Biochemical Properties - Sugar Utilization	5	2025-06-25 02:09:22.009949
6	biochemical_other	Other Biochemical Characteristics	6	2025-06-25 02:09:22.009949
\.


--
-- Data for Name: test_results_boolean; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_results_boolean (result_id, strain_id, test_id, value_id, notes, confidence_level, tested_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_results_numeric; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_results_numeric (result_id, strain_id, test_id, value_type, numeric_value, measurement_unit, notes, confidence_level, tested_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_results_text; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_results_text (result_id, strain_id, test_id, text_value, notes, confidence_level, tested_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_values; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_values (value_id, test_id, value_code, value_name, description, sort_order, created_at) FROM stdin;
1	1	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
2	1	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
3	1	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
4	1	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
5	2	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
6	2	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
7	2	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
8	2	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
9	3	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
10	3	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
11	3	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
12	3	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
13	4	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
14	4	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
15	4	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
16	4	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
17	5	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
18	5	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
19	5	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
20	5	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
21	6	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
22	6	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
23	6	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
24	6	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
25	7	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
26	7	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
27	7	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
28	7	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
29	8	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
30	8	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
31	8	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
32	8	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
33	9	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
34	9	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
35	9	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
36	9	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
37	10	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
38	10	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
39	10	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
40	10	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
41	11	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
42	11	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
43	11	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
44	11	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
45	12	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
46	12	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
47	12	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
48	12	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
49	13	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
50	13	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
51	13	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
52	13	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
53	14	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
54	14	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
55	14	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
56	14	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
57	15	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
58	15	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
59	15	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
60	15	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
61	16	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
62	16	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
63	16	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
64	16	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
65	17	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
66	17	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
67	17	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
68	17	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
69	18	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
70	18	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
71	18	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
72	18	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
73	19	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
74	19	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
75	19	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
76	19	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
77	20	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
78	20	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
79	20	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
80	20	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
81	21	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
82	21	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
83	21	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
84	21	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
85	22	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
86	22	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
87	22	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
88	22	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
89	23	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
90	23	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
91	23	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
92	23	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
93	24	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
94	24	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
95	24	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
96	24	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
97	25	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
98	25	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
99	25	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
100	25	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
101	26	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
102	26	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
103	26	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
104	26	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
105	27	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
106	27	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
107	27	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
108	27	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
109	28	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
110	28	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
111	28	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
112	28	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
113	29	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
114	29	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
115	29	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
116	29	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
117	30	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
118	30	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
119	30	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
120	30	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
121	31	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
122	31	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
123	31	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
124	31	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
125	32	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
126	32	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
127	32	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
128	32	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
129	33	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
130	33	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
131	33	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
132	33	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
133	34	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
134	34	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
135	34	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
136	34	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
137	35	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
138	35	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
139	35	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
140	35	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
141	36	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
142	36	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
143	36	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
144	36	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
145	37	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
146	37	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
147	37	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
148	37	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
149	38	+	Positive	Positive result	1	2025-06-25 02:09:22.029693
150	38	-	Negative	Negative result	2	2025-06-25 02:09:22.029693
151	38	+/-	Intermediate	Intermediate/Variable result	3	2025-06-25 02:09:22.029693
152	38	n.d.	No Data	No data available	4	2025-06-25 02:09:22.029693
\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.tests (test_id, category_id, test_name, test_code, test_type, description, measurement_unit, is_active, sort_order, created_at) FROM stdin;
1	1	Spore Formation	spore_formation	boolean	Presence of spores, ability to form spores	\N	t	1	2025-06-25 02:09:22.012471
2	1	Motility	motility	boolean	Motility of the organism	\N	t	2	2025-06-25 02:09:22.012471
3	3	Proteolytic Activity	proteolytic_activity	boolean	Presence of proteolytic enzymes (ability to break down protein components)	\N	t	1	2025-06-25 02:09:22.017836
4	3	Oxidase	oxidase	boolean	Oxidase enzyme activity	\N	t	2	2025-06-25 02:09:22.017836
5	3	Catalase	catalase	boolean	Catalase enzyme activity	\N	t	3	2025-06-25 02:09:22.017836
6	3	Urease	urease	boolean	Urease enzyme activity	\N	t	4	2025-06-25 02:09:22.017836
7	3	Nitrate Reduction	nitrate_reduction	boolean	Nitrate reduction capability	\N	t	5	2025-06-25 02:09:22.017836
8	3	Indole Production	indole_production	boolean	Indole production	\N	t	6	2025-06-25 02:09:22.017836
9	3	Phosphatase	phosphatase	boolean	Phosphatase enzyme activity	\N	t	7	2025-06-25 02:09:22.017836
10	3	Esterase	esterase	boolean	Esterase enzyme activity	\N	t	8	2025-06-25 02:09:22.017836
11	4	Starch Breakdown	starch	boolean	Ability to break down starch	\N	t	1	2025-06-25 02:09:22.021058
12	4	Aesculin Breakdown	aesculin	boolean	Ability to break down aesculin	\N	t	2	2025-06-25 02:09:22.021058
13	4	Gelatin Breakdown	gelatin	boolean	Ability to break down gelatin	\N	t	3	2025-06-25 02:09:22.021058
14	4	Casein Breakdown	casein	boolean	Ability to break down casein	\N	t	4	2025-06-25 02:09:22.021058
15	4	Tween 20 Breakdown	tween_20	boolean	Ability to break down Tween 20	\N	t	5	2025-06-25 02:09:22.021058
16	4	Tween 40 Breakdown	tween_40	boolean	Ability to break down Tween 40	\N	t	6	2025-06-25 02:09:22.021058
17	4	Tween 60 Breakdown	tween_60	boolean	Ability to break down Tween 60	\N	t	7	2025-06-25 02:09:22.021058
18	4	Chitin Breakdown	chitin	boolean	Ability to break down chitin	\N	t	8	2025-06-25 02:09:22.021058
19	4	Cellulose Breakdown	cellulose	boolean	Ability to break down cellulose	\N	t	9	2025-06-25 02:09:22.021058
20	4	Arginine Hydrolase	arginine_hydrolase	boolean	Arginine hydrolase activity	\N	t	10	2025-06-25 02:09:22.021058
21	4	Pectin Breakdown	pectin	boolean	Ability to break down pectin	\N	t	11	2025-06-25 02:09:22.021058
22	4	Glucose Fermentation	glucose_fermentation	boolean	Glucose fermentation capability	\N	t	12	2025-06-25 02:09:22.021058
23	5	Maltose Utilization	maltose	boolean	Ability to utilize maltose	\N	t	1	2025-06-25 02:09:22.02517
24	5	Lactose Utilization	lactose	boolean	Ability to utilize lactose	\N	t	2	2025-06-25 02:09:22.02517
25	5	Fructose Utilization	fructose	boolean	Ability to utilize fructose	\N	t	3	2025-06-25 02:09:22.02517
26	5	Arabinose Utilization	arabinose	boolean	Ability to utilize arabinose	\N	t	4	2025-06-25 02:09:22.02517
27	5	Mannose Utilization	mannose	boolean	Ability to utilize mannose	\N	t	5	2025-06-25 02:09:22.02517
28	5	Trehalose Utilization	trehalose	boolean	Ability to utilize trehalose	\N	t	6	2025-06-25 02:09:22.02517
29	5	Sorbitol Utilization	sorbitol	boolean	Ability to utilize sorbitol	\N	t	7	2025-06-25 02:09:22.02517
30	5	Mannitol Utilization	mannitol	boolean	Ability to utilize mannitol	\N	t	8	2025-06-25 02:09:22.02517
31	5	Dextrose Utilization	dextrose	boolean	Ability to utilize dextrose	\N	t	9	2025-06-25 02:09:22.02517
32	5	Xylose Utilization	xylose	boolean	Ability to utilize xylose	\N	t	10	2025-06-25 02:09:22.02517
33	5	Galactose Utilization	galactose	boolean	Ability to utilize galactose	\N	t	11	2025-06-25 02:09:22.02517
34	5	Dulcitol Utilization	dulcitol	boolean	Ability to utilize dulcitol	\N	t	12	2025-06-25 02:09:22.02517
35	5	Cellobiose Utilization	cellobiose	boolean	Ability to utilize cellobiose	\N	t	13	2025-06-25 02:09:22.02517
36	5	Sucrose Utilization	sucrose	boolean	Ability to utilize sucrose	\N	t	14	2025-06-25 02:09:22.02517
37	5	Raffinose Utilization	raffinose	boolean	Ability to utilize raffinose	\N	t	15	2025-06-25 02:09:22.02517
38	5	Inositol Utilization	inositol	boolean	Ability to utilize inositol	\N	t	16	2025-06-25 02:09:22.02517
\.


--
-- Name: audit_log_log_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.audit_log_log_id_seq', 1, false);


--
-- Name: collection_numbers_collection_number_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.collection_numbers_collection_number_id_seq', 4, true);


--
-- Name: data_sources_source_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.data_sources_source_id_seq', 6, true);


--
-- Name: strains_strain_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.strains_strain_id_seq', 3, true);


--
-- Name: test_categories_category_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_categories_category_id_seq', 7, true);


--
-- Name: test_results_boolean_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_boolean_result_id_seq', 6, true);


--
-- Name: test_results_numeric_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_numeric_result_id_seq', 2, true);


--
-- Name: test_results_text_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_text_result_id_seq', 2, true);


--
-- Name: test_values_value_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_values_value_id_seq', 153, true);


--
-- Name: tests_test_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.tests_test_id_seq', 42, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (log_id);


--
-- Name: collection_numbers collection_numbers_collection_code_collection_number_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.collection_numbers
    ADD CONSTRAINT collection_numbers_collection_code_collection_number_key UNIQUE (collection_code, collection_number);


--
-- Name: collection_numbers collection_numbers_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.collection_numbers
    ADD CONSTRAINT collection_numbers_pkey PRIMARY KEY (collection_number_id);


--
-- Name: data_sources data_sources_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.data_sources
    ADD CONSTRAINT data_sources_pkey PRIMARY KEY (source_id);


--
-- Name: strain_collections strain_collections_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strain_collections
    ADD CONSTRAINT strain_collections_pkey PRIMARY KEY (strain_id, collection_number_id);


--
-- Name: strains strains_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains
    ADD CONSTRAINT strains_pkey PRIMARY KEY (strain_id);


--
-- Name: strains strains_strain_identifier_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains
    ADD CONSTRAINT strains_strain_identifier_key UNIQUE (strain_identifier);


--
-- Name: test_categories test_categories_category_name_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_categories
    ADD CONSTRAINT test_categories_category_name_key UNIQUE (category_name);


--
-- Name: test_categories test_categories_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_categories
    ADD CONSTRAINT test_categories_pkey PRIMARY KEY (category_id);


--
-- Name: test_results_boolean test_results_boolean_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_pkey PRIMARY KEY (result_id);


--
-- Name: test_results_boolean test_results_boolean_strain_id_test_id_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_strain_id_test_id_key UNIQUE (strain_id, test_id);


--
-- Name: test_results_numeric test_results_numeric_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric
    ADD CONSTRAINT test_results_numeric_pkey PRIMARY KEY (result_id);


--
-- Name: test_results_numeric test_results_numeric_strain_id_test_id_value_type_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric
    ADD CONSTRAINT test_results_numeric_strain_id_test_id_value_type_key UNIQUE (strain_id, test_id, value_type);


--
-- Name: test_results_text test_results_text_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text
    ADD CONSTRAINT test_results_text_pkey PRIMARY KEY (result_id);


--
-- Name: test_results_text test_results_text_strain_id_test_id_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text
    ADD CONSTRAINT test_results_text_strain_id_test_id_key UNIQUE (strain_id, test_id);


--
-- Name: test_values test_values_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_values
    ADD CONSTRAINT test_values_pkey PRIMARY KEY (value_id);


--
-- Name: test_values test_values_test_id_value_code_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_values
    ADD CONSTRAINT test_values_test_id_value_code_key UNIQUE (test_id, value_code);


--
-- Name: tests tests_category_id_test_name_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests
    ADD CONSTRAINT tests_category_id_test_name_key UNIQUE (category_id, test_name);


--
-- Name: tests tests_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (test_id);


--
-- Name: tests tests_test_code_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests
    ADD CONSTRAINT tests_test_code_key UNIQUE (test_code);


--
-- Name: idx_results_boolean_strain; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_boolean_strain ON lysobacter.test_results_boolean USING btree (strain_id);


--
-- Name: idx_results_boolean_test; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_boolean_test ON lysobacter.test_results_boolean USING btree (test_id);


--
-- Name: idx_results_numeric_strain; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_numeric_strain ON lysobacter.test_results_numeric USING btree (strain_id);


--
-- Name: idx_results_numeric_test; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_numeric_test ON lysobacter.test_results_numeric USING btree (test_id);


--
-- Name: idx_results_text_strain; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_text_strain ON lysobacter.test_results_text USING btree (strain_id);


--
-- Name: idx_strains_active; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_active ON lysobacter.strains USING btree (is_active);


--
-- Name: idx_strains_identifier; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_identifier ON lysobacter.strains USING btree (strain_identifier);


--
-- Name: idx_strains_source; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_source ON lysobacter.strains USING btree (source_id);


--
-- Name: idx_strains_text_search; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_text_search ON lysobacter.strains USING gin (to_tsvector('english'::regconfig, (((((COALESCE(strain_identifier, ''::character varying))::text || ' '::text) || (COALESCE(scientific_name, ''::character varying))::text) || ' '::text) || COALESCE(description, ''::text))));


--
-- Name: idx_tests_active; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_tests_active ON lysobacter.tests USING btree (is_active);


--
-- Name: idx_tests_category; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_tests_category ON lysobacter.tests USING btree (category_id);


--
-- Name: idx_tests_type; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_tests_type ON lysobacter.tests USING btree (test_type);


--
-- Name: v_strains_complete _RETURN; Type: RULE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE OR REPLACE VIEW lysobacter.v_strains_complete AS
 SELECT s.strain_id,
    s.strain_identifier,
    s.scientific_name,
    s.common_name,
    s.description,
    s.isolation_source,
    s.isolation_location,
    s.isolation_date,
    ds.source_name,
    ds.source_type,
    s.gc_content_min,
    s.gc_content_max,
    s.gc_content_optimal,
    s.notes,
    s.is_active,
    s.created_at,
    s.updated_at,
    array_agg(
        CASE
            WHEN (cn.collection_code IS NOT NULL) THEN (((cn.collection_code)::text || ' '::text) || (cn.collection_number)::text)
            ELSE NULL::text
        END) FILTER (WHERE (cn.collection_code IS NOT NULL)) AS collection_numbers
   FROM (((lysobacter.strains s
     LEFT JOIN lysobacter.data_sources ds ON ((s.source_id = ds.source_id)))
     LEFT JOIN lysobacter.strain_collections sc ON ((s.strain_id = sc.strain_id)))
     LEFT JOIN lysobacter.collection_numbers cn ON ((sc.collection_number_id = cn.collection_number_id)))
  GROUP BY s.strain_id, ds.source_name, ds.source_type;


--
-- Name: v_category_statistics _RETURN; Type: RULE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE OR REPLACE VIEW lysobacter.v_category_statistics AS
 SELECT tc.category_name,
    tc.description,
    count(t.test_id) AS total_tests,
    count(
        CASE
            WHEN (t.is_active = true) THEN 1
            ELSE NULL::integer
        END) AS active_tests,
    ((count(DISTINCT trb.strain_id) + count(DISTINCT trn.strain_id)) + count(DISTINCT trt.strain_id)) AS strains_with_data
   FROM ((((lysobacter.test_categories tc
     LEFT JOIN lysobacter.tests t ON ((tc.category_id = t.category_id)))
     LEFT JOIN lysobacter.test_results_boolean trb ON ((t.test_id = trb.test_id)))
     LEFT JOIN lysobacter.test_results_numeric trn ON ((t.test_id = trn.test_id)))
     LEFT JOIN lysobacter.test_results_text trt ON ((t.test_id = trt.test_id)))
  GROUP BY tc.category_id, tc.category_name, tc.description
  ORDER BY tc.sort_order;


--
-- Name: test_results_boolean update_results_boolean_updated_at; Type: TRIGGER; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TRIGGER update_results_boolean_updated_at BEFORE UPDATE ON lysobacter.test_results_boolean FOR EACH ROW EXECUTE FUNCTION lysobacter.update_updated_at_column();


--
-- Name: test_results_numeric update_results_numeric_updated_at; Type: TRIGGER; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TRIGGER update_results_numeric_updated_at BEFORE UPDATE ON lysobacter.test_results_numeric FOR EACH ROW EXECUTE FUNCTION lysobacter.update_updated_at_column();


--
-- Name: strains update_strains_updated_at; Type: TRIGGER; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TRIGGER update_strains_updated_at BEFORE UPDATE ON lysobacter.strains FOR EACH ROW EXECUTE FUNCTION lysobacter.update_updated_at_column();


--
-- Name: strain_collections strain_collections_collection_number_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strain_collections
    ADD CONSTRAINT strain_collections_collection_number_id_fkey FOREIGN KEY (collection_number_id) REFERENCES lysobacter.collection_numbers(collection_number_id);


--
-- Name: strain_collections strain_collections_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strain_collections
    ADD CONSTRAINT strain_collections_strain_id_fkey FOREIGN KEY (strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE CASCADE;


--
-- Name: strains strains_source_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains
    ADD CONSTRAINT strains_source_id_fkey FOREIGN KEY (source_id) REFERENCES lysobacter.data_sources(source_id);


--
-- Name: test_results_boolean test_results_boolean_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_strain_id_fkey FOREIGN KEY (strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE CASCADE;


--
-- Name: test_results_boolean test_results_boolean_test_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_test_id_fkey FOREIGN KEY (test_id) REFERENCES lysobacter.tests(test_id);


--
-- Name: test_results_boolean test_results_boolean_value_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_value_id_fkey FOREIGN KEY (value_id) REFERENCES lysobacter.test_values(value_id);


--
-- Name: test_results_numeric test_results_numeric_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric
    ADD CONSTRAINT test_results_numeric_strain_id_fkey FOREIGN KEY (strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE CASCADE;


--
-- Name: test_results_numeric test_results_numeric_test_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric
    ADD CONSTRAINT test_results_numeric_test_id_fkey FOREIGN KEY (test_id) REFERENCES lysobacter.tests(test_id);


--
-- Name: test_results_text test_results_text_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text
    ADD CONSTRAINT test_results_text_strain_id_fkey FOREIGN KEY (strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE CASCADE;


--
-- Name: test_results_text test_results_text_test_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text
    ADD CONSTRAINT test_results_text_test_id_fkey FOREIGN KEY (test_id) REFERENCES lysobacter.tests(test_id);


--
-- Name: test_values test_values_test_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_values
    ADD CONSTRAINT test_values_test_id_fkey FOREIGN KEY (test_id) REFERENCES lysobacter.tests(test_id) ON DELETE CASCADE;


--
-- Name: tests tests_category_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests
    ADD CONSTRAINT tests_category_id_fkey FOREIGN KEY (category_id) REFERENCES lysobacter.test_categories(category_id);


--
-- PostgreSQL database dump complete
--

