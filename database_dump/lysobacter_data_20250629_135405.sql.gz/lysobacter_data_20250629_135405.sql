--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--



--
-- Data for Name: collection_numbers; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.collection_numbers VALUES (5, 'ATCC', '29479', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (6, 'ATCC', '29480', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (7, 'ATCC', '29481', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (8, 'UASM', '4045', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (9, 'ATCC', '29483', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (10, 'UASM', '2', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (11, 'JCM', '19212T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (12, 'KACC', '17502T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (13, 'ATCC', '29489', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (14, 'ATCC', '29489T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (15, 'DSM', '6980T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (16, 'KACC', '11386T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (17, 'KCTC', '12132T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (18, 'LMG', '8763T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (19, 'UASM', '402', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (20, 'ATCC', '29482', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (21, 'ATCC', '29482T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (22, 'ATCC', '29484', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (23, 'UASM', '6', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (24, 'DSM', '19286T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (25, 'KCTC', '12891T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (26, 'ATCC', '29487T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (27, 'BCRC', '11654T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (28, 'DSM', '2043T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (29, 'KACC', '10127T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (30, 'KCTC', '12131T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (31, 'LMG', '8762T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (32, 'KACC', '18720', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (33, 'KCTC', '12600', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (34, 'KCTC', '12600T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (35, 'DSM', '18482T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (36, 'KACC', '11407T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (37, 'DSM', '17958T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (38, 'KCTC', '12822T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (39, 'KACC', '18711T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (40, 'NBRC', '111306T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (41, 'ATCC', '27796', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (42, 'DSM', '16239T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (43, 'KCTC', '12205T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (44, 'KACC', '15381T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (45, 'KACC', '22011T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (46, 'KCTC', '22011T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (47, 'JCM', '32178T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (48, 'KACC', '18656T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (49, 'ATCC', '29488', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (50, 'DSM', '17633T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (51, 'KCTC', '12204T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (52, 'KCTC', '42381T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (53, 'NBRC', '110750T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (54, 'DSM', '18244T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (55, 'DSM', '18481T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (56, 'KACC', '11587T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (57, 'KACC', '11588T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (58, 'KACC', '22750T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (59, 'LMG', '24310T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (60, 'KACC', '21942T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (61, 'KACC', '14553T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (62, 'KCTC', '22249T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (63, 'CECT', '9427T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (64, 'LMG', '30077T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (65, 'JCM', '18933T', NULL, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.collection_numbers VALUES (66, 'KACC', '16548T', NULL, NULL, '2025-06-29 10:43:37.618007');


--
-- Data for Name: data_sources; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.data_sources VALUES (1, 'Laboratory Research Data', 'laboratory', 'Internal laboratory testing', 'Primary research data from laboratory experiments', '2025-06-26 01:18:03.859223');
INSERT INTO lysobacter.data_sources VALUES (2, 'Literature Review', 'publication', 'Various scientific publications', 'Data collected from published research papers', '2025-06-26 01:18:03.859223');
INSERT INTO lysobacter.data_sources VALUES (3, 'Culture Collection Database', 'database', 'International culture collections', 'Data from established culture collection databases', '2025-06-26 01:18:03.859223');


--
-- Data for Name: species; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.species VALUES (1, 'Lysobacter yangpyeongensis', NULL, NULL, '2025-06-26 01:55:33.94069', '2025-06-26 01:55:33.94069');
INSERT INTO lysobacter.species VALUES (2, 'Lysobacter antrifimi', NULL, NULL, '2025-06-26 01:55:33.94069', '2025-06-26 01:55:33.94069');
INSERT INTO lysobacter.species VALUES (3, 'Lysobacter alkalisoli', NULL, NULL, '2025-06-26 01:55:33.94069', '2025-06-26 01:55:33.94069');
INSERT INTO lysobacter.species VALUES (4, 'Lysobacter agilis', NULL, NULL, '2025-06-26 01:55:33.94069', '2025-06-26 01:55:33.94069');
INSERT INTO lysobacter.species VALUES (5, 'Lysobacter aestuarii', NULL, NULL, '2025-06-26 01:55:33.94069', '2025-06-26 01:55:33.94069');
INSERT INTO lysobacter.species VALUES (6, 'Lysobacter antibioticus', NULL, NULL, '2025-06-26 02:05:40.181', '2025-06-26 02:05:40.181');
INSERT INTO lysobacter.species VALUES (7, 'Lysobacter arenosi', NULL, NULL, '2025-06-26 02:45:09.04858', '2025-06-26 02:45:09.04858');
INSERT INTO lysobacter.species VALUES (8, 'Lysobacter arseniciresistens', NULL, NULL, '2025-06-26 02:51:18.044327', '2025-06-26 02:51:18.044327');
INSERT INTO lysobacter.species VALUES (9, 'Lysobacter brunescens', NULL, NULL, '2025-06-26 02:56:46.609219', '2025-06-26 02:56:46.609219');
INSERT INTO lysobacter.species VALUES (10, 'Lysobacter bugurensis', NULL, NULL, '2025-06-26 06:08:48.097892', '2025-06-26 06:08:48.097892');
INSERT INTO lysobacter.species VALUES (11, 'Lysobacter caeni', NULL, NULL, '2025-06-26 06:11:46.884141', '2025-06-26 06:11:46.884141');
INSERT INTO lysobacter.species VALUES (12, 'Lysobacter capsici', NULL, NULL, '2025-06-26 06:20:20.109378', '2025-06-26 06:20:20.109378');
INSERT INTO lysobacter.species VALUES (13, 'Lysobacter caseinilyticus', NULL, NULL, '2025-06-26 06:21:59.494506', '2025-06-26 06:21:59.494506');
INSERT INTO lysobacter.species VALUES (14, 'Lysobacter cavernae', NULL, NULL, '2025-06-26 06:24:48.508178', '2025-06-26 06:24:48.508178');
INSERT INTO lysobacter.species VALUES (15, 'Lysobacter concretionis', NULL, NULL, '2025-06-26 06:27:04.328668', '2025-06-26 06:27:04.328668');
INSERT INTO lysobacter.species VALUES (16, 'Lysobacter cucumeris', NULL, NULL, '2025-06-26 06:30:03.856434', '2025-06-26 06:30:03.856434');
INSERT INTO lysobacter.species VALUES (17, 'Lysobacter daejeonensis', NULL, NULL, '2025-06-26 06:34:41.601951', '2025-06-26 06:34:41.601951');
INSERT INTO lysobacter.species VALUES (18, 'Lysobacter defluvii', NULL, NULL, '2025-06-26 06:52:03.607207', '2025-06-26 06:52:03.607207');
INSERT INTO lysobacter.species VALUES (19, 'Lysobacter dokdonensis', NULL, NULL, '2025-06-26 06:57:10.819485', '2025-06-26 06:57:10.819485');
INSERT INTO lysobacter.species VALUES (20, 'Lysobacter tongrenensis', NULL, NULL, '2025-06-26 06:57:10.819485', '2025-06-26 06:57:10.819485');
INSERT INTO lysobacter.species VALUES (21, 'Lysobacter enzymogenes', NULL, NULL, '2025-06-26 07:07:28.925588', '2025-06-26 07:07:28.925588');
INSERT INTO lysobacter.species VALUES (22, 'Lysobacter enzymogenes subsp. cookii', NULL, NULL, '2025-06-26 07:15:30.110978', '2025-06-26 07:15:30.110978');
INSERT INTO lysobacter.species VALUES (23, 'Lysobacter enzymogenes subsp. enzymogenes', NULL, NULL, '2025-06-26 07:17:39.437709', '2025-06-26 07:17:39.437709');
INSERT INTO lysobacter.species VALUES (24, 'Lysobacter firmicutimachus', NULL, NULL, '2025-06-26 07:22:26.618307', '2025-06-26 07:22:26.618307');
INSERT INTO lysobacter.species VALUES (25, 'Lysobacter fragariae', NULL, NULL, '2025-06-26 07:25:02.810458', '2025-06-26 07:25:02.810458');
INSERT INTO lysobacter.species VALUES (26, 'Lysobacter ginsengisoli', NULL, NULL, '2025-06-26 07:31:04.56484', '2025-06-26 07:31:04.56484');
INSERT INTO lysobacter.species VALUES (27, 'Lysobacter gummosus', NULL, NULL, '2025-06-26 07:33:14.429692', '2025-06-26 07:33:14.429692');
INSERT INTO lysobacter.species VALUES (28, 'Lysobacter hankyongensis', NULL, NULL, '2025-06-26 07:35:10.644027', '2025-06-26 07:35:10.644027');
INSERT INTO lysobacter.species VALUES (29, 'Lysobacter humi', NULL, NULL, '2025-06-26 07:37:24.903408', '2025-06-26 07:37:24.903408');
INSERT INTO lysobacter.species VALUES (30, 'Lysobacter koreensis', NULL, NULL, '2025-06-26 07:40:33.583319', '2025-06-26 07:40:33.583319');
INSERT INTO lysobacter.species VALUES (31, 'Lysobacter korlensis', NULL, NULL, '2025-06-26 07:46:04.762326', '2025-06-26 07:46:04.762326');
INSERT INTO lysobacter.species VALUES (32, 'Lysobacter lacus', NULL, NULL, '2025-06-26 07:48:31.490817', '2025-06-26 07:48:31.490817');
INSERT INTO lysobacter.species VALUES (33, 'Lysobacter maris', NULL, NULL, '2025-06-26 07:50:15.081584', '2025-06-26 07:50:15.081584');
INSERT INTO lysobacter.species VALUES (34, 'Lysobacter mephitis', NULL, NULL, '2025-06-26 07:57:19.568773', '2025-06-26 07:57:19.568773');
INSERT INTO lysobacter.species VALUES (35, 'Lysobacter mobilis', NULL, NULL, '2025-06-26 07:57:19.568773', '2025-06-26 07:57:19.568773');
INSERT INTO lysobacter.species VALUES (36, 'Lysobacter niabensis', NULL, NULL, '2025-06-26 07:57:19.568773', '2025-06-26 07:57:19.568773');
INSERT INTO lysobacter.species VALUES (37, 'Lysobacter niastensis', NULL, NULL, '2025-06-26 07:59:40.869851', '2025-06-26 07:59:40.869851');
INSERT INTO lysobacter.species VALUES (38, 'Lysobacter silvestris', NULL, NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.species VALUES (39, 'Lysobacter novalis', NULL, NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.species VALUES (40, 'Lysobacter oculi', NULL, NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.species VALUES (41, 'Lysobacter oligotrophicus', NULL, NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.species VALUES (42, 'Lysobacter oryzae', NULL, NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.species VALUES (43, 'Lysobacter terrae', NULL, NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.species VALUES (44, 'Lysobacter panacisoli', NULL, NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.species VALUES (45, 'Lysobacter panaciterrae', NULL, NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.species VALUES (46, 'Lysobacter soli', NULL, NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.species VALUES (47, 'Lysobacter penaei', NULL, NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.species VALUES (48, 'Lysobacter pocheonensis', NULL, NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.species VALUES (49, 'Lysobacter prati', NULL, NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.species VALUES (50, 'Lysobacter rhizosphaerae', NULL, NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.species VALUES (51, 'Lysobacter ruishenii', NULL, NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:05:41.237309');
INSERT INTO lysobacter.species VALUES (52, 'Lysobacter sediminicola', NULL, NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.species VALUES (53, 'Lysobacter solanacearum', NULL, NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.species VALUES (54, 'Lysobacter zonguldakensis', NULL, NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.species VALUES (55, 'Lysobacter erysipheiresistens', NULL, NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.species VALUES (56, 'Lysobacter spongiae', NULL, NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.species VALUES (57, 'Lysobacter xinjiangensis', NULL, NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.species VALUES (58, 'Lysobacter lactamgenus', NULL, NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.species VALUES (59, 'Lysobacter vadosa', NULL, NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.species VALUES (60, 'Lysobacter sp.', NULL, NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.species VALUES (61, 'Luteimonas tolerans', NULL, NULL, '2025-06-28 08:47:18.018991', '2025-06-28 08:47:18.018991');
INSERT INTO lysobacter.species VALUES (62, 'Lysobacter tyrosinilyticus', NULL, NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.species VALUES (63, 'Lysobacter ximonensis', NULL, NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');


--
-- Data for Name: strains; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.strains VALUES (2, 'DCY117T', 'Lysobacter aestuarii', 'Strain DCY117T', 'Strain isolated from contaminated soil.', 'Загрязненная почва', NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 48.', true, '2025-06-26 01:25:32.136319', '2025-06-29 11:51:58.568418', 5, false, NULL);
INSERT INTO lysobacter.strains VALUES (3, 'DSM 19680T', 'Lysobacter aestuarii', 'Strain DSM 19680T', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Detailed test results for this strain were not found in the provided source document.', true, '2025-06-26 01:25:32.136319', '2025-06-29 11:51:58.568418', 5, false, NULL);
INSERT INTO lysobacter.strains VALUES (26, 'UASM 3C', 'Lysobacter antibioticus', 'Strain ATCC 29479', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 16 (ATCC 29479).
Original notes: Data from Table 9 on page 1. Also known as ATCC 29479.', true, '2025-06-26 02:08:58.160833', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (37, 'UASM L17', 'Lysobacter antibioticus', 'Strain ATCC 29480', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 17 (ATCC 29480).
Original notes: Data from Table 9 on page 1. Also known as ATCC 29480.', true, '2025-06-26 02:40:27.452518', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (84, 'UASM 2', 'Lysobacter brunescens', 'Strain ATCC 29483', 'Strain of Lysobacter brunescens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 79 (ATCC 29483).
Original notes: Data from Table 9 on page 2. Also known as ATCC 29483.', true, '2025-06-26 02:56:46.609219', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (20, 'DSM 2044T', 'Lysobacter antibioticus', 'Strain DSM 2044T', 'Type strain of Lysobacter antibioticus, frequently used in comparative studies.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data compiled from tables on pages 20, 21, 23, 30, 35, 43.', true, '2025-06-26 02:08:43.428969', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (21, 'KACC 11383T', 'Lysobacter antibioticus', 'Strain KACC 11383T', 'Strain of Lysobacter antibioticus.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from tables on pages 25-27.', true, '2025-06-26 02:08:43.428969', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (22, 'KCTC 12129T', 'Lysobacter antibioticus', 'Strain KCTC 12129T', 'Strain of Lysobacter antibioticus.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from tables on pages 12-13.', true, '2025-06-26 02:08:43.428969', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (107, 'D-14T', 'Lysobacter caeni', 'Strain D-14T', 'Type strain of Lysobacter caeni.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 45.', true, '2025-06-26 06:11:46.884141', '2025-06-29 11:51:58.568418', 11, false, NULL);
INSERT INTO lysobacter.strains VALUES (24, 'UASM 101', 'Lysobacter antibioticus', 'Strain UASM 101', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:08:58.160833', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (25, 'UASM 121', 'Lysobacter antibioticus', 'Strain UASM 121', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:08:58.160833', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (28, 'UASM 4169', 'Lysobacter antibioticus', 'Strain UASM 4169', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:17:20.062616', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (29, 'UASM 4551', 'Lysobacter antibioticus', 'Strain UASM 4551', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:17:20.062616', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (30, 'UASM 4572', 'Lysobacter antibioticus', 'Strain UASM 4572', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:17:20.062616', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (31, 'UASM 4574', 'Lysobacter antibioticus', 'Strain UASM 4574', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:17:20.062616', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (32, 'UASM 4578', 'Lysobacter antibioticus', 'Strain UASM 4578', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:23:11.891632', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (33, 'UASM 4593', 'Lysobacter antibioticus', 'Strain UASM 4593', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:23:11.891632', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (34, 'UASM 4598', 'Lysobacter antibioticus', 'Strain UASM 4598', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:23:11.891632', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (35, 'UASM 66', 'Lysobacter antibioticus', 'Strain UASM 66', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:23:11.891632', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (36, 'UASM 81', 'Lysobacter antibioticus', 'Strain UASM 81', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:40:27.452518', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (38, 'UASM Q15', 'Lysobacter antibioticus', 'Strain UASM Q15', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:40:27.452518', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (39, 'UASM Q9', 'Lysobacter antibioticus', 'Strain UASM Q9', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 1.', true, '2025-06-26 02:40:27.452518', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (41, 'CGMCC 1.10752T', 'Lysobacter arseniciresistens', 'Strain CGMCC 1.10752T', 'Strain isolated from iron ore soil, used for comparison with Lysobacter agilis.', 'Почва с железорудного месторождения', NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 1 on pages 1 and 84. Most data is inferred from the note comparing it to ZGLJ7-1T.', true, '2025-06-26 02:51:18.044327', '2025-06-29 11:51:58.568418', 8, false, NULL);
INSERT INTO lysobacter.strains VALUES (155, 'UASM 4556', 'Lysobacter enzymogenes', 'Strain UASM 4556', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (156, 'UASM 4557', 'Lysobacter enzymogenes', 'Strain UASM 4557', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (692, 'CJ29T', 'Lysobacter panacisoli', NULL, 'Грамотрицательная, факультативно-анаэробная, палочковидная, неподвижная бактерия. [2, 4, 5] Образует ярко-желтые колонии. [7]', 'Почва из женьшеневого поля', 'Ансон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как KACC 17502T и JCM 19212T. [2, 3]', true, '2025-06-28 07:53:00.30969', '2025-06-29 11:51:58.568418', 44, false, NULL);
INSERT INTO lysobacter.strains VALUES (745, 'TEST01-01', 'Lysobacter aestuarii', NULL, '', '', '', '2025-06-27', NULL, 11.00, 57.00, 45.00, '', false, '2025-06-29 06:36:17.577276', '2025-06-29 11:51:58.568418', NULL, false, NULL);
INSERT INTO lysobacter.strains VALUES (10, 'ZGLJ7-1T', 'Lysobacter agilis', 'Strain ZGLJ7-1T', 'Type strain of Lysobacter agilis, distinguished from Lysobacter arseniciresistens.', 'Грязь из ямы', NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 1 on page 1 and 84.', true, '2025-06-26 01:39:52.018094', '2025-06-29 11:51:58.568418', 4, false, NULL);
INSERT INTO lysobacter.strains VALUES (11, 'CGMCC 1.16756T', 'Lysobacter alkalisoli', 'Strain CGMCC 1.16756T', 'Type strain of Lysobacter alkalisoli.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 52.', true, '2025-06-26 01:39:52.018094', '2025-06-29 11:51:58.568418', 3, false, NULL);
INSERT INTO lysobacter.strains VALUES (12, '5-21aT', 'Lysobacter antrifimi', 'Strain 5-21aT', 'Type strain of Lysobacter antrifimi.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 11.', true, '2025-06-26 01:39:52.018094', '2025-06-29 11:51:58.568418', 2, false, NULL);
INSERT INTO lysobacter.strains VALUES (23, 'LMG 8760T', 'Lysobacter antibioticus', 'Strain LMG 8760T', 'Strain of Lysobacter antibioticus.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 29. All data points are cited from another source (Christensen & Cook, 1978).', true, '2025-06-26 02:08:43.428969', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (42, 'KCTC 23365T', 'Lysobacter arseniciresistens', 'Strain ZS79T', 'Type strain of Lysobacter arseniciresistens. Also known as ZS79T.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KCTC designation for the type strain ZS79T. Data is identical to ZS79T.', true, '2025-06-26 02:51:18.044327', '2025-06-29 11:51:58.568418', 8, false, NULL);
INSERT INTO lysobacter.strains VALUES (105, 'ZLD-29T', 'Lysobacter bugurensis', 'Strain ZLD-29T', 'Type strain of Lysobacter bugurensis, isolated from soil.', 'Почва', NULL, NULL, NULL, NULL, NULL, NULL, 'This strain is also referred to as ZLD-29 in some contexts.', true, '2025-06-26 06:08:48.097892', '2025-06-29 11:51:58.568418', 10, false, NULL);
INSERT INTO lysobacter.strains VALUES (117, 'KCTC 42875T', 'Lysobacter cavernae', 'Type strain of Lysobacter cavernae', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KCTC designation for the type strain C8-1T. All test data is listed under the C8-1T entry.', true, '2025-06-26 06:24:48.508178', '2025-06-29 11:51:58.568418', 14, false, NULL);
INSERT INTO lysobacter.strains VALUES (77, 'ATCC 29482', 'Lysobacter brunescens', 'Strain UASM D, ATCC 29482T', 'Type strain of Lysobacter brunescens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 78 (ATCC 29482T).
Original notes: Data compiled from pages 2, 20, 21, 30. This is the type strain, also designated as ATCC 29482T and UASM D.', true, '2025-06-26 02:56:46.609219', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (96, 'UASM 4541', 'Lysobacter brunescens', 'Strain UASM 4541', 'Strain of Lysobacter brunescens with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 2.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (97, 'UASM 6', 'Lysobacter brunescens', 'Strain ATCC 29484', 'Strain of Lysobacter brunescens with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 2. Also known as ATCC 29484.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (98, 'UASM CB1', 'Lysobacter brunescens', 'Strain UASM CB1', 'Strain of Lysobacter brunescens with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 2.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (109, 'DSM 19286T', 'Lysobacter capsici', 'Type strain of Lysobacter capsici', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the DSM designation for the type strain YC5194T. All test data is listed under the YC5194T entry.', true, '2025-06-26 06:20:20.109378', '2025-06-29 11:51:58.568418', 12, false, NULL);
INSERT INTO lysobacter.strains VALUES (110, 'KACC 14554T', 'Lysobacter capsici', 'Type strain of Lysobacter capsici', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KACC designation for the type strain YC5194T. All test data is listed under the YC5194T entry.', true, '2025-06-26 06:20:20.109378', '2025-06-29 11:51:58.568418', 12, false, NULL);
INSERT INTO lysobacter.strains VALUES (111, 'KCTC 22007T', 'Lysobacter capsici', 'Type strain of Lysobacter capsici', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KCTC designation for the type strain YC5194T. All test data is listed under the YC5194T entry.', true, '2025-06-26 06:20:20.109378', '2025-06-29 11:51:58.568418', 12, false, NULL);
INSERT INTO lysobacter.strains VALUES (112, 'YC 5194T', 'Lysobacter capsici', 'Type strain of Lysobacter capsici', 'Type strain of Lysobacter capsici. Also known as DSM 19286T, KACC 14554T, KCTC 22007T.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the primary designation for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms.', true, '2025-06-26 06:20:20.109378', '2025-06-29 11:51:58.568418', 12, false, NULL);
INSERT INTO lysobacter.strains VALUES (114, 'KACC 19816T', 'Lysobacter caseinilyticus', 'Strain KACC 19816T', 'Type strain of Lysobacter caseinilyticus.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'All data points except colony size are cited from Chhetri et al. 2019 in the source document.', true, '2025-06-26 06:21:59.494506', '2025-06-29 11:51:58.568418', 13, false, NULL);
INSERT INTO lysobacter.strains VALUES (190, 'KCTC 42810T', 'Lysobacter humi', 'Type strain of Lysobacter humi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KCTC designation for the type strain FJY8T. All test data is listed under the FJY8T entry.', true, '2025-06-26 07:37:24.903408', '2025-06-29 11:51:58.568418', 29, false, NULL);
INSERT INTO lysobacter.strains VALUES (78, 'ATCC 29482T', 'Lysobacter brunescens', 'Strain UASM D, ATCC 29482', 'Type strain of Lysobacter brunescens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 77 (ATCC 29482). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 77 (ATCC 29482).
Original notes: This is the type strain designation for ATCC 29482. Data is identical.', true, '2025-06-26 02:56:46.609219', '2025-06-29 11:52:07.11539', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (108, 'KACC 17141T', 'Lysobacter caeni', 'Strain KACC 17141T', 'Type strain of Lysobacter caeni, isolated from pesticide sediment.', 'Осадок пестицида', NULL, NULL, NULL, NULL, NULL, NULL, 'Data compiled from pages 5, 48, 69, 70. Conflicting data for salt tolerance and GC content was found between tables.', true, '2025-06-26 06:11:46.884141', '2025-06-29 11:51:58.568418', 11, false, NULL);
INSERT INTO lysobacter.strains VALUES (113, 'YC5194T', 'Lysobacter capsici', 'Type strain of Lysobacter capsici', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is a duplicate entry for YC 5194T. All test data is listed under the primary YC 5194T entry.', true, '2025-06-26 06:20:20.109378', '2025-06-29 11:51:58.568418', 12, false, NULL);
INSERT INTO lysobacter.strains VALUES (151, 'UASM 18L', 'Lysobacter enzymogenes', 'Strain ATCC 29485/6', 'Strain of Lysobacter enzymogenes. Also known as ATCC 29485/6.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (152, 'UASM 4553', 'Lysobacter enzymogenes', 'Strain UASM 4553', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (153, 'UASM 4554', 'Lysobacter enzymogenes', 'Strain UASM 4554', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (154, 'UASM 4555', 'Lysobacter enzymogenes', 'Strain UASM 4555', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (149, 'KCTC 12131T', 'Lysobacter enzymogenes', 'Type strain of Lysobacter enzymogenes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: This is the KCTC designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:52:07.11539', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (150, 'LMG 8762T', 'Lysobacter enzymogenes', 'Type strain of Lysobacter enzymogenes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: This is the LMG designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:52:07.11539', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (106, 'BUT-8T', 'Lysobacter caeni', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желто-зеленые колонии. [5, 6]', 'Активный ил с очистных сооружений', 'Порён, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как KCTC 23221T и CCUG 59800T. [5, 6]', true, '2025-06-26 06:11:46.884141', '2025-06-29 11:51:58.568418', 11, false, NULL);
INSERT INTO lysobacter.strains VALUES (115, 'C8-1T', 'Lysobacter cavernae', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [7, 8]', 'Стена пещеры', 'Пещера Ёнчхон, провинция Кёнсан-Пукто, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как YIM C01544T и KCTC 42504T. [7, 8]', true, '2025-06-26 06:24:48.508178', '2025-06-29 11:51:58.568418', 14, false, NULL);
INSERT INTO lysobacter.strains VALUES (4, 'KACC 18502T', 'Lysobacter aestuarii', 'Strain KACC 18502T', 'Strain isolated from estuarine sediments.', 'Эстуарные отложения', NULL, NULL, NULL, NULL, NULL, NULL, 'Data from tables on pages 48 and 52.', true, '2025-06-26 01:25:32.136319', '2025-06-29 11:51:58.568418', 5, false, NULL);
INSERT INTO lysobacter.strains VALUES (5, 'S2-CT', 'Lysobacter aestuarii', 'Strain S2-CT', 'Type strain of Lysobacter aestuarii.', 'Estuarine environment', NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 5.', true, '2025-06-26 01:25:32.136319', '2025-06-29 11:51:58.568418', 5, false, NULL);
INSERT INTO lysobacter.strains VALUES (99, 'UASM CB2', 'Lysobacter brunescens', 'Strain UASM CB2', 'Strain of Lysobacter brunescens with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 2.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (125, 'KACC 18720', 'Lysobacter daejeonensis', 'Type strain of Lysobacter daejeonensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 126 (KCTC 12600).
Original notes: This is the KACC designation for the type strain KCTC 12600T. All test data is listed under the KCTC 12600T entry.', true, '2025-06-26 06:34:41.601951', '2025-06-29 11:51:58.568418', 17, false, NULL);
INSERT INTO lysobacter.strains VALUES (128, 'Dae08T', 'Lysobacter daejeonensis', 'Type strain of Lysobacter daejeonensis', 'Type strain isolated from a freshwater stream sediment in Daejeon, South Korea. Also known as DSM 17634T, GH1-9T, KACC 11406T, KACC 18720.', 'freshwater stream sediment', 'Daejeon, South Korea', NULL, NULL, NULL, NULL, NULL, 'Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 06:48:31.463937', '2025-06-29 11:51:58.568418', 17, false, NULL);
INSERT INTO lysobacter.strains VALUES (129, 'DSM 17634T', 'Lysobacter daejeonensis', 'Type strain of Lysobacter daejeonensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the DSM designation for the type strain Dae08T. All test data is listed under the Dae08T entry.', true, '2025-06-26 06:48:31.463937', '2025-06-29 11:51:58.568418', 17, false, NULL);
INSERT INTO lysobacter.strains VALUES (130, 'GH1-9T', 'Lysobacter daejeonensis', 'Type strain of Lysobacter daejeonensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is a designation for the type strain Dae08T. All test data is listed under the Dae08T entry.', true, '2025-06-26 06:48:31.463937', '2025-06-29 11:51:58.568418', 17, false, NULL);
INSERT INTO lysobacter.strains VALUES (127, 'KCTC 12600T', 'Lysobacter daejeonensis', 'Type strain of Lysobacter daejeonensis', 'Type strain of Lysobacter daejeonensis, isolated from stream sediment. Also known as KACC 18720.', 'Осадок ручья', NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 125 (KACC 18720). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 126 (KCTC 12600).
Original notes: DUPLICATE of Strain ID 125 (KACC 18720).
Original notes: Data is a compilation from all tables mentioning this strain or its synonyms. Significant conflicts were found for GC content, salt tolerance, catalase, and trypsin activity.', true, '2025-06-26 06:34:41.601951', '2025-06-29 11:52:07.11539', 17, false, NULL);
INSERT INTO lysobacter.strains VALUES (132, 'DSM 18482T', 'Lysobacter defluvii', 'Type strain of Lysobacter defluvii', 'Type strain isolated from activated sludge in Braunschweig, Germany. Also known as IMMIB APB-9T.', 'activated sludge', 'Braunschweig, Germany', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 133 (IMMIB APB-9T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 133 (IMMIB APB-9T).
Original notes: DUPLICATE of Strain ID 133 (IMMIB APB-9T).
Original notes: Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive. Conflicting data was resolved using BacDive as the primary source.', true, '2025-06-26 06:52:03.607207', '2025-06-29 11:52:07.11539', 18, false, NULL);
INSERT INTO lysobacter.strains VALUES (133, 'IMMIB APB-9T', 'Lysobacter defluvii', 'Type strain of Lysobacter defluvii', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the IMMIB designation for the type strain DSM 18482T. All test data is listed under the DSM 18482T entry.', true, '2025-06-26 06:52:03.607207', '2025-06-29 11:51:58.568418', 18, false, NULL);
INSERT INTO lysobacter.strains VALUES (126, 'KCTC 12600', 'Lysobacter daejeonensis', 'Type strain of Lysobacter daejeonensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 125 (KACC 18720). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 125 (KACC 18720).
Original notes: This is a designation for the type strain KCTC 12600T. All test data is listed under the KCTC 12600T entry.', true, '2025-06-26 06:34:41.601951', '2025-06-29 11:52:07.11539', 17, false, NULL);
INSERT INTO lysobacter.strains VALUES (134, 'DS-58T', 'Lysobacter dokdonensis', 'Type strain of Lysobacter dokdonensis', 'Type strain isolated from soil on Dokdo island, South Korea. Also known as DSM 17958T, KACC 18711T, KCTC 12822T.', 'soil', 'Dokdo, South Korea', NULL, NULL, NULL, NULL, NULL, 'Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive. Conflicting data for nitrate reduction was resolved.', true, '2025-06-26 06:57:10.819485', '2025-06-29 11:51:58.568418', 19, false, NULL);
INSERT INTO lysobacter.strains VALUES (137, 'KCTC 12822T', 'Lysobacter dokdonensis', 'Type strain of Lysobacter dokdonensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 135 (DSM 17958T).
Original notes: This is the KCTC designation for the type strain DS-58T. All test data is listed under the DS-58T entry.', true, '2025-06-26 06:57:10.819485', '2025-06-29 11:51:58.568418', 19, false, NULL);
INSERT INTO lysobacter.strains VALUES (136, 'KACC 18711T', 'Lysobacter dokdonensis', 'Type strain of Lysobacter dokdonensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is a KACC designation for the type strain DS-58T. All test data is listed under the DS-58T entry.', true, '2025-06-26 06:57:10.819485', '2025-06-29 11:51:58.568418', 19, false, NULL);
INSERT INTO lysobacter.strains VALUES (139, 'DSM 2043T', 'Lysobacter enzymogenes', 'Type strain of Lysobacter enzymogenes', 'Type strain isolated from soil in Wisconsin, USA. Also known as ATCC 29487T, LMG 8762T, KACC 10127T, BCRC 11654T, KCTC 12131T.', 'soil', 'Wisconsin, USA', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive. Conflicting data was resolved.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (140, '495T', 'Lysobacter enzymogenes', 'Strain UASM 495, ATCC 29488', 'Strain of Lysobacter enzymogenes. Also known as UASM 495 and ATCC 29488.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (141, 'ATCC 21123', 'Lysobacter enzymogenes', 'Strain ATCC 21123', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (142, 'ATCC 27796', 'Lysobacter enzymogenes', 'Strain UASM AL-1', 'Strain of Lysobacter enzymogenes. Also known as UASM AL-1.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (120, 'K007T', 'Lysobacter concretionis', 'Type strain of Lysobacter concretionis', 'Type strain of Lysobacter concretionis. Also known as DSM 16239T, KACC 11484T, KCTC 12205T, Ko07T.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data is a compilation from all tables mentioning this strain or its synonyms. Conflicting data was found for aesculin hydrolysis and GC content.', true, '2025-06-26 06:27:04.328668', '2025-06-29 11:51:58.568418', 15, false, NULL);
INSERT INTO lysobacter.strains VALUES (124, 'BZ', 'Lysobacter cucumeris', 'Strain BZ', 'Strain of Lysobacter cucumeris used in a comparative study.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'All data points are from the table on page 57.', true, '2025-06-26 06:30:03.856434', '2025-06-29 11:51:58.568418', 16, false, NULL);
INSERT INTO lysobacter.strains VALUES (131, 'KACC 11406T', 'Lysobacter daejeonensis', 'Type strain of Lysobacter daejeonensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KACC designation for the type strain Dae08T. All test data is listed under the Dae08T entry.', true, '2025-06-26 06:48:31.463937', '2025-06-29 11:51:58.568418', 17, false, NULL);
INSERT INTO lysobacter.strains VALUES (143, 'ATCC 29485/6', 'Lysobacter enzymogenes', 'Strain UASM 18L', 'Strain of Lysobacter enzymogenes. Also known as UASM 18L.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is a designation for the strain UASM 18L. All test data is listed under the UASM 18L entry.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (684, 'AM20-91T', 'Lysobacter silvestris', NULL, 'Грамотрицательная, палочковидная, подвижная, каталазоположительная и оксидазоположительная бактерия.', 'Альпийская лесная почва', 'Монтиггл, Южный Тироль, Италия', NULL, NULL, NULL, NULL, NULL, 'Дополнительные тесты, не входящие в канонический список, включают: полярный жгутик (+), липаза (C14) (-), β-галактозидаза (+), β-глюкозидаза (+), N-ацетил-β-D-глюкозаминидаза (+).', true, '2025-06-28 02:44:37.959633', '2025-06-29 11:51:58.568418', 38, false, NULL);
INSERT INTO lysobacter.strains VALUES (685, 'CCTCC AB2014319T', 'Lysobacter novalis', NULL, 'Грамотрицательная, темно-желтая, аэробная, палочковидная бактерия со скользящей подвижностью.', 'Почва с парового поля', 'Йонъин, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как THG-PC7T. [1] Дополнительные тесты, не входящие в канонический список, включают: полярный жгутик (-), липаза (C14) (+), β-галактозидаза (+), β-глюкозидаза (+), N-ацетил-β-D-глюкозаминидаза (+).', true, '2025-06-28 02:44:37.959633', '2025-06-29 11:51:58.568418', 39, false, NULL);
INSERT INTO lysobacter.strains VALUES (171, 'PB-6250T', 'Lysobacter firmicutimachus', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует кремово-желтые колонии. [3, 4]', 'Речная вода', 'Река Тафф, Кардифф, Великобритания', NULL, NULL, NULL, NULL, NULL, 'Также известен как LMG 24580T и CCUG 55848T. [3, 4]', true, '2025-06-26 07:22:26.618307', '2025-06-29 11:51:58.568418', 24, false, NULL);
INSERT INTO lysobacter.strains VALUES (135, 'DSM 17958T', 'Lysobacter dokdonensis', 'Type strain of Lysobacter dokdonensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 137 (KCTC 12822T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 137 (KCTC 12822T).
Original notes: This is the DSM designation for the type strain DS-58T. All test data is listed under the DS-58T entry.', true, '2025-06-26 06:57:10.819485', '2025-06-29 11:52:07.11539', 19, false, NULL);
INSERT INTO lysobacter.strains VALUES (177, 'ATCC 29489', 'Lysobacter gummosus', 'Type strain of Lysobacter gummosus', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: This is a designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.', true, '2025-06-26 07:33:14.429692', '2025-06-29 11:52:07.11539', 27, false, NULL);
INSERT INTO lysobacter.strains VALUES (693, 'KCTC 12601T', 'Lysobacter panaciterrae', NULL, 'Грамотрицательная, аэробная, палочковидная, неспорообразующая бактерия. [1] Обладает скользящей подвижностью. [4]', 'Почва с поля женьшеня', 'Провинция Почхон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как CC-Bw-6T и Gsoil 068T (согласно публикации Ten et al., 2009, но позже Gsoil 068T был переклассифицирован). [1] Впоследствии был переклассифицирован в Luteimonas panaciterrae. [10]', true, '2025-06-28 07:55:31.590866', '2025-06-29 11:51:58.568418', 45, false, NULL);
INSERT INTO lysobacter.strains VALUES (698, '5GH18-14T', 'Lysobacter rhizosphaerae', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная бактерия. Образует желтые, круглые, гладкие колонии. [1, 2]', 'Ризосфера Aglaia odorata', 'Гуанчжоу, провинция Гуандун, Китай', NULL, NULL, NULL, NULL, NULL, 'Также известен как KACC 18544T и CCTCC AB 2015201T. [1, 2]', true, '2025-06-28 08:04:18.217889', '2025-06-29 11:51:58.568418', 50, false, NULL);
INSERT INTO lysobacter.strains VALUES (701, 'T20R-70T', 'Lysobacter solanacearum', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует бледно-желтые, круглые, выпуклые колонии. [1, 2]', 'Почва', 'Провинция Кёнгидо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как CHu50b-3-2T, KACC 18656T и JCM 32178T. [1, 2]', true, '2025-06-28 08:10:22.874785', '2025-06-29 11:51:58.568418', 53, false, NULL);
INSERT INTO lysobacter.strains VALUES (157, 'UASM 4558', 'Lysobacter enzymogenes', 'Strain UASM 4558', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (158, 'UASM 4559', 'Lysobacter enzymogenes', 'Strain UASM 4559', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (159, 'UASM 4560', 'Lysobacter enzymogenes', 'Strain UASM 4560', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (160, 'UASM 4561', 'Lysobacter enzymogenes', 'Strain UASM 4561', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (170, 'BCRC 11', 'Lysobacter enzymogenes subsp. enzymogenes', 'Strain BCRC 11', 'Strain of the subspecies Lysobacter enzymogenes subsp. enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'All data points are from the table on page 40.', true, '2025-06-26 07:17:39.437709', '2025-06-29 11:51:58.568418', 23, false, NULL);
INSERT INTO lysobacter.strains VALUES (173, 'Gsoil 357T', 'Lysobacter ginsengisoli', 'Strain KCTC 12602T', 'Type strain of Lysobacter ginsengisoli, isolated from soil of a ginseng field. Also known as KCTC 12602T.', 'soil of a ginseng field', 'Pocheon, Gyeonggi Province, South Korea', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 07:31:04.56484', '2025-06-29 11:51:58.568418', 26, false, NULL);
INSERT INTO lysobacter.strains VALUES (174, 'KCTC 12602', 'Lysobacter ginsengisoli', 'Type strain of Lysobacter ginsengisoli', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KCTC designation for the type strain Gsoil 357T. All test data is listed under the Gsoil 357T entry.', true, '2025-06-26 07:31:04.56484', '2025-06-29 11:51:58.568418', 26, false, NULL);
INSERT INTO lysobacter.strains VALUES (175, 'KCTC 12602T', 'Lysobacter ginsengisoli', 'Type strain of Lysobacter ginsengisoli', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KCTC designation for the type strain Gsoil 357T. All test data is listed under the Gsoil 357T entry.', true, '2025-06-26 07:31:04.56484', '2025-06-29 11:51:58.568418', 26, false, NULL);
INSERT INTO lysobacter.strains VALUES (176, 'ATCC 29489T', 'Lysobacter gummosus', 'Type strain of Lysobacter gummosus', 'Type strain of Lysobacter gummosus, isolated from soil. Also known as DSM 6980T, LMG 8763T, etc.', 'soil', 'USA, Iowa', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive. Conflicting data was resolved.', true, '2025-06-26 07:33:14.429692', '2025-06-29 11:51:58.568418', 27, false, NULL);
INSERT INTO lysobacter.strains VALUES (188, '17J68-2T', 'Lysobacter humi', 'Type strain of Lysobacter humi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is a designation for the type strain FJY8T. All test data is listed under the FJY8T entry.', true, '2025-06-26 07:37:24.903408', '2025-06-29 11:51:58.568418', 29, false, NULL);
INSERT INTO lysobacter.strains VALUES (189, '17J7-1T', 'Lysobacter humi', 'Type strain of Lysobacter humi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is a designation for the type strain FJY8T. All test data is listed under the FJY8T entry.', true, '2025-06-26 07:37:24.903408', '2025-06-29 11:51:58.568418', 29, false, NULL);
INSERT INTO lysobacter.strains VALUES (191, 'Dae16T', 'Lysobacter koreensis', 'Strain KACC 11581T, KCTC 12204T, DSM 17633', 'Type strain of Lysobacter koreensis, isolated from greenhouse soil. Also known as KACC 11581T and KCTC 12204T.', 'greenhouse soil', 'Suwon, Gyeonggi Province, South Korea', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 07:40:33.583319', '2025-06-29 11:51:58.568418', 30, false, NULL);
INSERT INTO lysobacter.strains VALUES (192, 'KACC 11581T', 'Lysobacter koreensis', 'Type strain of Lysobacter koreensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KACC designation for the type strain Dae16T. All test data is listed under the Dae16T entry.', true, '2025-06-26 07:40:33.583319', '2025-06-29 11:51:58.568418', 30, false, NULL);
INSERT INTO lysobacter.strains VALUES (193, 'KCTC 12204T', 'Lysobacter koreensis', 'Type strain of Lysobacter koreensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KCTC designation for the type strain Dae16T. All test data is listed under the Dae16T entry.', true, '2025-06-26 07:40:33.583319', '2025-06-29 11:51:58.568418', 30, false, NULL);
INSERT INTO lysobacter.strains VALUES (194, 'ZLD-17T', 'Lysobacter korlensis', 'Strain KCTC 42168, CGMCC 1.12943', 'Type strain of Lysobacter korlensis, isolated from a soil sample.', 'soil', 'Korla, Xinjiang, China', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain, cross-referenced with BacDive.', true, '2025-06-26 07:46:04.762326', '2025-06-29 11:51:58.568418', 31, false, NULL);
INSERT INTO lysobacter.strains VALUES (195, 'UKS-15T', 'Lysobacter lacus', 'Strain KCTC 42810T, NBRC 109678T', 'Type strain of Lysobacter lacus, isolated from freshwater lake sediment.', 'freshwater lake sediment', 'Uksan, Republic of Korea', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from the PDF and BacDive.', true, '2025-06-26 07:48:31.490817', '2025-06-29 11:51:58.568418', 32, false, NULL);
INSERT INTO lysobacter.strains VALUES (196, 'KMU-14T', 'Lysobacter maris', 'Strain KCTC 42381T, NBRC 110750T', 'Type strain of Lysobacter maris, isolated from seawater. Also known as KCTC 42381T and NBRC 110750T.', 'seawater', 'Jeju Island, Republic of Korea', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 07:50:15.081584', '2025-06-29 11:51:58.568418', 33, false, NULL);
INSERT INTO lysobacter.strains VALUES (197, 'KCTC 42381T', 'Lysobacter maris', 'Type strain of Lysobacter maris', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 198 (NBRC 110750T).
Original notes: This is the KCTC designation for the type strain KMU-14T. All test data is listed under the KMU-14T entry.', true, '2025-06-26 07:50:15.081584', '2025-06-29 11:51:58.568418', 33, false, NULL);
INSERT INTO lysobacter.strains VALUES (199, 'CIP 107229T', 'Lysobacter mephitis', 'Type strain of Lysobacter mephitis', 'Type strain of Lysobacter mephitis.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data extracted from the table on page 57.', true, '2025-06-26 07:57:19.568773', '2025-06-29 11:51:58.568418', 34, false, NULL);
INSERT INTO lysobacter.strains VALUES (200, '9NM-14T', 'Lysobacter mobilis', 'Strain DSM 27574T, KCTC 52627T', 'Type strain of Lysobacter mobilis, isolated from zinc-lead mine tailings.', 'zinc-lead mine tailings', 'Dongshengmiao, Inner Mongolia, China', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 07:57:19.568773', '2025-06-29 11:51:58.568418', 35, false, NULL);
INSERT INTO lysobacter.strains VALUES (201, 'DSM 27574T', 'Lysobacter mobilis', 'Type strain of Lysobacter mobilis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the DSM designation for the type strain 9NM-14T. All test data is listed under the 9NM-14T entry.', true, '2025-06-26 07:57:19.568773', '2025-06-29 11:51:58.568418', 35, false, NULL);
INSERT INTO lysobacter.strains VALUES (202, 'KCTC 52627T', 'Lysobacter mobilis', 'Type strain of Lysobacter mobilis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KCTC designation for the type strain 9NM-14T. All test data is listed under the 9NM-14T entry.', true, '2025-06-26 07:57:19.568773', '2025-06-29 11:51:58.568418', 35, false, NULL);
INSERT INTO lysobacter.strains VALUES (206, 'DSM 18481T', 'Lysobacter niastensis', 'Strain GH41-7T, KACC 11588T, KACC 22750T', 'Type strain of Lysobacter niastensis, isolated from greenhouse soil. Also known as GH41-7T, KACC 11588T, KACC 22750T.', 'greenhouse soil', 'Yongin, Gyeonggi Province, South Korea', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 07:59:40.869851', '2025-06-29 11:51:58.568418', 37, false, NULL);
INSERT INTO lysobacter.strains VALUES (686, '83-4T', 'Lysobacter oculi', NULL, 'Грамотрицательная, палочковидная, каталазо- и оксидазоположительная бактерия, образующая желтые колонии. [1, 2, 3]', 'Секрет мейбомиевых желез человека', 'Пекин, Китай', NULL, NULL, NULL, NULL, NULL, 'Также известен как CGMCC 1.13464T и NRBC 113451T. [2] Размер клеток 2.7 × 1.3 мкм. [3]', true, '2025-06-28 07:47:08.669393', '2025-06-29 11:51:58.568418', 40, false, NULL);
INSERT INTO lysobacter.strains VALUES (699, 'CTN-1T', 'Lysobacter ruishenii', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые, круглые, выпуклые колонии. [1, 2, 3]', 'Почва', 'Пекин, Китай', NULL, NULL, NULL, NULL, NULL, 'Также известен как DSM 22393T и KCTC 23715T. [1, 2, 3]', true, '2025-06-28 08:05:41.237309', '2025-06-29 11:51:58.568418', 51, false, NULL);
INSERT INTO lysobacter.strains VALUES (184, 'KACC 16618', 'Lysobacter hankyongensis', 'Type strain of Lysobacter hankyongensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KACC designation for the type strain KTCe-2T. All test data is listed under the KTCe-2T entry.', true, '2025-06-26 07:35:10.644027', '2025-06-29 11:51:58.568418', 28, false, NULL);
INSERT INTO lysobacter.strains VALUES (185, 'KACC 16618T', 'Lysobacter hankyongensis', 'Type strain of Lysobacter hankyongensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KACC designation for the type strain KTCe-2T. All test data is listed under the KTCe-2T entry.', true, '2025-06-26 07:35:10.644027', '2025-06-29 11:51:58.568418', 28, false, NULL);
INSERT INTO lysobacter.strains VALUES (186, 'KTCe-2T', 'Lysobacter hankyongensis', 'Strain KACC 16618T', 'Type strain of Lysobacter hankyongensis, isolated from activated sludge. Also known as KACC 16618T.', 'activated sludge', 'Anseong, South Korea', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 07:35:10.644027', '2025-06-29 11:51:58.568418', 28, false, NULL);
INSERT INTO lysobacter.strains VALUES (187, 'FJY8T', 'Lysobacter humi', 'Strain KCTC 42810T, DSM 27573', 'Type strain of Lysobacter humi, isolated from forest soil. Also known as KCTC 42810T, 17J68-2T, 17J7-1T.', 'forest soil', 'South Korea', NULL, NULL, NULL, NULL, NULL, 'This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 07:37:24.903408', '2025-06-29 11:51:58.568418', 29, false, NULL);
INSERT INTO lysobacter.strains VALUES (27, 'UASM 4045', 'Lysobacter antibioticus', 'Strain ATCC 29481', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 18 (ATCC 29481).
Original notes: Data from Table 9 on page 1. Also known as ATCC 29481.', true, '2025-06-26 02:08:58.160833', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (118, 'YIM C01544T', 'Lysobacter cavernae', 'Type strain of Lysobacter cavernae', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the YIM designation for the type strain C8-1T. All test data is listed under the C8-1T entry.', true, '2025-06-26 06:24:48.508178', '2025-06-29 11:51:58.568418', 14, false, NULL);
INSERT INTO lysobacter.strains VALUES (121, 'KACC 11484T', 'Lysobacter concretionis', 'Type strain of Lysobacter concretionis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the KACC designation for the type strain K007T. All test data is listed under the K007T entry.', true, '2025-06-26 06:27:04.328668', '2025-06-29 11:51:58.568418', 15, false, NULL);
INSERT INTO lysobacter.strains VALUES (123, 'Ko07T', 'Lysobacter concretionis', 'Type strain of Lysobacter concretionis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is a variant spelling for the type strain K007T. All test data is listed under the K007T entry.', true, '2025-06-26 06:27:04.328668', '2025-06-29 11:51:58.568418', 15, false, NULL);
INSERT INTO lysobacter.strains VALUES (138, 'YJ15T', 'Lysobacter tongrenensis', 'Type strain of Lysobacter tongrenensis', 'Type strain of Lysobacter tongrenensis. Also known as KCTC 52206T.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data extracted from the table on page 73.', true, '2025-06-26 06:57:10.819485', '2025-06-29 11:51:58.568418', 20, false, NULL);
INSERT INTO lysobacter.strains VALUES (122, 'KCTC 12205T', 'Lysobacter concretionis', 'Type strain of Lysobacter concretionis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 119 (DSM 16239T).
Original notes: This is the KCTC designation for the type strain K007T. All test data is listed under the K007T entry.', true, '2025-06-26 06:27:04.328668', '2025-06-29 11:51:58.568418', 15, false, NULL);
INSERT INTO lysobacter.strains VALUES (148, 'KACC 11382T', 'Lysobacter enzymogenes', 'Strain KACC 11382T', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 7.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (708, 'RS-LYSO-3T', 'Lysobacter erysipheiresistens', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [7, 8]', 'Почва', 'Тэджон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как KCTC 12900T и DSM 19330T. [7, 8]', true, '2025-06-28 08:22:56.033373', '2025-06-29 11:51:58.568418', 55, false, NULL);
INSERT INTO lysobacter.strains VALUES (198, 'NBRC 110750T', 'Lysobacter maris', 'Type strain of Lysobacter maris', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 197 (KCTC 42381T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 197 (KCTC 42381T).
Original notes: This is the NBRC designation for the type strain KMU-14T. All test data is listed under the KMU-14T entry.', true, '2025-06-26 07:50:15.081584', '2025-06-29 11:52:07.11539', 33, false, NULL);
INSERT INTO lysobacter.strains VALUES (687, 'JCM 18257T', 'Lysobacter oligotrophicus', NULL, 'Грамотрицательная, неспорообразующая, палочковидная, аэробная бактерия. [6, 7] Проявляет олиготрофные свойства, не растет в средах с высокой концентрацией органических соединений. [6]', 'Пресная вода с микробными матами', 'Озеро Танаго Ике, Скарвснес, Антарктида', NULL, NULL, NULL, NULL, NULL, 'Также известен как 107-E2T и ATCC BAA-2438T. [6] В поздней стационарной фазе образует водорастворимый темно-коричневый пигмент (меланин). [3, 6]', true, '2025-06-28 07:49:04.951662', '2025-06-29 11:51:58.568418', 41, false, NULL);
INSERT INTO lysobacter.strains VALUES (696, 'KCTC 12624T', 'Lysobacter pocheonensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2, 3]', 'Почва с поля женьшеня', 'Пхочхон, провинция Кёнгидо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как 50T, Gsoil 193T и YS-37T. [1, 2, 3]', true, '2025-06-28 08:00:51.681277', '2025-06-29 11:51:58.568418', 48, false, NULL);
INSERT INTO lysobacter.strains VALUES (700, '7C-9T', 'Lysobacter sediminicola', NULL, 'Грамотрицательная, аэробная, неподвижная, палочковидная бактерия. Образует желтые, круглые, выпуклые колонии. [1, 2, 3]', 'Осадок пресной воды', 'Плотина Тэчхон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как KCTC 22340T и CCUG 56350T. [1, 2, 3]', true, '2025-06-28 08:08:11.075227', '2025-06-29 11:51:58.568418', 52, false, NULL);
INSERT INTO lysobacter.strains VALUES (703, 'DCY21T', 'Lysobacter soli', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия со скользящей подвижностью. Образует желтоватые колонии. [4, 5]', 'Почва с поля женьшеня', 'Пхочхон, провинция Кёнгидо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как KCTC 22011T, KACC 15381T и KACC 22011T. [4, 5]', true, '2025-06-28 08:17:14.808024', '2025-06-29 11:51:58.568418', 46, false, NULL);
INSERT INTO lysobacter.strains VALUES (704, 'zong215T', 'Lysobacter zonguldakensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые, круглые колонии. [6, 7]', 'Почва', 'Зонгулдак, Турция', NULL, NULL, NULL, NULL, NULL, 'Также известен как DSM 22241T и CCUG 57973T. [6, 7]', true, '2025-06-28 08:17:14.808024', '2025-06-29 11:51:58.568418', 54, false, NULL);
INSERT INTO lysobacter.strains VALUES (1, 'GH19-3', 'Lysobacter yangpyeongensis', 'Strain GH19-3', 'Automated test by Gemini AI - it finally works!', 'Soil from a greenhouse', 'Yangpyeong, Gyeonggi province, Republic of Korea', '2009-08-01', NULL, NULL, NULL, NULL, 'Also known as KACC 13310 or DSM 22445. The paper describing the strain was published in 2009.', true, '2025-06-26 01:19:03.170621', '2025-06-29 11:51:58.568418', 1, false, NULL);
INSERT INTO lysobacter.strains VALUES (19, 'BCRC 11653T', 'Lysobacter antibioticus', 'Strain BCRC 11653T', 'Type strain of Lysobacter antibioticus.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 14.', true, '2025-06-26 02:05:40.181', '2025-06-29 11:51:58.568418', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (43, 'ZS79T', 'Lysobacter arseniciresistens', 'Strain ZS79T', 'Type strain of Lysobacter arseniciresistens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data compiled from tables on pages 5, 8, and 27. Some conflicting data points were noted and resolved.', true, '2025-06-26 02:51:18.044327', '2025-06-29 11:51:58.568418', 8, false, NULL);
INSERT INTO lysobacter.strains VALUES (81, 'DSM 6979T', 'Lysobacter brunescens', 'Strain DSM 6979T', 'Type strain of Lysobacter brunescens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data compiled from table on page 24.', true, '2025-06-26 02:56:46.609219', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (82, 'KACC 11385T', 'Lysobacter brunescens', 'Strain KACC 11385T', 'Type strain of Lysobacter brunescens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data compiled from tables on pages 25-27.', true, '2025-06-26 02:56:46.609219', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (83, 'KCTC 12130T', 'Lysobacter brunescens', 'Strain KCTC 12130T', 'Strain of Lysobacter brunescens isolated from soil.', 'Почва', NULL, NULL, NULL, NULL, NULL, NULL, 'Data compiled from table on page 31.', true, '2025-06-26 02:56:46.609219', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (116, 'IPC6T', 'Lysobacter cavernae', 'Type strain of Lysobacter cavernae', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is a designation for the type strain C8-1T. All test data is listed under the C8-1T entry.', true, '2025-06-26 06:24:48.508178', '2025-06-29 11:51:58.568418', 14, false, NULL);
INSERT INTO lysobacter.strains VALUES (688, 'KACC 14553T', 'Lysobacter oryzae', NULL, 'Грамотрицательная, палочковидная, аэробная бактерия, образующая бледно-желтые колонии.', 'Почва из теплицы', 'Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как L. oryzae KCTC 22249T. Данные для этого штамма были собраны из разных таблиц в предоставленном документе.', true, '2025-06-28 07:50:55.242479', '2025-06-29 11:51:58.568418', 42, false, NULL);
INSERT INTO lysobacter.strains VALUES (690, 'THG-DN8.2T', 'Lysobacter terrae', NULL, 'Грамотрицательная, палочковидная, аэробная бактерия, образующая бледно-желтые колонии. [1]', 'Почва', 'Остров Чеджу, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Все штаммы положительны на гидролиз Твин 80, L-тирозина, казеина и желатина. Отрицательны на восстановление нитратов, продукцию индола, подкисление глюкозы и аргининдигидролазу; гидролиз хитина, мочевины и эскулина.', true, '2025-06-28 07:50:55.242479', '2025-06-29 11:51:58.568418', 43, false, NULL);
INSERT INTO lysobacter.strains VALUES (691, 'THG-YS3.6T', 'Lysobacter terrae', NULL, 'Палочковидные бактерии, отрицательные на восстановление нитратов и продукцию индола.', 'Почва', 'Остров Чеджу, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Данные из таблицы ''Физиологические характеристики штамма THG-YS3.6T''.', true, '2025-06-28 07:50:55.242479', '2025-06-29 11:51:58.568418', 43, false, NULL);
INSERT INTO lysobacter.strains VALUES (697, 'SYSU H10001T', 'Lysobacter prati', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия, образующая желтые, круглые колонии. [2, 4]', 'Почва с луга на плато', 'Округ Хунъюань, провинция Сычуань, Китай', NULL, NULL, NULL, NULL, NULL, 'Также известен как KCTC 72062T и CGMCC 1.16662T. [2, 3]', true, '2025-06-28 08:02:14.256398', '2025-06-29 11:51:58.568418', 49, false, NULL);
INSERT INTO lysobacter.strains VALUES (100, 'UASM CB4', 'Lysobacter brunescens', 'Strain UASM CB4', 'Strain of Lysobacter brunescens with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 2.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (101, 'UASM CB5', 'Lysobacter brunescens', 'Strain UASM CB5', 'Strain of Lysobacter brunescens with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 2.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (102, 'UASM CB6', 'Lysobacter brunescens', 'Strain UASM CB6', 'Strain of Lysobacter brunescens with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 2.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (103, 'UASM CB7', 'Lysobacter brunescens', 'Strain UASM CB7', 'Strain of Lysobacter brunescens with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from Table 9 on page 2.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:51:58.568418', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (161, 'UASM 4562', 'Lysobacter enzymogenes', 'Strain UASM 4562', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (162, 'UASM 4563', 'Lysobacter enzymogenes', 'Strain UASM 4563', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (163, 'UASM 4564', 'Lysobacter enzymogenes', 'Strain UASM 4564', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (164, 'UASM 4565', 'Lysobacter enzymogenes', 'Strain UASM 4565', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (165, 'UASM 495', 'Lysobacter enzymogenes', 'Strain ATCC 29488, 495T', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is the UASM designation for the strain 495T. All test data is listed under the 495T entry.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (167, 'UASM Q1', 'Lysobacter enzymogenes', 'Strain UASM Q1', 'Strain of Lysobacter enzymogenes.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Data from table on page 2.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (145, 'ATCC 29488', 'Lysobacter enzymogenes subsp. cookii', 'Strain UASM 13B', 'Type strain of the subspecies Lysobacter enzymogenes subsp. cookii. Also known as UASM 13B.', 'soil', 'USA, Wisconsin', NULL, NULL, NULL, NULL, NULL, 'Data is a compilation from the PDF (page 2) and BacDive. BacDive provided core physiological data, while the PDF provided specific acid production results.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:51:58.568418', 22, false, NULL);
INSERT INTO lysobacter.strains VALUES (710, 'LMG 30077T', 'Lysobacter spongiae', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые, круглые, блестящие колонии. [1, 2]', 'Морская губка Aplysina aerophoba', 'Средиземное море, Кала-Монтго, Испания', NULL, NULL, NULL, NULL, NULL, 'Также известен как KMM 9005T и CECT 9427T. [1, 2]', true, '2025-06-28 08:27:25.420929', '2025-06-29 11:51:58.568418', 56, false, NULL);
INSERT INTO lysobacter.strains VALUES (718, 'UCT', 'Lysobacter soli', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия. Образует бледно-желтые колонии. [3]', 'Почва', 'Неизвестно', NULL, NULL, NULL, NULL, NULL, 'Данные для этого штамма взяты из таблицы ''Дифференциальные фенотипические характеристики штамма UCT''. Вероятно, является синонимом DCY21T (Lysobacter soli) из-за почти идентичных характеристик.', true, '2025-06-28 08:33:23.64213', '2025-06-29 11:51:58.568418', 46, false, NULL);
INSERT INTO lysobacter.strains VALUES (719, 'YIM 77875T', 'Lysobacter xinjiangensis', NULL, 'Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует желтые, круглые колонии. [5, 6]', 'Почва', 'Синьцзян, Китай', NULL, NULL, NULL, NULL, NULL, 'Также известен как CCTCC AB 2011043T и KCTC 23558T. [5, 6]', true, '2025-06-28 08:33:23.64213', '2025-06-29 11:51:58.568418', 57, false, NULL);
INSERT INTO lysobacter.strains VALUES (720, 'YK-278', 'Lysobacter lactamgenus', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия, продуцирующая антибиотики цефабацины. [7, 8]', 'Почва', 'Япония', NULL, NULL, NULL, NULL, NULL, 'Штамм-продуцент цефабацина. [7]', true, '2025-06-28 08:33:23.64213', '2025-06-29 11:51:58.568418', 58, false, NULL);
INSERT INTO lysobacter.strains VALUES (721, 'YK-280', 'Lysobacter lactamgenus', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия, продуцирующая антибиотики цефабацины. [7, 8]', 'Почва', 'Япония', NULL, NULL, NULL, NULL, NULL, 'Штамм-продуцент цефабацина. [7]', true, '2025-06-28 08:33:23.64213', '2025-06-29 11:51:58.568418', 58, false, NULL);
INSERT INTO lysobacter.strains VALUES (724, '812/17', 'Lysobacter sp.', NULL, 'Неидентифицированный штамм Lysobacter.', 'Неизвестно', 'Неизвестно', NULL, NULL, NULL, NULL, NULL, 'Данные для этого штамма взяты из таблицы ''Гидролиз:'' в OCR.', true, '2025-06-28 08:39:02.105974', '2025-06-29 11:51:58.568418', 60, false, NULL);
INSERT INTO lysobacter.strains VALUES (711, 'SG-8T', 'Lysobacter penaei', NULL, 'Грамотрицательная, аэробная, не обладающая скользящей подвижностью, палочковидная бактерия. Образует светло-желтые колонии. [3, 4]', 'Содержимое кишечника тихоокеанской белой креветки (Penaeus vannamei)', 'Гуанчжоу, Китай', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 695 (GDMCC 1.1817T).
Original notes: Также известен как GDMCC 1.1817T и KACC 21942T. [3, 4]', true, '2025-06-28 08:27:25.420929', '2025-06-29 11:51:58.568418', 47, false, NULL);
INSERT INTO lysobacter.strains VALUES (727, 'R19T', 'Lysobacter niabensis', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия. Образует бледно-желтые колонии. [1, 2]', 'Почва с поля женьшеня', 'Провинция Кёнгидо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Данные для этого штамма взяты из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', true, '2025-06-28 08:41:12.302332', '2025-06-29 11:51:58.568418', 36, false, NULL);
INSERT INTO lysobacter.strains VALUES (40, 'R7T', 'Lysobacter arenosi', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия. Образует бледно-желтые колонии.', 'Неизвестно', 'Неизвестно', NULL, NULL, NULL, NULL, NULL, 'Данные для этого штамма взяты из таблиц ''Сравнение фенотипических характеристик штаммов R7T и R19Т'' и ''Характеристики, отличающие штамм 5-21aT''. Название ''L. arenosi'' используется условно, как в OCR.', true, '2025-06-26 02:45:09.04858', '2025-06-29 11:51:58.568418', 7, false, NULL);
INSERT INTO lysobacter.strains VALUES (729, 'H21R20T', 'Lysobacter sp.', NULL, 'Неидентифицированный штамм Lysobacter.', 'Неизвестно', 'Неизвестно', NULL, NULL, NULL, NULL, NULL, 'Данные для этого штамма взяты из таблицы ''Дифференциальные фенотипические характеристики штамма H21R20T...''. Многие тесты не соответствуют каноническому списку.', true, '2025-06-28 08:41:12.302332', '2025-06-29 11:51:58.568418', 60, false, NULL);
INSERT INTO lysobacter.strains VALUES (730, 'H23M41T', 'Lysobacter sp.', NULL, 'Неидентифицированный штамм Lysobacter.', 'Неизвестно', 'Неизвестно', NULL, NULL, NULL, NULL, NULL, 'Данные для этого штамма взяты из таблицы ''Дифференциальные фенотипические характеристики штамма H21R20T...''. Многие тесты не соответствуют каноническому списку.', true, '2025-06-28 08:41:12.302332', '2025-06-29 11:51:58.568418', 60, false, NULL);
INSERT INTO lysobacter.strains VALUES (731, 'YK-90', 'Lysobacter lactamgenus', NULL, 'Грамотрицательная, аэробная/факультативно-анаэробная, палочковидная бактерия, продуцирующая антибиотики цефабацины. [4, 5]', 'Почва', 'Япония', NULL, NULL, NULL, NULL, NULL, 'Штамм-продуцент цефабацина. [4]', true, '2025-06-28 08:41:12.302332', '2025-06-29 11:51:58.568418', 58, false, NULL);
INSERT INTO lysobacter.strains VALUES (735, 'THG-A13T', 'Lysobacter terrae', NULL, 'Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует желтые колонии. [3, 4]', 'Почва', 'Остров Чеджу, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как KACC 17646T и JCM 30600T. [3, 4]', true, '2025-06-28 08:45:38.897799', '2025-06-29 11:51:58.568418', 43, false, NULL);
INSERT INTO lysobacter.strains VALUES (736, 'THG-DN8.7T', 'Lysobacter terrae', NULL, 'Штамм Lysobacter terrae с некоторыми отличительными биохимическими характеристиками.', 'Почва', 'Остров Чеджу, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Данные для этого штамма взяты из таблицы ''Дифференциальные биохимические и физиологические характеристики штаммов THG-DN8.7T и THG-DN8.3T''.', true, '2025-06-28 08:45:38.897799', '2025-06-29 11:51:58.568418', 43, false, NULL);
INSERT INTO lysobacter.strains VALUES (738, 'KCTC 52206T', 'Lysobacter tongrenensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2]', 'Ризосферная почва риса (Oryza sativa L.)', 'Тунжэнь, провинция Гуйчжоу, Китай', NULL, NULL, NULL, NULL, NULL, 'Также известен как YJ15T и MCCC 1K03268T. [1, 2]', true, '2025-06-28 08:49:51.67424', '2025-06-29 11:51:58.568418', 20, false, NULL);
INSERT INTO lysobacter.strains VALUES (16, 'ATCC 29479', 'Lysobacter antibioticus', 'Strain UASM 3C', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 26 (UASM 3C). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 26 (UASM 3C).
Original notes: Data from Table 9 on page 1. Also known as UASM 3C.', true, '2025-06-26 02:05:40.181', '2025-06-29 11:52:07.11539', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (172, 'KACC 18545', 'Lysobacter tyrosinilyticus', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]', 'Ризосфера капусты, зараженной килой', 'Провинция Канвондо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как JCM 30601T. [3, 4]', true, '2025-06-26 07:25:02.810458', '2025-06-29 11:51:58.568418', 62, false, NULL);
INSERT INTO lysobacter.strains VALUES (741, 'DSM 23410T', 'Lysobacter ximonensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2]', 'Почва', 'Округ Симэн, провинция Юньнань, Китай', NULL, NULL, NULL, NULL, NULL, 'Также известен как KACC 14084T, KCTC 22336T, THG-PC7T, XM415T, CCTCC AB 208043T. [1, 2]', true, '2025-06-28 08:51:38.768394', '2025-06-29 11:51:58.568418', 63, false, NULL);
INSERT INTO lysobacter.strains VALUES (742, 'KCTC 22558T', 'Lysobacter xinjiangensis', NULL, 'Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует желтые, круглые колонии. [1, 2]', 'Почва', 'Синьцзян, Китай', NULL, NULL, NULL, NULL, NULL, 'Также известен как RCML-52T, YIM 77875T и CCTCC AB 2011043T. [1, 2]', true, '2025-06-28 08:53:23.449789', '2025-06-29 11:51:58.568418', 57, false, NULL);
INSERT INTO lysobacter.strains VALUES (743, 'YC6269T', 'Lysobacter yangpyeongensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2]', 'Почва', 'Янпхён, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'Также известен как DSM 17635T и KCTC 12890T. [1, 2]', true, '2025-06-28 08:55:22.522263', '2025-06-29 11:51:58.568418', 1, false, NULL);
INSERT INTO lysobacter.strains VALUES (737, 'UM1T', 'Luteimonas tolerans', NULL, 'Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует желтые, круглые, гладкие колонии. [1, 2] - Edited successfully!', 'Почва', 'Уттар-Прадеш, Индия', NULL, NULL, NULL, NULL, NULL, 'Также известен как DSM 28473T и KCTC 42502T. [1, 2]', true, '2025-06-28 08:47:18.018991', '2025-06-29 11:51:58.568418', 61, false, NULL);
INSERT INTO lysobacter.strains VALUES (714, 'U8T', 'Lysobacter humi', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]', 'Почва', 'Тэджон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 713 (D10T).
Original notes: Также известен как KACC 16548T и JCM 18933T. [3, 4]', true, '2025-06-28 08:31:30.960414', '2025-06-29 11:51:58.568418', 29, false, NULL);
INSERT INTO lysobacter.strains VALUES (79, 'ATCC 29483', 'Lysobacter brunescens', 'Strain UASM 2', 'Strain of Lysobacter brunescens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 84 (UASM 2). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 84 (UASM 2).
Original notes: Data from Table 9 on page 2. Also known as UASM 2.', true, '2025-06-26 02:56:46.609219', '2025-06-29 11:52:07.11539', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (705, 'GW1-59T', 'Lysobacter concretionis', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия, обладающая скользящей подвижностью. Образует желтые колонии. [1, 2]', 'Микробный мат в стоке термальных вод', 'Тэджон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 122 (KCTC 12205T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 119 (DSM 16239T).
Original notes: DUPLICATE of Strain ID 122 (KCTC 12205T).
Original notes: Также известен как Ko07T, DSM 16239T, KCTC 12205T. [1, 2]', true, '2025-06-28 08:22:56.033373', '2025-06-29 11:52:07.11539', 15, false, NULL);
INSERT INTO lysobacter.strains VALUES (179, 'Gsoil 068T', 'Lysobacter soli', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия со скользящей подвижностью. [12, 13]', 'Почва с поля женьшеня', 'Республика Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 703 (DCY21T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 703 (DCY21T).
Original notes: DUPLICATE of Strain ID 703 (DCY21T).
Original notes: Также известен как KCTC 22011T. [12] В OCR GC-содержание указано как 67.0%, в то время как в первоисточнике 65.4%. [12]', true, '2025-06-26 07:33:14.429692', '2025-06-29 11:52:07.11539', 46, false, NULL);
INSERT INTO lysobacter.strains VALUES (689, 'KCTC 22249T', 'Lysobacter oryzae', NULL, 'Грамотрицательная, палочковидная, аэробная бактерия, образующая желтые колонии. [1]', 'Почва из теплицы', 'Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 688 (KACC 14553T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 688 (KACC 14553T).
Original notes: DUPLICATE of Strain ID 688 (KACC 14553T).
Original notes: Также известен как L. oryzae KACC 14553T. Данные для этого штамма были собраны из разных таблиц в предоставленном документе.', true, '2025-06-28 07:50:55.242479', '2025-06-29 11:52:07.11539', 42, false, NULL);
INSERT INTO lysobacter.strains VALUES (169, 'UASM 13B', 'Lysobacter enzymogenes subsp. cookii', 'Strain ATCC 29488', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 145 (ATCC 29488). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 145 (ATCC 29488).
Original notes: DUPLICATE of Strain ID 145 (ATCC 29488).
Original notes: This is the UASM designation for the strain ATCC 29488. All test data is listed under the ATCC 29488 entry.', true, '2025-06-26 07:15:30.110978', '2025-06-29 11:52:07.11539', 22, false, NULL);
INSERT INTO lysobacter.strains VALUES (723, '4284/11T', 'Lysobacter vadosa', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]', 'Морская губка Aplysina aerophoba', 'Средиземное море, Кала-Монтго, Испания', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 710 (LMG 30077T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 710 (LMG 30077T).
Original notes: DUPLICATE of Strain ID 710 (LMG 30077T).
Original notes: Также известен как KMM 9005T и CECT 9427T. [3, 4]', true, '2025-06-28 08:39:02.105974', '2025-06-29 11:52:07.11539', 59, false, NULL);
INSERT INTO lysobacter.strains VALUES (740, 'KMM 9005T', 'Lysobacter vadosa', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [5, 6]', 'Морская губка Aplysina aerophoba', 'Средиземное море, Кала-Монтго, Испания', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 710 (LMG 30077T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 710 (LMG 30077T).
Original notes: DUPLICATE of Strain ID 710 (LMG 30077T).
Original notes: Также известен как LMG 30077T и CECT 9427T. [5, 6]', true, '2025-06-28 08:49:51.67424', '2025-06-29 11:52:07.11539', 59, false, NULL);
INSERT INTO lysobacter.strains VALUES (17, 'ATCC 29480', 'Lysobacter antibioticus', 'Strain UASM L17', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 37 (UASM L17). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 37 (UASM L17).
Original notes: Data from Table 9 on page 1. Also known as UASM L17.', true, '2025-06-26 02:05:40.181', '2025-06-29 11:52:07.11539', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (722, 'CM-3-T8T', 'Lysobacter panacisoli', NULL, 'Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует ярко-желтые колонии. [1, 2]', 'Почва с поля женьшеня', 'Ансон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 692 (CJ29T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 692 (CJ29T).
Original notes: DUPLICATE of Strain ID 692 (CJ29T).
Original notes: Также известен как KACC 17502T и JCM 19212T. [1, 2] Данные для этого штамма взяты из таблицы ''Дифференциальные фенотипические характеристики штамма СМ-3-Т8Т''.', true, '2025-06-28 08:39:02.105974', '2025-06-29 11:52:07.11539', 44, false, NULL);
INSERT INTO lysobacter.strains VALUES (104, 'UASM D', 'Lysobacter brunescens', 'Strain ATCC 29482', 'Type strain of Lysobacter brunescens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 77 (ATCC 29482). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 78 (ATCC 29482T).
Original notes: DUPLICATE of Strain ID 77 (ATCC 29482).
Original notes: Data from Table 9 on page 2. Also known as ATCC 29482.', true, '2025-06-26 03:04:32.422276', '2025-06-29 11:52:07.11539', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (80, 'ATCC 29484', 'Lysobacter brunescens', 'Strain UASM 6', 'Strain of Lysobacter brunescens.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 97 (UASM 6). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 97 (UASM 6).
Original notes: DUPLICATE of Strain ID 97 (UASM 6).
Original notes: Data from Table 9 on page 2. Also known as UASM 6.', true, '2025-06-26 02:56:46.609219', '2025-06-29 11:52:07.11539', 9, false, NULL);
INSERT INTO lysobacter.strains VALUES (709, 'PAGU 1119T', 'Lysobacter capsici', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желто-кремовые колонии. [9, 10]', 'Ризосфера перца (Capsicum annuum L.)', 'Чинджу, провинция Кёнсан-Намдо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 109 (DSM 19286T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 109 (DSM 19286T).
Original notes: DUPLICATE of Strain ID 109 (DSM 19286T).
Original notes: Также известен как YC5194T, KCTC 12891T, DSM 19286T. [9, 10]', true, '2025-06-28 08:22:56.033373', '2025-06-29 11:52:07.11539', 12, false, NULL);
INSERT INTO lysobacter.strains VALUES (144, 'ATCC 29487T', 'Lysobacter enzymogenes', 'Type strain of Lysobacter enzymogenes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: This is the ATCC designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:52:07.11539', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (146, 'BCRC 11654T', 'Lysobacter enzymogenes', 'Type strain of Lysobacter enzymogenes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: This is the BCRC designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:52:07.11539', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (147, 'KACC 10127T', 'Lysobacter enzymogenes', 'Type strain of Lysobacter enzymogenes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: DUPLICATE of Strain ID 139 (DSM 2043T).
Original notes: This is a KACC designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:52:07.11539', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (744, 'KACC 11407T', 'Lysobacter daejeonensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]', 'Микробный мат в стоке термальных вод', 'Тэджон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 133 (IMMIB APB-9T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 133 (IMMIB APB-9T).
Original notes: DUPLICATE of Strain ID 133 (IMMIB APB-9T).
Original notes: Также известен как DSM 18482T. [3, 4]', true, '2025-06-28 08:55:22.522263', '2025-06-29 11:52:07.11539', 17, false, NULL);
INSERT INTO lysobacter.strains VALUES (725, 'HX-5-24T', 'Lysobacter dokdonensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует бледно-желтые колонии. [5, 6]', 'Почва', 'Остров Токто, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 137 (KCTC 12822T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 135 (DSM 17958T).
Original notes: DUPLICATE of Strain ID 137 (KCTC 12822T).
Original notes: Также известен как KCTC 12822T и DSM 17958T. [5, 6]', true, '2025-06-28 08:39:02.105974', '2025-06-29 11:52:07.11539', 19, false, NULL);
INSERT INTO lysobacter.strains VALUES (733, 'KVB24T', 'Lysobacter hankyongensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желто-оранжевые колонии. [3, 4]', 'Морская вода', 'Желтое море, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 136 (KACC 18711T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 136 (KACC 18711T).
Original notes: DUPLICATE of Strain ID 136 (KACC 18711T).
Original notes: Также известен как KACC 18711T и NBRC 111306T. [3, 4]', true, '2025-06-28 08:43:15.469519', '2025-06-29 11:52:07.11539', 28, false, NULL);
INSERT INTO lysobacter.strains VALUES (166, 'UASM AL-1', 'Lysobacter enzymogenes', 'Strain ATCC 27796', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 142 (ATCC 27796). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 142 (ATCC 27796).
Original notes: DUPLICATE of Strain ID 142 (ATCC 27796).
Original notes: This is the UASM designation for the strain ATCC 27796. All test data is listed under the ATCC 27796 entry.', true, '2025-06-26 07:07:28.925588', '2025-06-29 11:52:07.11539', 21, false, NULL);
INSERT INTO lysobacter.strains VALUES (178, 'DSM6980T', 'Lysobacter gummosus', 'Type strain of Lysobacter gummosus', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: This is the DSM designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.', true, '2025-06-26 07:33:14.429692', '2025-06-29 11:52:07.11539', 27, false, NULL);
INSERT INTO lysobacter.strains VALUES (180, 'KACC 11386T', 'Lysobacter gummosus', 'Type strain of Lysobacter gummosus', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: This is the KACC designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.', true, '2025-06-26 07:33:14.429692', '2025-06-29 11:52:07.11539', 27, false, NULL);
INSERT INTO lysobacter.strains VALUES (181, 'KCTC 12132T', 'Lysobacter gummosus', 'Type strain of Lysobacter gummosus', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: This is the KCTC designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.', true, '2025-06-26 07:33:14.429692', '2025-06-29 11:52:07.11539', 27, false, NULL);
INSERT INTO lysobacter.strains VALUES (182, 'LMG 8763T', 'Lysobacter gummosus', 'Type strain of Lysobacter gummosus', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: This is the LMG designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.', true, '2025-06-26 07:33:14.429692', '2025-06-29 11:52:07.11539', 27, false, NULL);
INSERT INTO lysobacter.strains VALUES (183, 'UASM 402', 'Lysobacter gummosus', 'Type strain of Lysobacter gummosus', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: DUPLICATE of Strain ID 176 (ATCC 29489T).
Original notes: This is the UASM designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.', true, '2025-06-26 07:33:14.429692', '2025-06-29 11:52:07.11539', 27, false, NULL);
INSERT INTO lysobacter.strains VALUES (726, 'CHu40b-3-1', 'Lysobacter solanacearum', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует бледно-желтые колонии. [7, 8]', 'Почва', 'Провинция Кёнгидо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 701 (T20R-70T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 701 (T20R-70T).
Original notes: DUPLICATE of Strain ID 701 (T20R-70T).
Original notes: Также известен как KACC 18656T и JCM 32178T. [7, 8]', true, '2025-06-28 08:39:02.105974', '2025-06-29 11:52:07.11539', 53, false, NULL);
INSERT INTO lysobacter.strains VALUES (732, '2-5T', 'Lysobacter koreensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует кремовые колонии. [1, 2]', 'Почва с поля женьшеня', 'Пхочхон, провинция Кёнгидо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 193 (KCTC 12204T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 193 (KCTC 12204T).
Original notes: DUPLICATE of Strain ID 193 (KCTC 12204T).
Original notes: Также известен как KCTC 12204T и DSM 17633T. [1, 2]', true, '2025-06-28 08:43:15.469519', '2025-06-29 11:52:07.11539', 30, false, NULL);
INSERT INTO lysobacter.strains VALUES (717, 'TLK-CK17T', 'Lysobacter maris', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия. Образует абрикосовые колонии. [1, 2]', 'Компост из коровьего навоза', 'Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 197 (KCTC 42381T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 198 (NBRC 110750T).
Original notes: DUPLICATE of Strain ID 197 (KCTC 42381T).
Original notes: Также известен как KCTC 42381T и NBRC 110750T. [1, 2]', true, '2025-06-28 08:33:23.64213', '2025-06-29 11:52:07.11539', 33, false, NULL);
INSERT INTO lysobacter.strains VALUES (203, 'DSM 18244T', 'Lysobacter niabensis', 'Type strain of Lysobacter niabensis', 'Type strain of Lysobacter niabensis, isolated from greenhouse soil. Also known as GH34-4T and KACC 11587T.', 'greenhouse soil', 'Gyeonggi Province, South Korea', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.', true, '2025-06-26 07:57:19.568773', '2025-06-29 11:52:07.11539', 36, false, NULL);
INSERT INTO lysobacter.strains VALUES (204, 'GH34-4T', 'Lysobacter niabensis', 'Type strain of Lysobacter niabensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: This is a designation for the type strain DSM 18244T. All test data is listed under the DSM 18244T entry.', true, '2025-06-26 07:57:19.568773', '2025-06-29 11:52:07.11539', 36, false, NULL);
INSERT INTO lysobacter.strains VALUES (205, 'KACC 11587T', 'Lysobacter niabensis', 'Type strain of Lysobacter niabensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: This is the KACC designation for the type strain DSM 18244T. All test data is listed under the DSM 18244T entry.', true, '2025-06-26 07:57:19.568773', '2025-06-29 11:52:07.11539', 36, false, NULL);
INSERT INTO lysobacter.strains VALUES (207, 'GH41-7T', 'Lysobacter niastensis', 'Type strain of Lysobacter niastensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: This is a designation for the type strain DSM 18481T. All test data is listed under the DSM 18481T entry.', true, '2025-06-26 07:59:40.869851', '2025-06-29 11:52:07.11539', 37, false, NULL);
INSERT INTO lysobacter.strains VALUES (208, 'KACC 11588T', 'Lysobacter niastensis', 'Type strain of Lysobacter niastensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: This is a KACC designation for the type strain DSM 18481T. All test data is listed under the DSM 18481T entry.', true, '2025-06-26 07:59:40.869851', '2025-06-29 11:52:07.11539', 37, false, NULL);
INSERT INTO lysobacter.strains VALUES (209, 'KACC 22750T', 'Lysobacter niastensis', 'Type strain of Lysobacter niastensis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: This is a KACC designation for the type strain DSM 18481T. All test data is listed under the DSM 18481T entry.', true, '2025-06-26 07:59:40.869851', '2025-06-29 11:52:07.11539', 37, false, NULL);
INSERT INTO lysobacter.strains VALUES (712, 'THG-SKA3T', 'Lysobacter mobilis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует белые колонии. [1, 2]', 'Почва из теплицы', 'Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: Также известен как KACC 11588T и LMG 24310T. [1, 2]', true, '2025-06-28 08:31:30.960414', '2025-06-29 11:52:07.11539', 35, false, NULL);
INSERT INTO lysobacter.strains VALUES (734, 'GH19-3T', 'Lysobacter niabensis', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2]', 'Почва из теплицы', 'Провинция Кёнгидо, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: DUPLICATE of Strain ID 206 (DSM 18481T).
Original notes: Также известен как KACC 11587T и DSM 18481T. [1, 2]', true, '2025-06-28 08:45:38.897799', '2025-06-29 11:52:07.11539', 36, false, NULL);
INSERT INTO lysobacter.strains VALUES (18, 'ATCC 29481', 'Lysobacter antibioticus', 'Strain UASM 4045', 'Strain of Lysobacter antibioticus with specific biochemical reactions.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 27 (UASM 4045). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 27 (UASM 4045).
Original notes: Data from Table 9 on page 1. Also known as UASM 4045.', true, '2025-06-26 02:05:40.181', '2025-06-29 11:52:07.11539', 6, false, NULL);
INSERT INTO lysobacter.strains VALUES (119, 'DSM 16239T', 'Lysobacter concretionis', 'Type strain of Lysobacter concretionis', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 122 (KCTC 12205T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 122 (KCTC 12205T).
Original notes: This is the DSM designation for the type strain K007T. All test data is listed under the K007T entry.', true, '2025-06-26 06:27:04.328668', '2025-06-29 11:52:07.11539', 15, false, NULL);
INSERT INTO lysobacter.strains VALUES (695, 'GDMCC 1.1817T', 'Lysobacter penaei', NULL, 'Грамотрицательная, аэробная, не обладающая скользящей подвижностью, палочковидная бактерия. Образует светло-желтые колонии. [1, 2]', 'Содержимое кишечника тихоокеанской белой креветки (Penaeus vannamei)', 'Гуанчжоу, Китай', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 711 (SG-8T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 711 (SG-8T).
Original notes: Также известен как SG-8T и KACC 21942T. [1, 2]', true, '2025-06-28 07:58:48.567273', '2025-06-29 11:52:07.11539', 47, false, NULL);
INSERT INTO lysobacter.strains VALUES (713, 'D10T', 'Lysobacter humi', NULL, 'Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]', 'Почва', 'Тэджон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 714 (U8T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 714 (U8T).
Original notes: Также известен как KACC 16548T и JCM 18933T. [3, 4]', true, '2025-06-28 08:31:30.960414', '2025-06-29 11:52:07.11539', 29, false, NULL);
INSERT INTO lysobacter.strains VALUES (716, 'ZS60T', 'Lysobacter humi', NULL, 'Грамотрицательная, аэробная, палочковидная бактерия. Образует желтые колонии. [3, 4]', 'Почва', 'Тэджон, Южная Корея', NULL, NULL, NULL, NULL, NULL, 'DUPLICATE of Strain ID 714 (U8T). See master record for consolidated data.
Original notes: DUPLICATE of Strain ID 714 (U8T).
Original notes: DUPLICATE of Strain ID 713 (D10T).
Original notes: Также известен как KACC 16548T и JCM 18933T. [3, 4]', true, '2025-06-28 08:31:30.960414', '2025-06-29 11:52:07.11539', 29, false, NULL);


--
-- Data for Name: strain_collections; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.strain_collections VALUES (26, 5, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (37, 6, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (27, 7, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (27, 8, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (84, 9, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (84, 10, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (692, 11, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (692, 12, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (176, 13, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (176, 14, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (176, 15, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (176, 16, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (176, 17, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (176, 18, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (176, 19, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (77, 20, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (77, 21, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (97, 22, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (97, 23, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (109, 24, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (109, 25, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (139, 26, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (139, 27, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (139, 28, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (139, 29, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (139, 30, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (139, 31, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (125, 32, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (125, 33, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (125, 34, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (133, 35, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (133, 36, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (137, 37, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (137, 38, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (136, 39, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (136, 40, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (142, 41, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (122, 42, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (122, 43, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (703, 44, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (703, 45, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (703, 46, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (701, 47, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (701, 48, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (145, 49, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (193, 50, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (193, 51, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (197, 52, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (197, 53, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (206, 54, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (206, 55, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (206, 56, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (206, 57, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (206, 58, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (206, 59, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (711, 60, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (688, 61, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (688, 62, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (710, 63, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (710, 64, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (713, 65, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (713, 66, false, NULL, '2025-06-29 10:43:37.618007');
INSERT INTO lysobacter.strain_collections VALUES (16, 5, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (17, 6, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (79, 9, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (79, 10, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (78, 20, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (78, 21, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (126, 32, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (126, 33, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (126, 34, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (135, 37, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (135, 38, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (198, 52, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (198, 53, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (18, 7, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (18, 8, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (119, 42, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (119, 43, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (695, 60, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (714, 65, false, NULL, '2025-06-29 11:44:13.145438');
INSERT INTO lysobacter.strain_collections VALUES (714, 66, false, NULL, '2025-06-29 11:44:13.145438');


--
-- Data for Name: test_categories; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.test_categories VALUES (4, 'biochemical_breakdown', 'Biochemical_breakdown', 4, '2025-06-26 01:18:03.824687');
INSERT INTO lysobacter.test_categories VALUES (1, 'morphological', 'Morphological', 1, '2025-06-26 01:18:03.824687');
INSERT INTO lysobacter.test_categories VALUES (2, 'physiological', 'Physiological', 2, '2025-06-26 01:18:03.824687');
INSERT INTO lysobacter.test_categories VALUES (5, 'biochemical_utilization', 'Biochemical_utilization', 5, '2025-06-26 01:18:03.824687');
INSERT INTO lysobacter.test_categories VALUES (3, 'biochemical_enzymes', 'Biochemical_enzymes', 3, '2025-06-26 01:18:03.824687');
INSERT INTO lysobacter.test_categories VALUES (14, 'biochemical_other', 'Other_biochemical', 6, '2025-06-27 09:22:49.359803');


--
-- Data for Name: tests; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.tests VALUES (5, 2, 'Солеустойчивость', 'salt_tolerance', 'boolean', 'Солеустойчивость', NULL, true, 3, '2025-06-26 01:18:03.834738');
INSERT INTO lysobacter.tests VALUES (6, 3, 'Протеолитическая активность', 'proteolytic_activity', 'boolean', 'Протеолитическая активность', NULL, true, 1, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (7, 3, 'Оксидаза', 'oxidase', 'boolean', 'Оксидаза', NULL, true, 2, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (9, 3, 'Уреаза', 'urease', 'boolean', 'Уреаза', NULL, true, 4, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (10, 3, 'Восстановление нитрата', 'nitrate_reduction', 'boolean', 'Восстановление нитрата', NULL, true, 5, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (11, 3, 'Продукция индола', 'indole_production', 'boolean', 'Продукция индола', NULL, true, 6, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (12, 3, 'Фосфатаза', 'phosphatase', 'boolean', 'Фосфатаза', NULL, true, 7, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (13, 3, 'Эстераза', 'esterase', 'boolean', 'Эстераза', NULL, true, 8, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (16, 4, 'Расщепление крахмала', 'starch', 'boolean', 'Расщепление крахмала', NULL, true, 1, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (17, 4, 'Эскулин', 'aesculin', 'boolean', 'Эскулин', NULL, true, 2, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (18, 4, 'Желатин', 'gelatin', 'boolean', 'Желатин', NULL, true, 3, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (19, 4, 'Казеин', 'casein', 'boolean', 'Казеин', NULL, true, 4, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (20, 4, 'Tween 20', 'tween_20', 'boolean', 'Tween 20', NULL, true, 5, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (21, 4, 'Tween 40', 'tween_40', 'boolean', 'Tween 40', NULL, true, 6, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (22, 4, 'Tween 60', 'tween_60', 'boolean', 'Tween 60', NULL, true, 7, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (23, 4, 'Хитин', 'chitin', 'boolean', 'Хитин', NULL, true, 8, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (24, 4, 'Целлюлоза', 'cellulose', 'boolean', 'Целлюлоза', NULL, true, 9, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (25, 4, 'Аргинин-гидролаза', 'arginine_hydrolase', 'boolean', 'Аргинин-гидролаза', NULL, true, 10, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (26, 4, 'Пектин', 'pectin', 'boolean', 'Пектин', NULL, true, 11, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (27, 4, 'Ферментация глюкозы', 'glucose_fermentation', 'boolean', 'Ферментация глюкозы', NULL, true, 12, '2025-06-26 01:18:03.841146');
INSERT INTO lysobacter.tests VALUES (28, 5, 'Мальтоза', 'maltose', 'boolean', 'Мальтоза', NULL, true, 1, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (29, 5, 'Лактоза', 'lactose', 'boolean', 'Лактоза', NULL, true, 2, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (30, 5, 'Фруктоза', 'fructose', 'boolean', 'Фруктоза', NULL, true, 3, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (31, 5, 'Арабиноза', 'arabinose', 'boolean', 'Арабиноза', NULL, true, 4, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (32, 5, 'Манноза', 'mannose', 'boolean', 'Манноза', NULL, true, 5, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (33, 5, 'Трегалоза', 'trehalose', 'boolean', 'Трегалоза', NULL, true, 6, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (34, 5, 'Сорбит', 'sorbitol', 'boolean', 'Сорбит', NULL, true, 7, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (35, 5, 'Маннит', 'mannitol', 'boolean', 'Маннит', NULL, true, 8, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (36, 5, 'Декстроза', 'dextrose', 'boolean', 'Декстроза', NULL, true, 9, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (37, 5, 'Ксиллоза', 'xylose', 'boolean', 'Ксиллоза', NULL, true, 10, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (38, 5, 'Галактоза', 'galactose', 'boolean', 'Галактоза', NULL, true, 11, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (39, 5, 'Дульцитол', 'dulcitol', 'boolean', 'Дульцитол', NULL, true, 12, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (40, 5, 'Целлобиоза', 'cellobiose', 'boolean', 'Целлобиоза', NULL, true, 13, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (41, 5, 'Сахароза', 'sucrose', 'boolean', 'Сахароза', NULL, true, 14, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (42, 5, 'Раффиноза', 'raffinose', 'boolean', 'Раффиноза', NULL, true, 15, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (43, 5, 'Инозитол', 'inositol', 'boolean', 'Инозитол', NULL, true, 16, '2025-06-26 01:18:03.844786');
INSERT INTO lysobacter.tests VALUES (14, 14, 'Целлюлазная активность', 'cellulase_activity', 'boolean', 'Целлюлазная активность', NULL, true, 9, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (15, 14, 'Солюбилизация фосфатов', 'phosphate_solubilization', 'boolean', 'Солюбилизация фосфатов', NULL, true, 10, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (44, 14, 'GC-состав', 'gc_content', 'numeric', 'GC-состав', '%', true, 1, '2025-06-26 01:18:03.848476');
INSERT INTO lysobacter.tests VALUES (45, 3, 'Cysteine Arylamidase', 'cysteine_arylamidase', 'boolean', 'Cysteine arylamidase enzyme activity', NULL, false, 11, '2025-06-26 01:42:11.441169');
INSERT INTO lysobacter.tests VALUES (46, 3, 'Trypsin', 'trypsin', 'boolean', 'Trypsin enzyme activity', NULL, false, 12, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (47, 3, 'Chymotrypsin', 'chymotrypsin', 'boolean', 'Chymotrypsin enzyme activity', NULL, false, 13, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (48, 5, 'Citrate Utilization', 'citrate_utilization', 'boolean', 'Ability to utilize citrate', NULL, false, 17, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (49, 4, 'Tween 80 Breakdown', 'tween_80', 'boolean', 'Ability to break down Tween 80', NULL, false, 13, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (51, 2, 'Growth at pH 9.5', 'ph_growth_9.5', 'boolean', 'Growth at pH 9.5', NULL, false, 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (52, 2, 'Growth at pH 10', 'ph_growth_10', 'boolean', 'Growth at pH 10', NULL, false, 5, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (53, 2, 'Growth at pH 11', 'ph_growth_11', 'boolean', 'Growth at pH 11', NULL, false, 6, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (3, 2, 'Temperature', 'temperature', 'numeric', 'Growth temperature range', '°C', false, 1, '2025-06-26 01:18:03.831533');
INSERT INTO lysobacter.tests VALUES (4, 2, 'pH Level', 'ph_level', 'numeric', 'pH range for growth', 'pH', false, 2, '2025-06-26 01:18:03.833123');
INSERT INTO lysobacter.tests VALUES (50, 14, 'Genome Size', 'genome_size', 'numeric', 'Genome size (Mb)', 'Mb', false, 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (1, 1, 'Спорообразование', 'spore_formation', 'boolean', 'Спорообразование', NULL, true, 1, '2025-06-26 01:18:03.826907');
INSERT INTO lysobacter.tests VALUES (2, 1, 'Подвижность', 'motility', 'boolean', 'Подвижность', NULL, true, 2, '2025-06-26 01:18:03.826907');
INSERT INTO lysobacter.tests VALUES (76, 2, 'Температура (мин)', 'temperature_min', 'numeric', 'Температура (мин)', '°C', true, 0, '2025-06-27 09:22:49.359803');
INSERT INTO lysobacter.tests VALUES (77, 2, 'Температура (опт)', 'temperature_opt', 'numeric', 'Температура (опт)', '°C', true, 0, '2025-06-27 09:22:49.359803');
INSERT INTO lysobacter.tests VALUES (78, 2, 'Температура (макс)', 'temperature_max', 'numeric', 'Температура (макс)', '°C', true, 0, '2025-06-27 09:22:49.359803');
INSERT INTO lysobacter.tests VALUES (79, 2, 'pH (мин)', 'ph_min', 'numeric', 'pH (мин)', NULL, true, 0, '2025-06-27 09:22:49.359803');
INSERT INTO lysobacter.tests VALUES (80, 2, 'pH (опт)', 'ph_opt', 'numeric', 'pH (опт)', NULL, true, 0, '2025-06-27 09:22:49.359803');
INSERT INTO lysobacter.tests VALUES (81, 2, 'pH (макс)', 'ph_max', 'numeric', 'pH (макс)', NULL, true, 0, '2025-06-27 09:22:49.359803');
INSERT INTO lysobacter.tests VALUES (8, 3, 'Каталаза', 'catalase', 'boolean', 'Каталаза', NULL, true, 3, '2025-06-26 01:18:03.837221');
INSERT INTO lysobacter.tests VALUES (54, 2, 'Growth at 37°C', 'temp_growth_37', 'boolean', 'Growth at 37°C', NULL, false, 7, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (55, 2, 'Growth at 42°C', 'temp_growth_42', 'boolean', 'Growth at 42°C', NULL, false, 8, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (56, 5, 'Glucose Assimilation', 'glucose_assimilation', 'boolean', 'Assimilation of glucose', NULL, false, 18, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (57, 5, 'Mannose Assimilation', 'mannose_assimilation', 'boolean', 'Assimilation of mannose', NULL, false, 19, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.tests VALUES (58, 4, 'Acid Production (Oxidative OF Test)', 'acid_production_oxidative', 'boolean', 'Oxidative acid production in OF test', NULL, false, 14, '2025-06-26 02:04:12.258436');
INSERT INTO lysobacter.tests VALUES (59, 1, 'Cell Size', 'cell_size', 'text', 'Cell size (length x width)', 'μm', false, 3, '2025-06-26 02:04:24.297166');
INSERT INTO lysobacter.tests VALUES (60, 4, 'Acid Production from Glycerol', 'glycerol', 'boolean', 'Acid production from glycerol substrate', NULL, false, 15, '2025-06-26 02:08:14.866174');
INSERT INTO lysobacter.tests VALUES (61, 1, 'Colony Color', 'colony_color', 'text', 'Colony color description', NULL, false, 4, '2025-06-26 02:43:44.634201');
INSERT INTO lysobacter.tests VALUES (62, 3, 'Alpha-glucosidase', 'alpha_glucosidase', 'boolean', 'Alpha-glucosidase enzyme activity', NULL, false, 14, '2025-06-26 02:43:44.634201');
INSERT INTO lysobacter.tests VALUES (63, 3, 'Beta-glucosidase', 'beta_glucosidase', 'boolean', 'Beta-glucosidase enzyme activity', NULL, false, 15, '2025-06-26 02:43:44.634201');
INSERT INTO lysobacter.tests VALUES (64, 3, 'Galactosidase', 'galactosidase', 'boolean', 'Galactosidase enzyme activity', NULL, false, 16, '2025-06-26 02:43:44.634201');
INSERT INTO lysobacter.tests VALUES (65, 3, 'N-acetyl-beta-glucosaminidase', 'n_acetyl_beta_glucosaminidase', 'boolean', 'N-acetyl-beta-glucosaminidase activity', NULL, false, 17, '2025-06-26 02:43:44.634201');
INSERT INTO lysobacter.tests VALUES (66, 3, 'Leucine arylamidase', 'leucine_arylamidase', 'boolean', 'Leucine arylamidase activity', NULL, false, 18, '2025-06-26 02:43:44.634201');
INSERT INTO lysobacter.tests VALUES (67, 3, 'Valine arylamidase', 'valine_arylamidase', 'boolean', 'Valine arylamidase activity', NULL, false, 19, '2025-06-26 02:43:44.634201');
INSERT INTO lysobacter.tests VALUES (68, 3, 'Lipase (C14)', 'lipase_c14', 'boolean', 'Lipase C14 activity', NULL, false, 20, '2025-06-26 02:50:46.646217');
INSERT INTO lysobacter.tests VALUES (69, 5, 'N-Acetylglucosamine Assimilation', 'n_acetyl_glucosamine', 'boolean', 'Assimilation of N-acetylglucosamine', NULL, false, 30, '2025-06-26 02:50:46.646217');
INSERT INTO lysobacter.tests VALUES (70, 3, 'Beta-galactosidase', 'beta_galactosidase', 'boolean', 'β-galactosidase enzyme activity', NULL, false, 21, '2025-06-26 03:04:09.844891');
INSERT INTO lysobacter.tests VALUES (72, 4, 'Tyrosine hydrolysis', 'tyrosine_hydrolysis', 'boolean', 'Hydrolysis of tyrosine', NULL, false, 25, '2025-06-26 03:04:09.844891');
INSERT INTO lysobacter.tests VALUES (71, 14, 'Ubiquinone type', 'ubiquinone_type', 'text', 'Major ubiquinone type', NULL, false, 5, '2025-06-26 03:04:09.844891');


--
-- Data for Name: test_values; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.test_values VALUES (1, 1, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (2, 1, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (3, 1, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (4, 1, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (5, 2, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (6, 2, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (7, 2, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (8, 2, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (13, 6, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (14, 6, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (15, 6, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (16, 6, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (17, 7, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (18, 7, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (19, 7, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (20, 7, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (21, 8, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (22, 8, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (23, 8, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (24, 8, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (25, 9, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (26, 9, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (27, 9, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (28, 9, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (29, 10, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (30, 10, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (31, 10, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (32, 10, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (33, 11, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (34, 11, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (35, 11, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (36, 11, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (37, 12, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (38, 12, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (39, 12, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (40, 12, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (41, 13, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (42, 13, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (43, 13, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (44, 13, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (45, 14, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (46, 14, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (47, 14, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (48, 14, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (49, 15, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (50, 15, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (51, 15, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (52, 15, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (53, 16, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (54, 16, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (55, 16, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (56, 16, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (57, 17, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (58, 17, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (59, 17, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (60, 17, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (61, 18, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (62, 18, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (63, 18, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (64, 18, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (65, 19, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (66, 19, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (67, 19, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (68, 19, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (69, 20, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (70, 20, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (71, 20, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (72, 20, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (73, 21, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (74, 21, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (75, 21, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (76, 21, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (77, 22, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (78, 22, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (79, 22, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (80, 22, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (81, 23, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (82, 23, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (83, 23, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (84, 23, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (85, 24, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (86, 24, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (87, 24, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (88, 24, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (89, 25, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (90, 25, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (91, 25, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (92, 25, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (93, 26, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (94, 26, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (95, 26, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (96, 26, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (97, 27, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (98, 27, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (99, 27, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (100, 27, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (101, 28, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (102, 28, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (103, 28, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (104, 28, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (105, 29, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (106, 29, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (107, 29, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (108, 29, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (109, 30, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (110, 30, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (111, 30, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (112, 30, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (113, 31, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (114, 31, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (115, 31, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (116, 31, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (117, 32, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (118, 32, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (119, 32, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (120, 32, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (121, 33, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (122, 33, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (123, 33, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (124, 33, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (125, 34, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (126, 34, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (127, 34, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (128, 34, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (129, 35, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (130, 35, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (131, 35, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (132, 35, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (133, 36, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (134, 36, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (135, 36, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (136, 36, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (137, 37, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (138, 37, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (139, 37, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (140, 37, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (141, 38, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (142, 38, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (143, 38, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (144, 38, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (145, 39, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (146, 39, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (147, 39, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (148, 39, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (149, 40, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (150, 40, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (151, 40, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (152, 40, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (153, 41, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (154, 41, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (155, 41, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (156, 41, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (157, 42, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (158, 42, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (159, 42, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (160, 42, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (161, 43, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (162, 43, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (163, 43, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (164, 43, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:18:03.850216');
INSERT INTO lysobacter.test_values VALUES (165, 45, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:42:20.613838');
INSERT INTO lysobacter.test_values VALUES (166, 45, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (167, 45, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (168, 45, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (169, 46, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (170, 46, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (171, 46, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (172, 46, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (173, 47, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (174, 47, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (175, 47, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (176, 47, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (177, 48, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (178, 48, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (179, 48, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (180, 48, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (181, 49, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (182, 49, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (183, 49, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (184, 49, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (185, 51, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (186, 51, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (187, 51, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (188, 51, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (189, 52, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (190, 52, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (191, 52, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (192, 52, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (193, 53, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (194, 53, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (195, 53, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (196, 53, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (197, 54, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (198, 54, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (199, 54, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (200, 54, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (201, 55, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (202, 55, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (203, 55, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (204, 55, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (205, 56, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (206, 56, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (207, 56, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (208, 56, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (209, 57, '+', 'Positive', 'Positive result', 1, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (210, 57, '-', 'Negative', 'Negative result', 2, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (211, 57, '+/-', 'Intermediate', 'Intermediate/Variable result', 3, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (212, 57, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 01:43:15.305562');
INSERT INTO lysobacter.test_values VALUES (214, 58, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:04:50.109458');
INSERT INTO lysobacter.test_values VALUES (215, 58, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:05:02.097223');
INSERT INTO lysobacter.test_values VALUES (216, 58, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:05:13.052107');
INSERT INTO lysobacter.test_values VALUES (217, 58, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 02:05:25.423318');
INSERT INTO lysobacter.test_values VALUES (218, 60, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:08:31.853531');
INSERT INTO lysobacter.test_values VALUES (219, 60, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:08:31.853531');
INSERT INTO lysobacter.test_values VALUES (220, 60, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:08:31.853531');
INSERT INTO lysobacter.test_values VALUES (221, 60, 'n.d.', 'No Data', 'No data available', 4, '2025-06-26 02:08:31.853531');
INSERT INTO lysobacter.test_values VALUES (228, 62, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (229, 63, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (230, 64, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (231, 65, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (232, 66, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (233, 67, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (234, 62, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (235, 63, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (236, 64, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (237, 65, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (238, 66, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (239, 67, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (240, 62, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (241, 63, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (242, 64, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (243, 65, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (244, 66, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (245, 67, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (246, 62, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (247, 63, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (248, 64, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (249, 65, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (250, 66, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (251, 67, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 02:44:58.911492');
INSERT INTO lysobacter.test_values VALUES (252, 68, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:51:06.481098');
INSERT INTO lysobacter.test_values VALUES (253, 69, '+', 'Positive', 'Positive result', 1, '2025-06-26 02:51:06.481098');
INSERT INTO lysobacter.test_values VALUES (254, 68, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:51:06.481098');
INSERT INTO lysobacter.test_values VALUES (255, 69, '-', 'Negative', 'Negative result', 2, '2025-06-26 02:51:06.481098');
INSERT INTO lysobacter.test_values VALUES (256, 68, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:51:06.481098');
INSERT INTO lysobacter.test_values VALUES (257, 69, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 02:51:06.481098');
INSERT INTO lysobacter.test_values VALUES (258, 68, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 02:51:06.481098');
INSERT INTO lysobacter.test_values VALUES (259, 69, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 02:51:06.481098');
INSERT INTO lysobacter.test_values VALUES (260, 70, '+', 'Positive', 'Positive result', 1, '2025-06-26 03:04:22.409002');
INSERT INTO lysobacter.test_values VALUES (261, 72, '+', 'Positive', 'Positive result', 1, '2025-06-26 03:04:22.409002');
INSERT INTO lysobacter.test_values VALUES (262, 70, '-', 'Negative', 'Negative result', 2, '2025-06-26 03:04:22.409002');
INSERT INTO lysobacter.test_values VALUES (263, 72, '-', 'Negative', 'Negative result', 2, '2025-06-26 03:04:22.409002');
INSERT INTO lysobacter.test_values VALUES (264, 70, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 03:04:22.409002');
INSERT INTO lysobacter.test_values VALUES (265, 72, '+/-', 'Intermediate', 'Intermediate result', 3, '2025-06-26 03:04:22.409002');
INSERT INTO lysobacter.test_values VALUES (266, 70, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 03:04:22.409002');
INSERT INTO lysobacter.test_values VALUES (267, 72, 'n.d.', 'No Data', 'No data', 4, '2025-06-26 03:04:22.409002');
INSERT INTO lysobacter.test_values VALUES (268, 5, '+', 'Positive', NULL, 1, '2025-06-27 09:52:34.91856');
INSERT INTO lysobacter.test_values VALUES (269, 5, '-', 'Negative', NULL, 2, '2025-06-27 09:52:34.91856');
INSERT INTO lysobacter.test_values VALUES (270, 5, '+/-', 'Intermediate', NULL, 3, '2025-06-27 09:52:34.91856');
INSERT INTO lysobacter.test_values VALUES (271, 5, 'n.d.', 'No Data', NULL, 4, '2025-06-27 09:52:34.91856');


--
-- Data for Name: test_results_boolean; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.test_results_boolean VALUES (37, 2, 2, 5, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (38, 2, 19, 65, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (39, 4, 2, 5, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (3379, 684, 2, 5, 'Источник: Margesin et al. (2018). [4]', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (40, 4, 19, 65, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (3380, 684, 5, 269, 'Проверено при 2-3% NaCl.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3381, 684, 7, 17, 'Источник: Margesin et al. (2018). [4]', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (97, 16, 27, 97, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (98, 16, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (41, 4, 7, 17, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (42, 5, 7, 17, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (43, 5, 17, 57, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (44, 5, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (59, 10, 2, 5, NULL, 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (45, 5, 10, 29, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (46, 5, 18, 61, NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (100, 17, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (101, 17, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (60, 10, 9, 25, 'From ''Гидролиз мочевины''', 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (515, 77, 2, 5, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (516, 77, 8, 21, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (517, 77, 7, 17, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (518, 77, 10, 30, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (614, 99, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (724, 114, 8, 21, NULL, 'high', NULL, '2025-06-26 06:21:59.494506', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_boolean VALUES (725, 114, 7, 17, NULL, 'high', NULL, '2025-06-26 06:21:59.494506', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_boolean VALUES (726, 114, 9, 25, NULL, 'high', NULL, '2025-06-26 06:21:59.494506', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_boolean VALUES (727, 114, 33, 121, 'Assimilation test', 'high', NULL, '2025-06-26 06:21:59.494506', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_boolean VALUES (3382, 684, 8, 21, 'Источник: Margesin et al. (2018). [4]', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3383, 684, 9, 26, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3384, 684, 10, 30, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3385, 684, 11, 34, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3386, 684, 12, 37, 'Положителен на щелочную и кислую фосфатазу.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3387, 684, 13, 41, 'Положителен на эстеразу липазу (C8).', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3388, 684, 19, 66, 'Определено по гидролизу обезжиренного молока (протеаза).', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3389, 684, 25, 90, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3390, 684, 27, 98, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (61, 10, 18, 61, 'Inferred from the note: ''положительны на гидролиз желатина''', 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (62, 10, 13, 41, 'Inferred from the note: ''положительны на ... эстеразу (С4), эстеразу липазу (C8)''', 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (63, 11, 2, 6, 'From ''Скользящая подвижность''', 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (64, 11, 7, 17, NULL, 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (65, 11, 18, 61, NULL, 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (66, 11, 19, 65, NULL, 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (67, 11, 10, 29, NULL, 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (68, 12, 10, 29, NULL, 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (47, 5, 32, 117, 'Assimilation of D-Mannose', 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_boolean VALUES (679, 107, 8, 21, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (680, 107, 7, 18, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (681, 107, 10, 29, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (682, 107, 17, 57, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (683, 107, 13, 43, 'Weak reaction (w) for C4 and C8', 'low', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (685, 108, 2, 6, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (686, 108, 8, 21, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (687, 108, 7, 17, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (688, 108, 9, 25, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (3391, 684, 30, 110, NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (668, 106, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (140, 24, 27, 97, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (164, 28, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (165, 28, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (166, 28, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (167, 28, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (170, 29, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (171, 29, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (172, 29, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (173, 29, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (176, 30, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (593, 96, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (594, 96, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (106, 19, 7, 17, NULL, 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (595, 96, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (596, 96, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (599, 97, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (600, 97, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (601, 97, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (602, 97, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (605, 98, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (606, 98, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (1016, 158, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1017, 158, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1018, 158, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1021, 159, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1022, 159, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1023, 159, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (3392, 684, 31, 114, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3393, 684, 33, 123, 'Результат ''w''.', 'low', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3394, 684, 36, 133, NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3395, 684, 38, 141, NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3396, 684, 28, 101, NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3397, 685, 2, 5, 'Скользящая подвижность. [1]', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3398, 685, 5, 269, 'Проверено при 2-3% NaCl.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3399, 685, 7, 17, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3400, 685, 8, 21, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3401, 685, 9, 26, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3402, 685, 10, 30, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3403, 685, 11, 34, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3404, 685, 12, 37, 'Положителен на щелочную и кислую фосфатазу.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3405, 685, 13, 41, 'Положителен на эстеразу липазу (C8).', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3406, 685, 19, 65, 'Определено по гидролизу обезжиренного молока (протеаза).', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (117, 20, 2, 5, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (118, 20, 7, 17, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (119, 20, 8, 21, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (120, 20, 10, 29, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (121, 20, 17, 57, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (122, 20, 9, 26, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (123, 20, 11, 34, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (124, 20, 27, 98, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (125, 21, 7, 17, 'Value is cited from another source.', 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (126, 21, 10, 29, 'Value is cited from another source.', 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (127, 21, 17, 58, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (129, 21, 29, 107, 'Result is weak (w).', 'low', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (141, 24, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (142, 24, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (143, 24, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (146, 25, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (147, 25, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (148, 25, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (149, 25, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (152, 26, 27, 97, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (177, 30, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (607, 98, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (608, 98, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (611, 99, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (612, 99, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (613, 99, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (128, 21, 16, 54, 'Value is cited from another source.', 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (130, 21, 28, 101, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (131, 21, 32, 117, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (132, 22, 8, 21, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (240, 40, 9, 26, NULL, 'high', NULL, '2025-06-26 02:45:09.04858', '2025-06-27 10:51:52.367638');
INSERT INTO lysobacter.test_results_boolean VALUES (631, 102, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (632, 102, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (635, 103, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (636, 103, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (637, 103, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (638, 103, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (689, 108, 19, 65, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (690, 108, 18, 61, NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_boolean VALUES (1024, 159, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1027, 160, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (3407, 685, 25, 90, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3408, 685, 27, 98, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3409, 685, 30, 111, 'Результат ''w''.', 'low', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3410, 685, 31, 114, 'Из примечания в таблице.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3411, 685, 33, 122, NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3412, 685, 36, 133, NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3413, 685, 38, 142, NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3414, 685, 28, 101, NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_boolean VALUES (3624, 700, 2, 6, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3625, 700, 5, 268, 'Рост при 0-2.0% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3626, 700, 7, 17, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3627, 700, 8, 21, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3628, 700, 9, 25, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (188, 32, 27, 97, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (189, 32, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (190, 32, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (191, 32, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (194, 33, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (212, 36, 27, 97, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (213, 36, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (214, 36, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (215, 36, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (218, 37, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (219, 37, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (220, 37, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (221, 37, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (224, 38, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''weak''', 'low', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (225, 38, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (227, 38, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (230, 39, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (231, 39, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (232, 39, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (233, 39, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (617, 100, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (618, 100, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (619, 100, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (620, 100, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (623, 101, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (624, 101, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (625, 101, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (626, 101, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (629, 102, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (3629, 700, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3630, 700, 11, 34, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (226, 38, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:40:27.452518', '2025-06-27 10:51:52.314742');
INSERT INTO lysobacter.test_results_boolean VALUES (630, 102, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (3631, 700, 12, 37, 'Положителен на кислую фосфатазу (из OCR).', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3632, 700, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8) (из OCR).', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3633, 700, 16, 54, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3634, 700, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3635, 700, 18, 61, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3636, 700, 19, 65, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3637, 700, 20, 69, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (137, 23, 13, 41, 'Esterase (C4)', 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (153, 26, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (154, 26, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (258, 41, 2, 6, NULL, 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (259, 41, 9, 26, 'From ''Гидролиз мочевины''', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (641, 104, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (642, 104, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (643, 104, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (644, 104, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 03:04:32.422276', '2025-06-27 10:51:52.534672');
INSERT INTO lysobacter.test_results_boolean VALUES (693, 112, 2, 5, 'From ''Скользящая подвижность''', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (694, 112, 8, 21, NULL, 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (695, 112, 7, 17, NULL, 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (696, 112, 10, 30, NULL, 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (697, 112, 9, 26, NULL, 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (698, 112, 17, 57, NULL, 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (699, 112, 23, 81, NULL, 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (716, 112, 33, 121, 'Assimilation test', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (717, 112, 40, 149, 'Assimilation test', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (718, 112, 30, 109, 'Assimilation test', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (719, 112, 38, 141, 'Assimilation test', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (3415, 686, 1, 2, 'Источник: BacDive. [3]', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_boolean VALUES (3416, 686, 2, 6, 'Источник: BacDive. [3]', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_boolean VALUES (3417, 686, 7, 17, 'Источник: Bai et al. (2020). [1, 2]', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_boolean VALUES (3418, 686, 8, 21, 'Источник: Bai et al. (2020). [1, 2]', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_boolean VALUES (3419, 686, 12, 37, 'Положителен на кислую фосфатазу (из OCR).', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_boolean VALUES (3420, 686, 18, 61, 'Гидролиз желатина (из OCR).', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_boolean VALUES (3638, 700, 21, 73, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3639, 700, 25, 90, 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3640, 700, 28, 101, 'Ассимиляция мальтозы (из OCR).', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3641, 700, 32, 118, 'Ассимиляция D-маннозы (из OCR).', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3642, 700, 35, 130, 'Ассимиляция D-маннита (из OCR).', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3643, 700, 36, 134, 'Ассимиляция D-глюкозы (из OCR).', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_boolean VALUES (3754, 708, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3755, 708, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3756, 708, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3757, 708, 11, 34, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3758, 708, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (103, 18, 27, 97, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (104, 18, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (105, 19, 2, 5, 'From ''Скользящая подвижность''', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (107, 19, 17, 57, NULL, 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (108, 19, 10, 29, NULL, 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (109, 19, 9, 26, NULL, 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (110, 19, 40, 150, 'Assimilation test', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (111, 19, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (112, 19, 35, 129, 'Assimilation test', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (113, 19, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (114, 19, 31, 113, 'Assimilation test', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (115, 19, 41, 153, 'Assimilation test', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (116, 19, 33, 121, 'Assimilation test', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_boolean VALUES (133, 22, 7, 17, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (134, 22, 23, 81, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (135, 22, 17, 57, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (264, 41, 18, 61, 'Inferred from the note: ''положительны на гидролиз желатина''', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (265, 41, 13, 41, 'Inferred from the note: ''положительны на ... эстеразу (С4), эстеразу липазу (C8)''', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (266, 41, 12, 37, 'Inferred from the note: ''положительны на ... щелочную фосфатазу, кислую фосфатазу''', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (269, 43, 2, 5, 'Gliding motility (G) observed on page 8.', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (700, 112, 16, 55, 'Conflicting data: Positive on pages 12, 21, 22 but negative (cited) on page 26.', 'low', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (701, 112, 21, 73, NULL, 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (710, 112, 13, 41, 'Positive for Esterase (C4)', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (711, 112, 12, 37, 'Positive for acid phosphatase', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (715, 112, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (720, 112, 29, 105, 'Assimilation test', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (136, 22, 16, 53, NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_boolean VALUES (3759, 708, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3760, 708, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3421, 687, 1, 2, 'Источник: Fukuda et al. (2013). [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3422, 687, 5, 268, 'Растет при 0.0-0.5% NaCl. [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3423, 687, 6, 13, 'Источник: Fukuda et al. (2013). [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3424, 687, 7, 18, 'Источник: BacDive. [7]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3425, 687, 8, 21, 'Источник: BacDive. [7]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3426, 687, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3427, 687, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3428, 687, 12, 37, 'Положителен на кислую фосфатазу (из OCR).', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3429, 687, 13, 41, 'Источник: Fukuda et al. (2013). [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (155, 26, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (158, 27, 27, 97, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (159, 27, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (160, 27, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (161, 27, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:08:58.160833', '2025-06-27 10:51:52.1528');
INSERT INTO lysobacter.test_results_boolean VALUES (178, 30, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (179, 30, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (182, 31, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''weak''', 'low', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (183, 31, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (184, 31, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (185, 31, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:17:20.062616', '2025-06-27 10:51:52.207024');
INSERT INTO lysobacter.test_results_boolean VALUES (195, 33, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (196, 33, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (197, 33, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (200, 34, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (201, 34, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (202, 34, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (203, 34, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (206, 35, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (207, 35, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (208, 35, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (209, 35, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 02:23:11.891632', '2025-06-27 10:51:52.261307');
INSERT INTO lysobacter.test_results_boolean VALUES (267, 41, 11, 34, 'Inferred from the note: ''отрицательны на ... продукцию индола''', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (268, 41, 27, 98, 'Inferred from the note: ''отрицательны на ... ферментацию глюкозы''', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (270, 43, 8, 21, NULL, 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (271, 43, 7, 17, NULL, 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (272, 43, 10, 29, 'Data from page 8. Pages 5 and 27 show negative.', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (273, 43, 11, 34, NULL, 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (274, 43, 17, 58, NULL, 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (275, 43, 18, 61, NULL, 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (276, 43, 19, 65, NULL, 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (277, 43, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (281, 43, 12, 37, 'Positive for acid and BI-phosphohydrolase', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (285, 43, 31, 114, 'Assimilation test', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (286, 43, 32, 118, 'Assimilation test', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (287, 43, 35, 130, 'Assimilation test', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_boolean VALUES (3430, 687, 16, 53, 'Продукция амилазы. [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3431, 687, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3432, 687, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3433, 687, 29, 106, 'Источник: BacDive. [7]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3434, 687, 30, 110, 'Источник: BacDive. [7]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3435, 687, 31, 113, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3436, 687, 32, 118, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3437, 687, 33, 122, 'Источник: BacDive. [7]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3438, 687, 34, 125, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3439, 687, 35, 130, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3440, 687, 36, 133, 'Ассимиляция D-глюкозы (из OCR).', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3441, 687, 37, 138, 'Источник: BacDive. [7]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3442, 687, 38, 142, 'Источник: BacDive. [7]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3443, 687, 41, 153, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_boolean VALUES (3644, 701, 2, 5, 'Скользящая подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3645, 701, 5, 268, 'Рост при 0-1% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3646, 701, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3647, 701, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3648, 701, 9, 26, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3649, 701, 10, 30, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3650, 701, 11, 34, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3651, 701, 12, 37, 'Положителен на щелочную и кислую фосфатазу (из OCR).', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3652, 701, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8) (из OCR).', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3653, 701, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (69, 12, 9, 25, NULL, 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (70, 12, 31, 113, 'Acid production from L-Арабинозы. Value is cited.', 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_boolean VALUES (519, 77, 9, 25, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (520, 77, 17, 57, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (521, 77, 25, 89, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (523, 79, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (524, 79, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (526, 80, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (527, 80, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (3444, 688, 8, 21, 'Извлечено из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3445, 688, 17, 57, 'Извлечено из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3446, 688, 20, 69, 'Извлечено из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (528, 81, 2, 5, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (3447, 688, 21, 73, 'Извлечено из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3448, 688, 19, 65, 'Извлечено из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (529, 81, 10, 29, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (3449, 688, 10, 30, 'Извлечено из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3450, 688, 25, 90, 'Извлечено из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3451, 688, 36, 133, 'Ассимиляция D-глюкозы (из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3452, 688, 32, 117, 'Ассимиляция D-маннозы (из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3453, 688, 28, 101, 'Ассимиляция D-мальтозы (из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3454, 689, 2, 5, 'Скользящая подвижность (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3455, 689, 7, 17, 'Извлечено из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3456, 689, 10, 29, 'Восстановление нитратов (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3457, 689, 19, 65, 'Все штаммы были положительны на гидролиз казеина (примечание к таблице ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3458, 689, 23, 81, 'Гидролиз хитина (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3459, 689, 18, 61, 'Гидролиз желатина (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3460, 689, 17, 57, 'Гидролиз эскулина (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (530, 81, 17, 57, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (3461, 689, 31, 114, 'Утилизация L-Арабинозы (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3462, 689, 36, 133, 'Утилизация D-Глюкозы (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (531, 82, 7, 17, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (532, 82, 10, 30, 'Value is cited.', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (533, 82, 17, 57, 'Value is cited.', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (534, 82, 16, 53, 'Value is cited.', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (535, 83, 9, 25, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (536, 83, 17, 57, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (537, 83, 13, 41, NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (539, 84, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (540, 84, 40, 150, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_boolean VALUES (646, 105, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (647, 105, 7, 17, NULL, 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (648, 105, 10, 29, NULL, 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (649, 105, 9, 25, NULL, 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (650, 105, 25, 89, NULL, 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (651, 105, 6, 13, 'From ''Ассимиляция Протеаза''', 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (655, 105, 16, 53, NULL, 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (656, 105, 23, 81, NULL, 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (657, 105, 24, 85, 'From ''Гидролиз КМ-целлюлоза''', 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (659, 105, 26, 94, NULL, 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (665, 105, 35, 130, 'Assimilation test', 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_boolean VALUES (721, 112, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_boolean VALUES (728, 114, 12, 37, 'Positive for alkaline phosphatase', 'high', NULL, '2025-06-26 06:21:59.494506', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_boolean VALUES (3654, 701, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3655, 701, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (760, 120, 8, 21, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (794, 124, 41, 153, 'Assimilation test', 'high', NULL, '2025-06-26 06:30:03.856434', '2025-06-27 10:51:52.92726');
INSERT INTO lysobacter.test_results_boolean VALUES (795, 124, 33, 121, 'Assimilation test', 'high', NULL, '2025-06-26 06:30:03.856434', '2025-06-27 10:51:52.92726');
INSERT INTO lysobacter.test_results_boolean VALUES (796, 127, 8, 23, 'Conflicting data: Positive on page 79, negative on page 66.', 'low', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (797, 127, 7, 17, NULL, 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (798, 127, 10, 30, NULL, 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (799, 127, 9, 26, NULL, 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (800, 127, 17, 57, NULL, 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (801, 127, 19, 65, NULL, 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (802, 127, 18, 61, NULL, 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (803, 127, 16, 53, NULL, 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (806, 127, 25, 90, NULL, 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (810, 127, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (3463, 689, 32, 118, 'Утилизация D-Маннозы (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3464, 689, 35, 130, 'Утилизация D-Маннитола (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3465, 689, 28, 102, 'Утилизация D-Мальтозы (из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T'').', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3466, 690, 2, 5, 'Скольжение.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3467, 690, 20, 69, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3468, 690, 16, 53, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3469, 690, 24, 86, 'Гидролиз КМЦ.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3470, 690, 13, 41, 'Липаза (C14) - отрицательно.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3471, 690, 31, 114, 'Ассимиляция L-арабинозы.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3472, 690, 28, 102, 'Ассимиляция D-мальтозы.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3473, 691, 2, 5, 'Скользящая подвижность.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3474, 691, 5, 268, 'Толерантность к NaCl до 2%.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3475, 691, 8, 22, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3476, 691, 7, 18, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3477, 691, 17, 57, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3478, 691, 20, 69, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3479, 691, 21, 73, 'Извлечено из Твин 80.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3480, 691, 22, 77, 'Извлечено из Твин 80.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3481, 691, 16, 54, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3482, 691, 24, 86, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3483, 691, 19, 65, NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (3484, 691, 12, 37, 'Нафтол-AS-BI-фосфогидролаза.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_boolean VALUES (729, 114, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 06:21:59.494506', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_boolean VALUES (741, 115, 19, 65, NULL, 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (742, 115, 18, 61, NULL, 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (743, 115, 20, 69, NULL, 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (744, 115, 21, 73, NULL, 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (745, 115, 22, 77, NULL, 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (749, 115, 40, 150, 'Assimilation test', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (750, 115, 30, 110, 'Assimilation test', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (751, 115, 29, 106, 'Assimilation test', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (755, 115, 37, 138, 'Assimilation test', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (757, 115, 41, 154, 'Assimilation test', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (758, 115, 33, 121, 'Assimilation test', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-27 10:51:52.817563');
INSERT INTO lysobacter.test_results_boolean VALUES (759, 120, 2, 5, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (761, 120, 7, 17, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (762, 120, 10, 29, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (763, 120, 9, 26, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (764, 120, 17, 59, 'Conflicting data: Positive on pages 6, 20 but negative on page 27.', 'low', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (765, 120, 18, 61, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (766, 120, 19, 65, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (767, 120, 16, 54, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (769, 120, 11, 34, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (770, 120, 27, 98, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (771, 120, 25, 90, NULL, 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (773, 120, 13, 41, 'Positive for Esterase (C4)', 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (777, 120, 12, 37, 'Positive for acid phosphatase', 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (779, 120, 31, 114, 'Assimilation test', 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (780, 120, 32, 118, 'Assimilation test', 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (781, 120, 35, 130, 'Assimilation test', 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (783, 120, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_boolean VALUES (787, 124, 17, 57, 'Value is cited.', 'high', NULL, '2025-06-26 06:30:03.856434', '2025-06-27 10:51:52.92726');
INSERT INTO lysobacter.test_results_boolean VALUES (789, 124, 40, 149, 'Assimilation test', 'high', NULL, '2025-06-26 06:30:03.856434', '2025-06-27 10:51:52.92726');
INSERT INTO lysobacter.test_results_boolean VALUES (790, 124, 30, 109, 'Assimilation test', 'high', NULL, '2025-06-26 06:30:03.856434', '2025-06-27 10:51:52.92726');
INSERT INTO lysobacter.test_results_boolean VALUES (792, 124, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 06:30:03.856434', '2025-06-27 10:51:52.92726');
INSERT INTO lysobacter.test_results_boolean VALUES (793, 124, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 06:30:03.856434', '2025-06-27 10:51:52.92726');
INSERT INTO lysobacter.test_results_boolean VALUES (3656, 701, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3485, 692, 2, 6, 'Источник: Choi et al. (2014). [2, 4]', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3486, 692, 5, 268, 'Растет в присутствии 0-1% NaCl (из OCR).', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3487, 692, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3488, 692, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3489, 692, 9, 25, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3490, 692, 10, 30, 'В OCR есть противоречивые данные (+/-). Choi et al. (2014) указывает на отрицательный результат. [1]', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3491, 692, 12, 37, 'Положителен на щелочную и кислую фосфатазу (из примечания в OCR).', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3492, 692, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8) (из OCR).', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (814, 127, 12, 37, 'Positive for acid and Naphthol-AS-BI-phosphohydrolase', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (819, 127, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (821, 127, 40, 149, 'Assimilation test', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (822, 127, 30, 109, 'Assimilation test', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (824, 127, 35, 129, 'Assimilation test', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (825, 127, 34, 125, 'Assimilation test', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (826, 127, 31, 113, 'Assimilation test', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (827, 127, 41, 153, 'Assimilation test', 'high', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_boolean VALUES (828, 128, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (829, 128, 8, 21, 'Confirmed by BacDive. Some tables in the PDF showed a negative result.', 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (830, 128, 7, 17, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (831, 128, 10, 29, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (832, 128, 9, 26, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (833, 128, 11, 34, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (834, 128, 27, 98, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (835, 128, 17, 57, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (836, 128, 18, 61, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (837, 128, 19, 65, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (838, 128, 16, 53, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (841, 128, 25, 90, NULL, 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (845, 128, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (848, 128, 12, 37, 'Positive for acid and alkaline phosphatase', 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (853, 128, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (854, 128, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_boolean VALUES (857, 132, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (858, 132, 8, 21, NULL, 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (859, 132, 7, 17, NULL, 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (860, 132, 10, 29, 'Confirmed by BacDive, resolving conflicting data in the PDF.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (861, 132, 9, 26, 'Confirmed by BacDive, resolving conflicting data in the PDF.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (862, 132, 11, 34, NULL, 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (863, 132, 17, 57, 'Confirmed by BacDive, resolving conflicting data in the PDF.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (864, 132, 18, 61, NULL, 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (865, 132, 19, 65, NULL, 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (866, 132, 16, 54, 'Confirmed by BacDive.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (869, 132, 25, 90, NULL, 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (876, 132, 32, 117, 'Assimilation test, confirmed by BacDive.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (877, 132, 28, 101, 'Assimilation test, confirmed by BacDive.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_boolean VALUES (880, 134, 2, 5, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (881, 134, 8, 21, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (882, 134, 7, 17, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (883, 134, 10, 29, 'Confirmed by BacDive. PDF table on page 26 shows a negative result.', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (884, 134, 17, 58, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (3493, 692, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3494, 692, 17, 57, 'Гидролиз эскулина (из OCR).', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3495, 692, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3496, 692, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3497, 692, 23, 82, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3498, 692, 25, 90, 'В OCR есть противоречивые данные (+/-). Choi et al. (2014) указывает на отрицательный результат.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3499, 692, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3500, 692, 29, 106, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3501, 692, 30, 109, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3502, 692, 31, 113, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3503, 692, 32, 119, 'Результат ''w'' (слабоположительный) из OCR.', 'low', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3504, 692, 33, 121, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3505, 692, 35, 130, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3506, 692, 36, 133, 'Ассимиляция D-глюкозы (из OCR).', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3507, 692, 37, 137, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3508, 692, 38, 141, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3509, 692, 40, 149, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3510, 692, 41, 153, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_boolean VALUES (3657, 701, 23, 81, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3658, 701, 24, 85, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3659, 701, 25, 90, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3660, 701, 27, 98, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3661, 701, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3511, 693, 2, 5, 'Скользящая подвижность. [4]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3512, 693, 5, 268, 'Рост при 0-1.0% NaCl. [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3513, 693, 7, 17, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3514, 693, 8, 21, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3515, 693, 9, 26, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3516, 693, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3517, 693, 11, 34, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3518, 693, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3519, 693, 16, 53, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3520, 693, 17, 57, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3521, 693, 18, 61, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3522, 693, 19, 65, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3523, 693, 25, 90, 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3524, 693, 36, 133, 'Ассимиляция D-глюкозы. [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (885, 134, 16, 54, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (886, 134, 21, 73, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (889, 134, 30, 109, 'Assimilation test', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (890, 134, 38, 141, 'Assimilation test', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (892, 134, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (893, 134, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (894, 134, 34, 125, 'Assimilation test', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (895, 134, 33, 121, 'Assimilation test', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (896, 138, 8, 21, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (897, 138, 7, 17, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (898, 138, 9, 26, NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (899, 138, 33, 121, 'Assimilation test', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (900, 138, 12, 39, 'Weakly positive for alkaline phosphatase', 'low', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (901, 138, 13, 43, 'Weakly positive for Esterase (C4)', 'low', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_boolean VALUES (906, 139, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (907, 139, 8, 21, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (908, 139, 7, 17, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (909, 139, 10, 29, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (910, 139, 9, 26, 'Confirmed by BacDive, resolving conflicting data in the PDF.', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (911, 139, 11, 34, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (912, 139, 27, 98, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (913, 139, 17, 57, 'Confirmed by BacDive, resolving conflicting data in the PDF.', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (914, 139, 18, 61, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (915, 139, 19, 65, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (916, 139, 16, 53, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (917, 139, 23, 81, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (918, 139, 20, 69, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (921, 139, 25, 90, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (925, 139, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (929, 139, 12, 37, 'Positive for acid and alkaline phosphatase', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (934, 139, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (937, 140, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (938, 140, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (939, 140, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (940, 140, 29, 106, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (943, 141, 27, 99, 'From ''ОФ-тест (Ферментативный)'', result was ''slow''', 'low', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (944, 141, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (945, 141, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (946, 141, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (949, 142, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (950, 142, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (951, 142, 41, 155, 'Acid production from sucrose. Result was ''weak''.', 'low', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (952, 142, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (954, 148, 8, 21, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (955, 148, 10, 30, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (956, 148, 17, 57, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (957, 148, 19, 65, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (958, 148, 20, 69, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (3525, 693, 28, 101, 'Ассимиляция D-мальтозы. [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3526, 179, 2, 5, 'Скользящая подвижность. [13]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3527, 179, 5, 268, 'Рост при 0-1.0% NaCl. [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3528, 179, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3529, 179, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3530, 179, 9, 26, 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3531, 179, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3532, 179, 11, 34, 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3533, 179, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3534, 179, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3535, 179, 18, 61, 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3536, 179, 19, 65, 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3537, 179, 20, 69, 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3538, 179, 21, 73, 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (962, 148, 25, 90, NULL, 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (969, 148, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (971, 148, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (973, 151, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (974, 151, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (975, 151, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (976, 151, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (979, 152, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (980, 152, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (981, 152, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (982, 152, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (985, 153, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (986, 153, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (987, 153, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (988, 153, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (991, 154, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (992, 154, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (993, 154, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (994, 154, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (997, 155, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (998, 155, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (999, 155, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1000, 155, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (3539, 179, 22, 77, 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3540, 179, 36, 133, 'Ассимиляция D-глюкозы. [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (3541, 179, 28, 101, 'Ассимиляция D-мальтозы. [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_boolean VALUES (1003, 156, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1004, 156, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (3662, 701, 30, 109, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3663, 701, 31, 113, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3664, 701, 32, 117, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3665, 701, 33, 121, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (1005, 156, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1006, 156, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (3666, 701, 35, 129, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (1009, 157, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1010, 157, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1011, 157, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1012, 157, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1015, 158, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (3667, 701, 36, 133, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3668, 701, 41, 153, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_boolean VALUES (3761, 708, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3762, 708, 23, 82, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3763, 708, 36, 133, 'Ассимиляция D-глюкозы. [7, 8]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3764, 708, 31, 114, 'Ассимиляция L-арабинозы. [7, 8]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3765, 708, 32, 118, 'Ассимиляция D-маннозы. [7, 8]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3766, 709, 2, 5, 'Скользящая подвижность. [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3767, 709, 5, 268, 'Рост при 0-2% NaCl. [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3768, 709, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3769, 709, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3770, 709, 9, 26, 'Источник: Park et al. (2008). [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3771, 709, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3772, 709, 18, 61, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3773, 709, 19, 65, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3774, 709, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3775, 709, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3776, 709, 20, 69, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3777, 709, 23, 81, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3778, 709, 36, 133, 'Ассимиляция D-глюкозы. [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3779, 709, 31, 113, 'Ассимиляция L-арабинозы. [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3780, 709, 32, 117, 'Ассимиляция D-маннозы. [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3781, 709, 28, 101, 'Ассимиляция мальтозы. [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3791, 710, 17, 57, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3792, 710, 18, 61, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3793, 710, 19, 65, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3794, 710, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3795, 710, 23, 81, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3796, 710, 36, 133, 'Ассимиляция D-глюкозы. [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3542, 695, 2, 6, 'В первоисточнике указано ''non-gliding''. [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3543, 695, 5, 268, 'Рост при 0-6.0% NaCl. [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3544, 695, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3545, 695, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3546, 695, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3547, 695, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3548, 695, 36, 133, 'Ассимиляция D-глюкозы (из OCR).', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3549, 695, 31, 114, 'Ассимиляция L-арабинозы (из OCR).', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3550, 695, 32, 117, 'Ассимиляция D-маннозы (из OCR).', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3551, 695, 28, 101, 'Ассимиляция мальтозы (из OCR).', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_boolean VALUES (3688, 703, 2, 5, 'Скользящая подвижность. [5]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3689, 703, 5, 268, 'Рост при 0-1.0% NaCl. [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3690, 703, 7, 17, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3691, 703, 8, 21, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3692, 703, 9, 26, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3693, 703, 10, 30, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3694, 703, 11, 34, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3695, 703, 16, 53, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3696, 703, 17, 57, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3697, 703, 18, 61, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3698, 703, 19, 65, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (1028, 160, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1029, 160, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1030, 160, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1033, 161, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1034, 161, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1035, 161, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1036, 161, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1039, 162, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1040, 162, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1041, 162, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1042, 162, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1045, 163, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1046, 163, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1047, 163, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1048, 163, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1051, 164, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1052, 164, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1053, 164, 41, 153, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1054, 164, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1057, 167, 27, 98, 'From ''ОФ-тест (Ферментативный)''', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1058, 167, 40, 149, 'Acid production from cellobiose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1059, 167, 41, 154, 'Acid production from sucrose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1060, 167, 29, 105, 'Acid production from lactose', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_boolean VALUES (1062, 145, 2, 5, 'Gliding motility observed (from BacDive).', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1063, 145, 8, 21, 'From BacDive.', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1064, 145, 7, 17, 'From BacDive.', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1065, 145, 10, 29, 'From BacDive.', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1066, 145, 9, 26, 'From BacDive.', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1067, 145, 19, 65, 'From BacDive.', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1068, 145, 18, 61, 'From BacDive.', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1069, 145, 16, 53, 'From BacDive.', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1072, 145, 27, 98, 'From ''ОФ-тест (Ферментативный)'' (from PDF).', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1073, 145, 40, 149, 'Acid production from cellobiose (from PDF).', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1074, 145, 41, 154, 'Acid production from sucrose (from PDF).', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1075, 145, 29, 105, 'Acid production from lactose (from PDF).', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_boolean VALUES (1077, 170, 40, 149, 'Carbon source utilization.', 'high', NULL, '2025-06-26 07:17:39.437709', '2025-06-27 10:51:53.323451');
INSERT INTO lysobacter.test_results_boolean VALUES (1078, 170, 30, 109, 'Carbon source utilization.', 'high', NULL, '2025-06-26 07:17:39.437709', '2025-06-27 10:51:53.323451');
INSERT INTO lysobacter.test_results_boolean VALUES (1080, 170, 28, 101, 'Carbon source utilization.', 'high', NULL, '2025-06-26 07:17:39.437709', '2025-06-27 10:51:53.323451');
INSERT INTO lysobacter.test_results_boolean VALUES (1089, 171, 10, 30, 'From BacDive.', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-27 10:51:53.374602');
INSERT INTO lysobacter.test_results_boolean VALUES (1090, 171, 9, 26, 'From BacDive.', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-27 10:51:53.374602');
INSERT INTO lysobacter.test_results_boolean VALUES (3699, 703, 20, 69, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3700, 703, 21, 73, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3552, 696, 2, 5, 'Скользящая подвижность. В одной из таблиц OCR указано ''Неподвижный'', но первоисточник подтверждает подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3553, 696, 5, 268, 'Рост при 0-0.5% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3554, 696, 7, 18, 'В OCR указано ''+'', но первоисточник и BacDive указывают ''-''. [1, 2, 3]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3555, 696, 8, 21, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3556, 696, 9, 26, 'В OCR указано ''+'', но первоисточник указывает ''-''. [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3557, 696, 12, 37, 'Положителен на щелочную и кислую фосфатазу. [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3558, 696, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3559, 696, 16, 54, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3560, 696, 17, 57, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3561, 696, 18, 61, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3562, 696, 19, 65, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3563, 696, 20, 69, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (1118, 173, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1119, 173, 8, 21, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1120, 173, 7, 17, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1121, 173, 10, 29, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1122, 173, 9, 26, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1123, 173, 17, 57, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1124, 173, 18, 61, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1125, 173, 19, 65, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1126, 173, 16, 53, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1129, 173, 25, 90, NULL, 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1131, 173, 27, 97, 'From ''Подкисление глюкозы''', 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1133, 173, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1135, 173, 31, 113, 'Assimilation test', 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_boolean VALUES (1137, 176, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1138, 176, 8, 21, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1139, 176, 7, 17, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1140, 176, 10, 30, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1141, 176, 9, 26, 'Confirmed by BacDive, resolving conflicting data in the PDF.', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1142, 176, 11, 34, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1143, 176, 27, 98, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1144, 176, 17, 57, 'Confirmed by BacDive, resolving conflicting data in the PDF.', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1145, 176, 18, 61, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1146, 176, 19, 65, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1147, 176, 16, 53, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1150, 176, 25, 90, NULL, 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1154, 176, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1157, 176, 12, 37, 'Positive for acid and alkaline phosphatase', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1162, 176, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1164, 176, 41, 155, 'Acid production from sucrose. Result was ''weak''.', 'low', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1165, 176, 29, 105, 'Acid production from lactose.', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_boolean VALUES (1167, 186, 2, 5, 'From BacDive.', 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1168, 186, 8, 21, NULL, 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1169, 186, 7, 17, NULL, 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1170, 186, 10, 30, NULL, 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1171, 186, 9, 25, NULL, 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1172, 186, 17, 57, NULL, 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1173, 186, 18, 61, NULL, 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1174, 186, 19, 65, NULL, 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1175, 186, 16, 53, NULL, 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1176, 186, 13, 41, 'Positive for Esterase (C4) and Esterase Lipase (C8).', 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (3564, 696, 21, 73, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3565, 696, 22, 77, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3566, 696, 25, 90, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3567, 696, 28, 101, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3568, 696, 29, 106, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3569, 696, 30, 109, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3570, 696, 31, 113, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3571, 696, 32, 117, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3572, 696, 33, 121, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3573, 696, 35, 130, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3574, 696, 36, 133, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3575, 696, 37, 137, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3576, 696, 38, 141, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3577, 696, 41, 153, 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_boolean VALUES (3701, 703, 22, 77, 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3702, 703, 36, 133, 'Ассимиляция D-глюкозы. [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (1180, 186, 12, 37, 'Positive for acid and Naphthol-AS-BI-phosphohydrolase', 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1188, 186, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1189, 186, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1190, 186, 35, 129, 'Assimilation test', 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_boolean VALUES (1193, 187, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1194, 187, 8, 21, NULL, 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1195, 187, 7, 17, NULL, 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1196, 187, 10, 29, NULL, 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1197, 187, 9, 26, 'From BacDive.', 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1198, 187, 17, 57, NULL, 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1199, 187, 18, 61, 'From BacDive.', 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1200, 187, 19, 65, 'From BacDive.', 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1201, 187, 16, 53, 'From BacDive.', 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1211, 187, 31, 113, 'Assimilation test', 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_boolean VALUES (1213, 191, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1214, 191, 8, 21, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1215, 191, 7, 17, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1216, 191, 10, 30, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1217, 191, 9, 25, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1218, 191, 17, 57, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1219, 191, 18, 61, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1220, 191, 19, 65, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1221, 191, 16, 53, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1224, 191, 25, 90, NULL, 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1229, 191, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1233, 191, 12, 37, 'Positive for acid and alkaline phosphatase', 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1238, 191, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1239, 191, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_boolean VALUES (1241, 194, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1242, 194, 8, 21, NULL, 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1243, 194, 7, 17, NULL, 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1244, 194, 10, 31, 'Result was weak (w).', 'low', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1245, 194, 9, 26, NULL, 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1246, 194, 17, 57, NULL, 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1247, 194, 18, 61, NULL, 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1248, 194, 19, 65, NULL, 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1249, 194, 16, 54, NULL, 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (3578, 697, 5, 268, 'Рост при 0-1.5% NaCl (из OCR).', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3579, 697, 7, 17, 'Источник: Fang et al. (2020). [8]', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3580, 697, 8, 21, 'Источник: Fang et al. (2020). [8]', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3581, 697, 9, 26, 'Источник: Fang et al. (2020). [8]', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3582, 697, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3583, 697, 13, 41, 'Положителен на эстеразу липазу (C8) (из OCR).', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3584, 697, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3585, 697, 21, 73, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3586, 697, 22, 77, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3587, 697, 31, 114, 'Ассимиляция D-Арабинозы (из OCR).', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3588, 697, 33, 121, 'Ассимиляция D-Трегалозы (из OCR).', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3589, 697, 34, 126, 'Ассимиляция D-Сорбита (из OCR).', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3590, 697, 36, 133, 'Ассимиляция D-глюкозы (из OCR).', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3591, 697, 37, 137, 'Ассимиляция D-Ксилозы (из OCR).', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3592, 697, 40, 149, 'Ассимиляция D-Целлобиозы (из OCR).', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_boolean VALUES (3703, 703, 28, 101, 'Ассимиляция D-мальтозы. [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3704, 704, 2, 5, 'Скользящая подвижность. [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3705, 704, 5, 268, 'Рост при 0-2% NaCl. [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3706, 704, 7, 17, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3707, 704, 8, 21, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3708, 704, 9, 26, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3709, 704, 10, 30, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3710, 704, 11, 34, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3711, 704, 16, 54, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3712, 704, 17, 57, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3713, 704, 18, 61, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3714, 704, 19, 65, 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3715, 704, 36, 133, 'Ассимиляция D-глюкозы. [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3716, 704, 28, 101, 'Ассимиляция D-мальтозы. [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3782, 710, 2, 5, 'Скользящая подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3783, 710, 5, 268, 'Рост при 0-7.0% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3784, 710, 7, 17, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3785, 710, 8, 21, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3786, 710, 9, 26, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3787, 710, 10, 30, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3788, 710, 11, 34, 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3789, 710, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3790, 710, 16, 54, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3593, 698, 2, 5, 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3594, 698, 5, 269, 'Рост отсутствует при 1% NaCl (из OCR).', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3595, 698, 7, 19, 'Результат ''w/+'' (слабоположительный/положительный) из OCR.', 'low', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3596, 698, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3597, 698, 13, 41, 'Положителен на эстеразу (C4). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3598, 698, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3599, 698, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3600, 698, 36, 133, 'Ассимиляция D-глюкозы (из OCR).', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (1254, 194, 12, 37, 'Positive for acid and alkaline phosphatase.', 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1259, 194, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1260, 194, 32, 118, 'Assimilation test', 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_boolean VALUES (1262, 195, 2, 5, 'From BacDive.', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1263, 195, 8, 21, 'From BacDive.', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1264, 195, 7, 17, 'From BacDive.', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1265, 195, 9, 26, NULL, 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1266, 195, 17, 57, NULL, 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1267, 195, 18, 61, NULL, 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1268, 195, 19, 65, 'From BacDive.', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1269, 195, 16, 53, 'From BacDive.', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1270, 195, 25, 90, NULL, 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1271, 195, 13, 41, 'Positive for Esterase Lipase (C8).', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1279, 195, 35, 130, 'Assimilation test', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_boolean VALUES (1281, 196, 2, 5, 'From BacDive.', 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1282, 196, 8, 21, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1283, 196, 7, 17, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1284, 196, 10, 29, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1285, 196, 9, 25, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1286, 196, 17, 57, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1287, 196, 18, 61, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1288, 196, 19, 65, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1289, 196, 20, 69, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1292, 196, 25, 89, NULL, 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1293, 196, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1296, 196, 12, 37, 'Positive for acid and Naphthol-AS-BI-phosphohydrolase', 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1302, 196, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_boolean VALUES (1306, 199, 17, 58, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1308, 199, 40, 149, 'Assimilation test', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1309, 199, 30, 109, 'Assimilation test', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1311, 199, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1312, 199, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1313, 199, 41, 153, 'Assimilation test', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1314, 199, 33, 121, 'Assimilation test', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1315, 200, 2, 5, 'Motile (M) from page 42.', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1316, 200, 7, 17, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1317, 200, 10, 29, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1318, 200, 16, 54, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1321, 200, 26, 93, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1322, 203, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1323, 203, 8, 21, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1324, 203, 7, 17, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1325, 203, 10, 30, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1326, 203, 17, 57, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1327, 203, 16, 53, NULL, 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (3601, 698, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3602, 698, 32, 118, 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3603, 698, 31, 114, 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3604, 698, 41, 154, 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_boolean VALUES (3717, 705, 2, 5, 'Скользящая подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3718, 705, 5, 268, 'Рост при 0-2% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3719, 705, 7, 17, 'Источник: Bae et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3720, 705, 8, 21, 'Источник: Bae et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3721, 705, 9, 25, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3722, 705, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3723, 705, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3724, 705, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3725, 705, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3726, 705, 16, 54, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (1086, 171, 2, 5, 'Скользящая подвижность. [3, 4]', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3728, 171, 5, 268, 'Рост при 0-0.5% NaCl. [3, 4]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (1088, 171, 7, 17, 'Источник: Yassin et al. (2008). [3, 4]', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (1087, 171, 8, 21, 'Источник: Yassin et al. (2008). [3, 4]', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (1096, 171, 13, 41, 'Положителен на эстеразу (C4). [3, 4]', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (1091, 171, 18, 61, 'Источник: Yassin et al. (2008). [3, 4]', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (1092, 171, 19, 65, 'Источник: Yassin et al. (2008). [3, 4]', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3734, 171, 17, 57, 'Источник: Yassin et al. (2008). [3, 4]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (1093, 171, 16, 53, 'Источник: Yassin et al. (2008). [3, 4]', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (667, 106, 2, 5, 'Скользящая подвижность. [5, 6]', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3737, 106, 5, 268, 'Рост при 0-2% NaCl. [5, 6]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (1334, 203, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1335, 203, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_boolean VALUES (1336, 206, 2, 5, 'Gliding motility observed.', 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1337, 206, 8, 21, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1338, 206, 7, 17, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1339, 206, 10, 29, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1340, 206, 9, 25, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1341, 206, 17, 57, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1342, 206, 18, 61, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1343, 206, 19, 65, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1344, 206, 16, 53, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1347, 206, 25, 90, NULL, 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1352, 206, 13, 41, 'Positive for Esterase (C4) and Esterase lipase (C8)', 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1356, 206, 12, 37, 'Positive for acid and alkaline phosphatase', 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1361, 206, 28, 101, 'Assimilation test', 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1362, 206, 32, 117, 'Assimilation test', 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (1363, 206, 35, 129, 'Assimilation test', 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_boolean VALUES (3605, 699, 2, 5, 'Скользящая подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3606, 699, 5, 268, 'Рост при 0-1% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3607, 699, 7, 17, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3608, 699, 8, 21, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3609, 699, 9, 25, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3610, 699, 10, 29, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3611, 699, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3612, 699, 16, 54, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3613, 699, 17, 57, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3614, 699, 18, 61, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3615, 699, 19, 65, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3616, 699, 23, 81, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3617, 699, 25, 89, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3618, 699, 36, 133, 'Ассимиляция D-глюкозы. [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3619, 699, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3620, 699, 32, 117, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3621, 699, 31, 114, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3622, 699, 41, 153, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (3623, 699, 35, 130, 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_boolean VALUES (669, 106, 7, 17, 'Источник: Jung et al. (2012). [5, 6]', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (670, 106, 9, 27, 'Слабоположительный (+). [5, 6]', 'low', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (671, 106, 10, 29, 'Источник: Jung et al. (2012). [5, 6]', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3742, 106, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [5, 6]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (674, 106, 18, 61, 'Источник: Jung et al. (2012). [5, 6]', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3744, 106, 19, 65, 'Источник: Jung et al. (2012). [5, 6]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (673, 106, 17, 57, 'Источник: Jung et al. (2012). [5, 6]', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3746, 106, 16, 53, 'Источник: Jung et al. (2012). [5, 6]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (672, 106, 25, 89, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3748, 106, 36, 133, 'Ассимиляция D-глюкозы. [5, 6]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (678, 106, 32, 117, 'Ассимиляция маннозы. [5, 6]', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (677, 106, 28, 101, 'Ассимиляция мальтозы. [5, 6]', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3751, 708, 2, 5, 'Скользящая подвижность. [7, 8]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3752, 708, 5, 268, 'Рост при 0-2.0% NaCl. [7, 8]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3753, 708, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_boolean VALUES (3797, 710, 28, 101, 'Ассимиляция D-мальтозы. [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3798, 711, 2, 6, 'В первоисточнике указано ''non-gliding''. [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3799, 711, 5, 268, 'Рост при 0-6.0% NaCl. [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3800, 711, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3801, 711, 8, 21, 'Источник: Cai et al. (2021). [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3802, 711, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3803, 711, 13, 43, 'Липаза (C14) - отрицательно, Валин ариламидаза - слабоположительно (w). [3, 4]', 'low', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3804, 711, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3805, 711, 16, 54, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3806, 711, 36, 133, 'Ассимиляция D-глюкозы. [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3807, 711, 31, 114, 'Ассимиляция L-арабинозы. [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3808, 711, 32, 117, 'Ассимиляция D-маннозы. [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3809, 711, 28, 101, 'Ассимиляция мальтозы. [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_boolean VALUES (3810, 712, 2, 5, 'Скользящая подвижность. [1]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3811, 712, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3812, 712, 8, 21, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3813, 712, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3814, 712, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3815, 712, 19, 65, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3816, 712, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3817, 712, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3818, 712, 23, 82, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3819, 712, 24, 85, 'Гидролиз КМЦ. [1]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3820, 712, 25, 90, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3821, 712, 36, 133, 'Ассимиляция D-глюкозы. [1]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3822, 712, 31, 113, 'Ассимиляция L-арабинозы. [1]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3823, 712, 32, 117, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3824, 712, 35, 129, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3825, 712, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3826, 713, 2, 5, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3827, 713, 5, 268, 'Рост при 0% NaCl. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3828, 713, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3829, 713, 8, 21, 'Источник: Liu et al. (2013). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3830, 713, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3831, 713, 25, 90, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3832, 713, 13, 41, 'Положителен на липазу (C14). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3833, 713, 23, 81, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3834, 713, 24, 85, 'Гидролиз КМ-целлюлозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3835, 713, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3836, 713, 36, 133, 'Ассимиляция D-глюкозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3837, 713, 35, 129, 'Ассимиляция D-маннитола. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3838, 713, 28, 101, 'Продукция кислоты из D-мальтозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3839, 713, 29, 105, 'Продукция кислоты из D-лактозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3840, 713, 33, 121, 'Продукция кислоты из D-трегалозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3841, 714, 2, 5, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3842, 714, 5, 268, 'Рост при 0% NaCl. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3843, 714, 7, 18, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3844, 714, 8, 21, 'Источник: Liu et al. (2013). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3845, 714, 9, 25, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3846, 714, 25, 89, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3847, 714, 13, 43, 'Слабоположителен на липазу (C14) и валин-ариламидазу. [3, 4]', 'low', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3848, 714, 23, 81, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3849, 714, 24, 85, 'Гидролиз КМ-целлюлозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3850, 714, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3851, 714, 36, 134, 'Ассимиляция D-глюкозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3852, 714, 35, 130, 'Ассимиляция D-маннитола. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3853, 714, 28, 102, 'Продукция кислоты из D-мальтозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3854, 714, 29, 106, 'Продукция кислоты из D-лактозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3855, 714, 33, 122, 'Продукция кислоты из D-трегалозы. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (733, 115, 2, 5, 'Скользящая подвижность. [7, 8]', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3857, 115, 5, 268, 'Рост при 0-1% NaCl. [7, 8]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (735, 115, 7, 18, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (734, 115, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (737, 115, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (736, 115, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (738, 115, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (740, 115, 16, 54, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3864, 115, 36, 134, 'Ассимиляция D-глюкозы. [7, 8]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (748, 115, 31, 113, 'Ассимиляция L-арабинозы. [7, 8]', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (754, 115, 32, 117, 'Ассимиляция D-маннозы. [7, 8]', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (752, 115, 28, 101, 'Ассимиляция D-мальтозы. [7, 8]', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (753, 115, 35, 131, 'Слабоположительный (w). [7, 8]', 'low', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3869, 716, 5, 268, 'Рост при 0-0.5% NaCl. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3870, 716, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3871, 716, 8, 21, 'Источник: Liu et al. (2013). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3872, 716, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3873, 716, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3874, 716, 13, 41, 'Положителен на липазу (C14). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3875, 716, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3876, 716, 25, 90, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3877, 716, 36, 133, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3878, 716, 28, 102, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_boolean VALUES (3879, 717, 5, 268, 'Рост при 0-7.0% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3880, 717, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3881, 717, 7, 19, 'Слабоположительный (w). [1, 2]', 'low', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3882, 717, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3883, 717, 13, 43, 'Липаза (C14) - слабоположительно (w), Валин-ариламидаза - слабоположительно (w), Трипсин - слабоположительно (w). [1, 2]', 'low', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3884, 717, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3885, 717, 36, 133, 'Ассимиляция d-глюкозы. [1, 2]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3886, 717, 31, 114, 'Ассимиляция l-арабинозы. [1, 2]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3887, 717, 32, 117, 'Ассимиляция d-маннозы. [1, 2]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3888, 717, 28, 101, 'Ассимиляция мальтозы. [1, 2]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3889, 718, 5, 268, 'Рост при 2% NaCl. [3]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3890, 718, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3891, 718, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3892, 718, 16, 54, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3893, 718, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3894, 718, 30, 109, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3895, 718, 31, 113, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3896, 718, 40, 150, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3897, 718, 32, 119, 'Слабоположительный (w). [3]', 'low', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3898, 718, 33, 121, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3899, 718, 41, 154, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3900, 718, 35, 130, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3901, 718, 36, 133, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3902, 718, 38, 141, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3903, 719, 2, 6, 'Неподвижный (N). [5]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3904, 719, 5, 268, 'Рост при 0-2% NaCl. [5]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3905, 719, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3906, 719, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3907, 719, 10, 31, 'Слабоположительный (w). [5]', 'low', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3908, 719, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3909, 719, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3910, 719, 25, 90, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3911, 719, 36, 133, 'Ассимиляция D-глюкозы. [5]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3912, 719, 31, 114, 'Ассимиляция L-арабинозы. [5]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3913, 719, 32, 117, 'Ассимиляция D-маннозы. [5]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3914, 719, 35, 130, 'Ассимиляция D-маннитола. [5]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3915, 719, 28, 101, 'Ассимиляция мальтозы. [5]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3916, 720, 5, 268, 'Рост при 0-4% NaCl. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3917, 720, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3918, 720, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3919, 720, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3920, 720, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3921, 720, 11, 34, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3922, 720, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3923, 720, 23, 81, 'Разложение коллоидного хитина. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3924, 720, 24, 85, 'Разложение карбоксиметилцеллюлозы. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3925, 721, 5, 268, 'Рост при 0-4% NaCl. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3926, 721, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3927, 721, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3928, 721, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3929, 721, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3930, 721, 11, 34, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3931, 721, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3932, 721, 23, 81, 'Разложение коллоидного хитина. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3933, 721, 24, 85, 'Разложение карбоксиметилцеллюлозы. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_boolean VALUES (3934, 722, 5, 268, 'Рост при 0-1% NaCl. [1]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3935, 722, 13, 43, 'Цистинол-ариламидаза (+), Трипсин (w), Химотрипсин (+).', 'low', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3936, 722, 21, 75, 'Слабоположительный (w). [1]', 'low', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3937, 722, 36, 133, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3938, 722, 38, 141, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3939, 723, 2, 5, 'Скользящая подвижность. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3940, 723, 5, 268, 'Рост при 0-7.0% NaCl. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3941, 723, 7, 17, 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3942, 723, 8, 21, 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3943, 723, 9, 26, 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3944, 723, 10, 30, 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3945, 723, 11, 34, 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3946, 723, 13, 41, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3947, 723, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3948, 723, 36, 133, 'Ассимиляция D-глюкозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3949, 723, 28, 101, 'Ассимиляция D-мальтозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3950, 723, 33, 121, 'Ассимиляция D-трегалозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3951, 723, 40, 149, 'Ассимиляция D-целлобиозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3952, 723, 41, 153, 'Ассимиляция сахарозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3953, 724, 13, 43, 'pNP-Фенил-фосфонат (+), pNP-Фосфорил-холин (+), DL-Лактат (+), Оксоглутарат (+).', 'low', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3954, 724, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3955, 724, 36, 134, 'Ассимиляция D-глюкозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3956, 724, 32, 118, 'Ассимиляция D-маннозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3957, 724, 28, 102, 'Ассимиляция D-мальтозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3958, 724, 33, 122, 'Ассимиляция D-трегалозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3959, 724, 40, 150, 'Ассимиляция D-целлобиозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3960, 724, 41, 154, 'Ассимиляция сахарозы. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3961, 725, 2, 5, 'Скользящая подвижность. [5]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3962, 725, 7, 17, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3963, 725, 8, 21, 'Источник: Oh et al. (2011). [5]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3964, 725, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [5]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3965, 725, 12, 37, 'Положителен на щелочную и кислую фосфатазу. [5]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3966, 725, 18, 61, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3967, 725, 21, 74, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3968, 725, 30, 109, 'Ассимиляция D-фруктозы. [5]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3969, 726, 2, 5, 'Скользящая подвижность. [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3970, 726, 5, 268, 'Рост при 0-1% NaCl. [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3971, 726, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3972, 726, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3973, 726, 9, 26, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3974, 726, 10, 30, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3975, 726, 11, 34, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3976, 726, 12, 37, 'Положителен на щелочную и кислую фосфатазу. [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3977, 726, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3978, 726, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3979, 726, 36, 133, 'Ассимиляция D-глюкозы. [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3980, 726, 28, 101, 'Ассимиляция мальтозы. [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_boolean VALUES (3981, 727, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3982, 727, 17, 58, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3983, 727, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3984, 727, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3985, 727, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3986, 727, 25, 89, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3987, 727, 36, 133, 'Ассимиляция D-глюкозы. [1]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3988, 727, 31, 114, 'Ассимиляция L-арабинозы. [1]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3989, 727, 32, 117, 'Ассимиляция D-маннозы. [1]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3990, 727, 28, 101, 'Ассимиляция D-мальтозы. [1]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (238, 40, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 02:45:09.04858', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (241, 40, 17, 58, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 02:45:09.04858', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (243, 40, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 02:45:09.04858', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (242, 40, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 02:45:09.04858', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (239, 40, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 02:45:09.04858', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (245, 40, 25, 90, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 02:45:09.04858', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3997, 40, 36, 133, 'Ассимиляция D-глюкозы. [1]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3998, 40, 31, 113, 'Ассимиляция L-арабинозы. [1]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (3999, 40, 32, 118, 'Ассимиляция D-маннозы. [1]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (257, 40, 28, 101, 'Ассимиляция D-мальтозы. [1]', 'high', NULL, '2025-06-26 02:45:09.04858', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4001, 729, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4002, 729, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [3]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4003, 730, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4004, 730, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [3]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4005, 731, 5, 268, 'Рост при 0-4% NaCl. [4]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4006, 731, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4007, 731, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4008, 731, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4009, 731, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4010, 731, 11, 34, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4011, 731, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4012, 731, 23, 81, 'Разложение коллоидного хитина. [4]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4013, 731, 24, 85, 'Разложение карбоксиметилцеллюлозы. [4]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_boolean VALUES (4014, 732, 2, 5, 'Скользящая подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4015, 732, 5, 268, 'Рост при 0-2% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4016, 732, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4017, 732, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4018, 732, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4019, 732, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4020, 732, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4021, 732, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4022, 732, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4023, 732, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4024, 732, 23, 81, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4025, 732, 36, 133, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4026, 732, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4027, 733, 2, 5, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4028, 733, 5, 268, 'Рост при 0-0.5% NaCl. [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4029, 733, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4030, 733, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4031, 733, 9, 25, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4032, 733, 10, 29, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4033, 733, 12, 37, 'Положителен на кислую фосфатазу и нафтол-AS-BI-фосфогидролазу. [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4034, 733, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4035, 733, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4036, 733, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4037, 733, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4038, 733, 19, 66, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4039, 733, 36, 134, 'Ассимиляция D-глюкозы. [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4040, 733, 28, 103, 'Слабоположительный (w+). [3, 4]', 'low', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4041, 733, 35, 130, 'Ассимиляция D-маннитола. [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_boolean VALUES (4042, 734, 2, 5, 'Скользящая подвижность. [1]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4043, 734, 5, 268, 'Рост при 0-1.0% NaCl. [1]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4044, 734, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4045, 734, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4046, 734, 9, 26, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4047, 734, 10, 29, 'Источник: Weon et al. (2007). [1]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4048, 734, 11, 34, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4049, 734, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4050, 734, 25, 90, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4051, 734, 27, 98, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4052, 734, 36, 133, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4053, 734, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4054, 735, 2, 6, 'Источник: Ngo et al. (2015). [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4055, 735, 5, 268, 'Рост при 0-1.0% NaCl. [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4056, 735, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4057, 735, 8, 23, 'Слабоположительный (w). [3]', 'low', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4058, 735, 9, 25, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4059, 735, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4060, 735, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4061, 735, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4062, 735, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4063, 735, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4064, 735, 23, 81, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4065, 735, 24, 85, 'Гидролиз КМ-целлюлозы. [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4066, 735, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4067, 735, 28, 101, 'Ассимиляция D-мальтозы. [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4068, 736, 7, 18, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4069, 736, 2, 6, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4070, 736, 10, 30, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4071, 736, 16, 54, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4072, 736, 19, 65, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4073, 736, 24, 85, 'Гидролиз КМЦ. [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4074, 736, 20, 69, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4075, 736, 18, 61, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4076, 736, 17, 58, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4077, 736, 13, 42, 'Липаза (C14). [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4078, 736, 28, 102, 'Ассимиляция D-мальтозы. [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_boolean VALUES (4085, 738, 2, 5, 'Скользящая подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4086, 738, 5, 268, 'Рост при 0-1.0% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4087, 738, 7, 17, 'Источник: Li et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4088, 738, 8, 21, 'Источник: Li et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4089, 738, 9, 25, 'Источник: Li et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4090, 738, 10, 29, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4091, 738, 18, 61, 'Из примечания к таблице в OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4092, 738, 13, 43, 'Эстераза (C4) (-), Эстераза липаза (C8) (-), Липаза (C14) (-), Трипсин (+), Химотрипсин (+). [1, 2]', 'low', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4093, 738, 33, 121, 'Ассимиляция D-трегалозы. [1, 2]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (1105, 172, 2, 5, 'Скользящая подвижность. [3, 4]', 'high', NULL, '2025-06-26 07:25:02.810458', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (1891, 172, 5, 268, 'Рост при 0-2.0% NaCl. [3, 4]', 'high', NULL, '2025-06-27 10:41:17.57901', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (1107, 172, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 07:25:02.810458', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (1106, 172, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 07:25:02.810458', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4098, 172, 9, 26, 'Источник: Singh et al. (2015). [3, 4]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4099, 172, 11, 34, 'Источник: Singh et al. (2015). [3, 4]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (1113, 172, 13, 43, 'Эстераза (C4) - слабоположительно (w). [3, 4]', 'low', NULL, '2025-06-26 07:25:02.810458', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (1109, 172, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 07:25:02.810458', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (1108, 172, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-26 07:25:02.810458', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4103, 172, 36, 133, 'Ассимиляция D-глюкозы. [3, 4]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (1112, 172, 28, 101, 'Ассимиляция мальтозы. [3, 4]', 'high', NULL, '2025-06-26 07:25:02.810458', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4105, 740, 2, 5, 'Скользящая подвижность. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4106, 740, 5, 268, 'Рост при 0-7.0% NaCl. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4107, 740, 7, 17, 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4108, 740, 8, 21, 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4109, 740, 9, 26, 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4110, 740, 11, 34, 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4111, 740, 13, 41, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4112, 740, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4113, 740, 36, 133, 'Ассимиляция D-глюкозы. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4114, 740, 28, 101, 'Ассимиляция D-мальтозы. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4115, 740, 33, 121, 'Ассимиляция D-трегалозы. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4116, 740, 40, 149, 'Ассимиляция D-целлобиозы. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4117, 740, 41, 153, 'Ассимиляция сахарозы. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_boolean VALUES (4118, 741, 2, 5, 'Скользящая подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4119, 741, 5, 268, 'Рост при 0-2.0% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4120, 741, 7, 17, 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4121, 741, 8, 21, 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4122, 741, 9, 26, 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4123, 741, 10, 30, 'Данные в OCR противоречивы (+/-), первоисточник указывает (-). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4124, 741, 11, 34, 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4125, 741, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4126, 741, 12, 37, 'Положителен на щелочную и кислую фосфатазу. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4127, 741, 16, 53, 'Данные в OCR противоречивы (+/-), первоисточник указывает (+). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4128, 741, 17, 57, 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4129, 741, 18, 61, 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4130, 741, 19, 65, 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4131, 741, 23, 82, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4132, 741, 25, 90, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4133, 741, 27, 98, 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4134, 741, 36, 133, 'Ассимиляция D-глюкозы. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4135, 741, 28, 101, 'Ассимиляция D-мальтозы. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4136, 741, 31, 113, 'Ассимиляция L-арабинозы. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4137, 741, 32, 117, 'Ассимиляция D-маннозы. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4138, 741, 33, 121, 'Ассимиляция трегалозы. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4139, 741, 35, 129, 'Ассимиляция D-маннитола. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4140, 741, 37, 137, 'Ассимиляция D-ксилозы. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4141, 741, 40, 149, 'Ассимиляция целлобиозы. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4142, 741, 41, 153, 'Ассимиляция сахарозы. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_boolean VALUES (4143, 742, 2, 6, 'В таблицах OCR указано ''N*'' (неподвижный) и ''-'' (отрицательный). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4144, 742, 5, 268, 'Рост при 0-2.0% NaCl. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4145, 742, 7, 17, 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4146, 742, 8, 21, 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4147, 742, 9, 26, 'В OCR указано ''+'', но первоисточник указывает ''-''. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4148, 742, 10, 31, 'Слабоположительный (w). [1]', 'low', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4149, 742, 11, 34, 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4150, 742, 13, 41, 'Положителен на эстеразу (C4), эстеразу липазу (C8) и липазу (C14). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4151, 742, 12, 37, 'Положителен на щелочную и кислую фосфатазу. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4152, 742, 16, 53, 'В OCR есть противоречивые данные (+/-), но первоисточник указывает (+). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4153, 742, 17, 57, 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4154, 742, 18, 61, 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4155, 742, 19, 65, 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4156, 742, 25, 90, 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4157, 742, 27, 98, 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4158, 742, 36, 133, 'Ассимиляция D-глюкозы. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4159, 742, 28, 101, 'Ассимиляция мальтозы. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4160, 742, 31, 114, 'Ассимиляция L-арабинозы. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4161, 742, 32, 117, 'Ассимиляция D-маннозы. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4162, 742, 33, 121, 'Ассимиляция трегалозы. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4163, 742, 35, 129, 'Ассимиляция D-маннитола. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4164, 742, 34, 125, 'Ассимиляция D-сорбита. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4165, 742, 41, 153, 'Ассимиляция сахарозы. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_boolean VALUES (4166, 743, 2, 5, 'Скользящая подвижность. [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4167, 743, 5, 268, 'Рост при 0-1.0% NaCl. [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4168, 743, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4169, 743, 8, 21, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4170, 743, 9, 26, 'Источник: Weon et al. (2006). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4171, 743, 13, 41, 'Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4172, 743, 16, 53, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4173, 743, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4174, 743, 18, 61, 'Источник: Weon et al. (2006). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4175, 743, 19, 65, 'Источник: Weon et al. (2006). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4176, 743, 20, 69, 'Источник: Weon et al. (2006). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4177, 743, 23, 81, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4178, 743, 36, 133, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4179, 743, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4180, 743, 31, 113, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4181, 744, 2, 5, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4182, 744, 5, 268, 'Рост при 0-3% NaCl. [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4183, 744, 7, 17, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4184, 744, 8, 23, 'Слабоположительный (+). [3, 4]', 'low', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4185, 744, 9, 26, 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4186, 744, 16, 54, 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4187, 744, 17, 57, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4188, 744, 18, 61, 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4189, 744, 19, 65, 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4190, 744, 20, 69, 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4191, 744, 23, 81, 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4192, 744, 36, 133, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_boolean VALUES (4193, 744, 28, 101, 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');


--
-- Data for Name: test_results_numeric; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

INSERT INTO lysobacter.test_results_numeric VALUES (353, 40, 79, 'minimum', 7.0000, 'pH', 'Optimal pH range 7-8', 'high', NULL, '2025-06-27 10:41:16.493403', '2025-06-27 10:51:52.367638');
INSERT INTO lysobacter.test_results_numeric VALUES (354, 40, 81, 'maximum', 8.0000, 'pH', 'Optimal pH range 7-8', 'high', NULL, '2025-06-27 10:41:16.493403', '2025-06-27 10:51:52.367638');
INSERT INTO lysobacter.test_results_numeric VALUES (373, 106, 76, 'minimum', 15.0000, '°C', 'Growth range 15-37°C', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (374, 106, 78, 'maximum', 37.0000, '°C', 'Growth range 15-37°C', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (352, 40, 77, 'optimal', 30.0000, '°C', 'Извлечено из OCR.', 'high', NULL, '2025-06-27 10:41:16.493403', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (378, 107, 79, 'minimum', 6.0000, 'pH', 'Growth range 6.0-10.0', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (379, 107, 81, 'maximum', 10.0000, 'pH', 'Growth range 6.0-10.0', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (381, 108, 76, 'minimum', 15.0000, '°C', 'Growth range 15-37°C', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (382, 108, 78, 'maximum', 37.0000, '°C', 'Growth range 15-37°C', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (403, 120, 76, 'minimum', 25.0000, '°C', 'Growth range 25-30°C', 'high', NULL, '2025-06-27 10:41:17.009519', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_numeric VALUES (404, 120, 78, 'maximum', 30.0000, '°C', 'Growth range 25-30°C', 'high', NULL, '2025-06-27 10:41:17.009519', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_numeric VALUES (405, 120, 79, 'minimum', 6.8000, 'pH', 'Growth range 6.8-7.5', 'high', NULL, '2025-06-27 10:41:17.009519', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_numeric VALUES (406, 120, 81, 'maximum', 7.5000, 'pH', 'Growth range 6.8-7.5', 'high', NULL, '2025-06-27 10:41:17.009519', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_numeric VALUES (424, 134, 76, 'minimum', 4.0000, '°C', 'Growth range 4-38°C.', 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (425, 134, 78, 'maximum', 38.0000, '°C', 'Growth range 4-38°C.', 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (32, 5, 44, 'single', 69.4000, '%', NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (59, 19, 44, 'single', 69.2000, '%', 'Value is cited from another source in the table.', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_numeric VALUES (62, 22, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%', 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-26 02:56:46.572336');
INSERT INTO lysobacter.test_results_numeric VALUES (60, 20, 44, 'single', 69.2000, '%', NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_numeric VALUES (64, 23, 5, 'maximum', 2.0000, '%', 'Growth range 0-2%', 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-26 02:56:46.572336');
INSERT INTO lysobacter.test_results_numeric VALUES (61, 21, 44, 'single', 69.2000, '%', 'Value is cited from another source.', 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_numeric VALUES (63, 22, 44, 'single', 69.2000, '%', 'Value is cited from another source.', 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_numeric VALUES (67, 23, 44, 'single', 69.2000, '%', NULL, 'high', NULL, '2025-06-26 02:08:43.428969', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_numeric VALUES (78, 43, 44, 'single', 70.7000, '%', 'Data from page 8. Page 5 shows 69.6%.', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_numeric VALUES (125, 77, 44, 'single', 67.7000, '%', NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_numeric VALUES (126, 81, 44, 'single', 67.7000, '%', NULL, 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_numeric VALUES (127, 82, 44, 'single', 67.7000, '%', 'Value is cited.', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_numeric VALUES (130, 83, 44, 'single', 67.7000, '%', 'Value is cited.', 'high', NULL, '2025-06-26 02:56:46.609219', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_numeric VALUES (146, 105, 44, 'single', 68.2000, '%', 'Value is cited from another source.', 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_numeric VALUES (383, 108, 79, 'minimum', 6.0000, 'pH', 'Growth range 6.0-9.0', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (426, 134, 77, 'optimal', 30.0000, '°C', NULL, 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (427, 134, 79, 'minimum', 6.0000, 'pH', 'Growth range 6.0-8.0.', 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (428, 134, 81, 'maximum', 8.0000, 'pH', 'Growth range 6.0-8.0.', 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (430, 138, 76, 'minimum', 10.0000, '°C', 'Growth range 10-37°C', 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (431, 138, 78, 'maximum', 37.0000, '°C', 'Growth range 10-37°C', 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (375, 106, 79, 'minimum', 6.0000, 'pH', 'Извлечено из диапазона 6.0-9.0 в OCR.', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (37, 2, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%', 'high', NULL, '2025-06-26 01:29:11.946964', '2025-06-26 02:56:46.559031');
INSERT INTO lysobacter.test_results_numeric VALUES (376, 106, 81, 'maximum', 9.0000, 'pH', 'Извлечено из диапазона 6.0-9.0 в OCR.', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (43, 4, 5, 'maximum', 7.0000, '%', 'Growth range 0-7%', 'high', NULL, '2025-06-26 01:29:11.946964', '2025-06-26 02:56:46.559031');
INSERT INTO lysobacter.test_results_numeric VALUES (45, 5, 5, 'maximum', 7.0000, '%', 'Growth range 0-7.0%', 'high', NULL, '2025-06-26 01:29:11.946964', '2025-06-26 02:56:46.559031');
INSERT INTO lysobacter.test_results_numeric VALUES (54, 19, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%', 'high', NULL, '2025-06-26 02:05:40.181', '2025-06-26 02:56:46.56493');
INSERT INTO lysobacter.test_results_numeric VALUES (49, 11, 44, 'single', 66.6000, '%', 'Value is cited from another source in the table.', 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-27 10:51:51.87673');
INSERT INTO lysobacter.test_results_numeric VALUES (26, 2, 44, 'single', 67.1000, '%', NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (31, 4, 44, 'single', 63.8000, '%', NULL, 'high', NULL, '2025-06-26 01:25:32.136319', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (77, 43, 5, 'maximum', 4.0000, '%', 'Growth range 0-4%. Page 8 shows 0-2%.', 'high', NULL, '2025-06-26 02:51:18.044327', '2025-06-26 02:56:46.602843');
INSERT INTO lysobacter.test_results_numeric VALUES (384, 108, 81, 'maximum', 9.0000, 'pH', 'Growth range 6.0-9.0', 'high', NULL, '2025-06-27 10:41:16.780313', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (47, 11, 5, 'minimum', 0.0000, '%', 'Growth range 0-6%', 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-26 02:56:46.618982');
INSERT INTO lysobacter.test_results_numeric VALUES (48, 11, 5, 'maximum', 6.0000, '%', 'Growth range 0-6%', 'high', NULL, '2025-06-26 01:39:52.018094', '2025-06-26 02:56:46.618982');
INSERT INTO lysobacter.test_results_numeric VALUES (145, 105, 5, 'maximum', 3.0000, '%', 'Growth range 0-3% (refined from multiple tables).', 'high', NULL, '2025-06-26 06:08:48.097892', '2025-06-26 06:08:48.097892');
INSERT INTO lysobacter.test_results_numeric VALUES (151, 106, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-26 06:11:46.884141');
INSERT INTO lysobacter.test_results_numeric VALUES (155, 107, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-26 06:11:46.884141');
INSERT INTO lysobacter.test_results_numeric VALUES (161, 108, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%. Data from page 70. Page 5 shows a conflicting range of 0-7.0%.', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-26 06:11:46.884141');
INSERT INTO lysobacter.test_results_numeric VALUES (167, 112, 5, 'maximum', 2.0000, '%', 'Growth range 0-2%', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-26 06:20:20.109378');
INSERT INTO lysobacter.test_results_numeric VALUES (186, 120, 44, 'single', 63.8000, '%', 'Conflicting data: 63.8% on pages 20, 23, 27, 43 vs 67.0% on page 6. The more frequent value was chosen.', 'low', NULL, '2025-06-26 06:27:04.328668', '2025-06-27 10:51:52.872535');
INSERT INTO lysobacter.test_results_numeric VALUES (408, 127, 76, 'minimum', 10.0000, '°C', 'Combined growth range from all tables is 10-40°C.', 'high', NULL, '2025-06-27 10:41:17.119192', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_numeric VALUES (409, 127, 78, 'maximum', 40.0000, '°C', 'Combined growth range from all tables is 10-40°C.', 'high', NULL, '2025-06-27 10:41:17.119192', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_numeric VALUES (180, 115, 5, 'maximum', 2.0000, '%', 'Growth range 0-2%.', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-26 06:24:48.508178');
INSERT INTO lysobacter.test_results_numeric VALUES (192, 127, 44, 'single', 69.3000, '%', 'Conflicting data: 69.3% on pages 31, 53 vs 61.7% on pages 48, 79. The more frequently cited value was chosen.', 'low', NULL, '2025-06-26 06:34:41.601951', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_numeric VALUES (199, 128, 44, 'single', 61.7000, '%', 'Value from BacDive and multiple tables in the PDF. Some tables showed a conflicting value of 69.3%.', 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_numeric VALUES (205, 132, 44, 'single', 67.1000, '%', 'Value from BacDive and multiple tables in the PDF. One table showed a conflicting value of 70.3%.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_numeric VALUES (434, 138, 81, 'maximum', 7.5000, 'pH', 'Growth range 6.0-7.5', 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (191, 127, 5, 'maximum', 7.0000, '%', 'Conflicting data: Ranges of 0-1%, 0-3%, and 0-7% were found. The widest range is reported.', 'low', NULL, '2025-06-26 06:34:41.601951', '2025-06-26 06:34:41.601951');
INSERT INTO lysobacter.test_results_numeric VALUES (435, 138, 80, 'optimal', 7.0000, 'pH', NULL, 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (451, 170, 79, 'minimum', 5.0000, 'pH', 'Growth range 5.0-9.0.', 'high', NULL, '2025-06-27 10:41:17.473608', '2025-06-27 10:51:53.323451');
INSERT INTO lysobacter.test_results_numeric VALUES (152, 106, 44, 'single', 70.6000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (181, 115, 44, 'single', 70.7000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-26 06:24:48.508178', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (198, 128, 5, 'maximum', 3.0000, '%', 'Growth range 0-3%.', 'high', NULL, '2025-06-26 06:48:31.463937', '2025-06-26 06:48:31.463937');
INSERT INTO lysobacter.test_results_numeric VALUES (204, 132, 5, 'maximum', 6.0000, '%', 'Growth range 0-6%.', 'high', NULL, '2025-06-26 06:52:03.607207', '2025-06-26 06:52:03.607207');
INSERT INTO lysobacter.test_results_numeric VALUES (211, 134, 5, 'maximum', 0.5000, '%', 'Growth range 0-0.5%.', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-26 06:57:10.819485');
INSERT INTO lysobacter.test_results_numeric VALUES (355, 43, 76, 'minimum', 4.0000, '°C', 'Growth range 4-37°C', 'high', NULL, '2025-06-27 10:41:16.54551', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_numeric VALUES (356, 43, 78, 'maximum', 37.0000, '°C', 'Growth range 4-37°C', 'high', NULL, '2025-06-27 10:41:16.54551', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_numeric VALUES (357, 43, 77, 'optimal', 28.0000, '°C', NULL, 'high', NULL, '2025-06-27 10:41:16.54551', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_numeric VALUES (358, 43, 79, 'minimum', 5.0000, 'pH', 'Growth range 5-9', 'high', NULL, '2025-06-27 10:41:16.54551', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_numeric VALUES (359, 43, 81, 'maximum', 9.0000, 'pH', 'Growth range 5-9', 'high', NULL, '2025-06-27 10:41:16.54551', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_numeric VALUES (360, 43, 80, 'optimal', 7.0000, 'pH', NULL, 'high', NULL, '2025-06-27 10:41:16.54551', '2025-06-27 10:51:52.420486');
INSERT INTO lysobacter.test_results_numeric VALUES (156, 107, 44, 'single', 68.7000, '%', NULL, 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (162, 108, 44, 'single', 70.6000, '%', 'Data from page 70. Page 5 shows a conflicting value of 69.4%.', 'high', NULL, '2025-06-26 06:11:46.884141', '2025-06-27 10:51:52.647616');
INSERT INTO lysobacter.test_results_numeric VALUES (386, 112, 76, 'minimum', 15.0000, '°C', 'Growth range 15-37°C', 'high', NULL, '2025-06-27 10:41:16.837563', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_numeric VALUES (387, 112, 78, 'maximum', 37.0000, '°C', 'Growth range 15-37°C', 'high', NULL, '2025-06-27 10:41:16.837563', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_numeric VALUES (388, 112, 79, 'minimum', 5.5000, 'pH', 'Growth range 5.5-8.5', 'high', NULL, '2025-06-27 10:41:16.837563', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_numeric VALUES (389, 112, 81, 'maximum', 8.5000, 'pH', 'Growth range 5.5-8.5', 'high', NULL, '2025-06-27 10:41:16.837563', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_numeric VALUES (168, 112, 44, 'single', 65.4000, '%', 'Value is consistent across multiple tables and citations.', 'high', NULL, '2025-06-26 06:20:20.109378', '2025-06-27 10:51:52.706755');
INSERT INTO lysobacter.test_results_numeric VALUES (175, 114, 44, 'single', 67.8000, '%', NULL, 'high', NULL, '2025-06-26 06:21:59.494506', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_numeric VALUES (410, 127, 79, 'minimum', 5.0000, 'pH', 'Combined growth range from all tables is 5.0-9.0.', 'high', NULL, '2025-06-27 10:41:17.119192', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_numeric VALUES (411, 127, 81, 'maximum', 9.0000, 'pH', 'Combined growth range from all tables is 5.0-9.0.', 'high', NULL, '2025-06-27 10:41:17.119192', '2025-06-27 10:51:52.978653');
INSERT INTO lysobacter.test_results_numeric VALUES (212, 134, 44, 'single', 68.1000, '%', 'Value from BacDive and multiple tables in the PDF.', 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (432, 138, 77, 'optimal', 28.0000, '°C', NULL, 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (433, 138, 79, 'minimum', 6.0000, 'pH', 'Growth range 6.0-7.5', 'high', NULL, '2025-06-27 10:41:17.284631', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (449, 170, 76, 'minimum', 20.0000, '°C', 'Growth range 20-37°C.', 'high', NULL, '2025-06-27 10:41:17.473608', '2025-06-27 10:51:53.323451');
INSERT INTO lysobacter.test_results_numeric VALUES (450, 170, 78, 'maximum', 37.0000, '°C', 'Growth range 20-37°C.', 'high', NULL, '2025-06-27 10:41:17.473608', '2025-06-27 10:51:53.323451');
INSERT INTO lysobacter.test_results_numeric VALUES (452, 170, 81, 'maximum', 9.0000, 'pH', 'Growth range 5.0-9.0.', 'high', NULL, '2025-06-27 10:41:17.473608', '2025-06-27 10:51:53.323451');
INSERT INTO lysobacter.test_results_numeric VALUES (462, 173, 76, 'minimum', 15.0000, '°C', 'Growth range 15-45°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.631892', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_numeric VALUES (463, 173, 78, 'maximum', 45.0000, '°C', 'Growth range 15-45°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.631892', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_numeric VALUES (464, 173, 77, 'optimal', 30.0000, '°C', 'From BacDive.', 'high', NULL, '2025-06-27 10:41:17.631892', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_numeric VALUES (330, 2, 76, 'minimum', 15.0000, '°C', 'Growth range 15-37°C', 'high', NULL, '2025-06-27 10:41:16.114924', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (331, 2, 78, 'maximum', 37.0000, '°C', 'Growth range 15-37°C', 'high', NULL, '2025-06-27 10:41:16.114924', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (332, 2, 79, 'minimum', 6.0000, 'pH', 'pH range 6.0-9.0', 'high', NULL, '2025-06-27 10:41:16.114924', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (333, 2, 81, 'maximum', 9.0000, 'pH', 'pH range 6.0-9.0', 'high', NULL, '2025-06-27 10:41:16.114924', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (335, 4, 76, 'minimum', 15.0000, '°C', 'Growth range 15-40°C', 'high', NULL, '2025-06-27 10:41:16.114924', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (336, 4, 78, 'maximum', 40.0000, '°C', 'Growth range 15-40°C', 'high', NULL, '2025-06-27 10:41:16.114924', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (337, 4, 79, 'minimum', 5.5000, 'pH', 'pH range 5.5-9.0', 'high', NULL, '2025-06-27 10:41:16.114924', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (338, 4, 81, 'maximum', 9.0000, 'pH', 'pH range 5.5-9.0', 'high', NULL, '2025-06-27 10:41:16.114924', '2025-06-27 10:51:51.986718');
INSERT INTO lysobacter.test_results_numeric VALUES (224, 139, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%.', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-26 07:07:28.925588');
INSERT INTO lysobacter.test_results_numeric VALUES (233, 145, 5, 'maximum', 2.0000, '%', 'Tolerates up to 2% NaCl (from BacDive).', 'high', NULL, '2025-06-26 07:15:30.110978', '2025-06-26 07:15:30.110978');
INSERT INTO lysobacter.test_results_numeric VALUES (238, 170, 5, 'maximum', 1.0000, '%', 'Growth range 0-1.0%.', 'high', NULL, '2025-06-26 07:17:39.437709', '2025-06-26 07:17:39.437709');
INSERT INTO lysobacter.test_results_numeric VALUES (239, 170, 44, 'single', 69.0000, '%', NULL, 'high', NULL, '2025-06-26 07:17:39.437709', '2025-06-27 10:51:53.323451');
INSERT INTO lysobacter.test_results_numeric VALUES (244, 171, 5, 'maximum', 0.5000, '%', 'Growth range 0-0.5%.', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-26 07:22:26.618307');
INSERT INTO lysobacter.test_results_numeric VALUES (248, 172, 44, 'single', 66.9000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-26 07:25:02.810458', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (255, 173, 5, 'maximum', 3.0000, '%', 'Tolerates up to 3% NaCl (from BacDive).', 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-26 07:31:04.56484');
INSERT INTO lysobacter.test_results_numeric VALUES (465, 173, 79, 'minimum', 5.0000, 'pH', 'Growth range 5.0-9.0 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.631892', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_numeric VALUES (262, 176, 44, 'single', 65.7000, '%', 'Value from BacDive and multiple tables in the PDF.', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_numeric VALUES (261, 176, 5, 'maximum', 2.0000, '%', 'Tolerates up to 2% NaCl.', 'high', NULL, '2025-06-26 07:33:14.429692', '2025-06-26 07:33:14.429692');
INSERT INTO lysobacter.test_results_numeric VALUES (265, 186, 5, 'maximum', 0.5000, '%', 'Growth range 0-0.5%.', 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-26 07:35:10.644027');
INSERT INTO lysobacter.test_results_numeric VALUES (474, 186, 76, 'minimum', 10.0000, '°C', 'Growth range 10-30°C.', 'high', NULL, '2025-06-27 10:41:17.752763', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_numeric VALUES (273, 187, 44, 'single', 68.0000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_numeric VALUES (272, 187, 5, 'maximum', 0.5000, '%', 'Growth range 0-0.5%.', 'high', NULL, '2025-06-26 07:37:24.903408', '2025-06-26 07:37:24.903408');
INSERT INTO lysobacter.test_results_numeric VALUES (483, 191, 76, 'minimum', 10.0000, '°C', 'Growth range 10-40°C.', 'high', NULL, '2025-06-27 10:41:17.861725', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_numeric VALUES (495, 195, 76, 'minimum', 10.0000, '°C', 'Growth range 10-30°C.', 'high', NULL, '2025-06-27 10:41:17.976415', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_numeric VALUES (279, 191, 5, 'maximum', 1.0000, '%', 'Tolerates up to 1% NaCl.', 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-26 07:40:33.583319');
INSERT INTO lysobacter.test_results_numeric VALUES (509, 200, 76, 'minimum', 15.0000, '°C', 'Growth range 15-37°C.', 'high', NULL, '2025-06-27 10:41:18.083889', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (286, 194, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%.', 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-26 07:46:04.762326');
INSERT INTO lysobacter.test_results_numeric VALUES (365, 83, 76, 'minimum', 4.0000, '°C', 'Growth range 4-50°C. Value is cited.', 'high', NULL, '2025-06-27 10:41:16.602311', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_numeric VALUES (391, 114, 76, 'minimum', 10.0000, '°C', 'Growth range 10-37°C', 'high', NULL, '2025-06-27 10:41:16.893922', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_numeric VALUES (392, 114, 78, 'maximum', 37.0000, '°C', 'Growth range 10-37°C', 'high', NULL, '2025-06-27 10:41:16.893922', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_numeric VALUES (413, 128, 76, 'minimum', 10.0000, '°C', 'Growth range 10-37°C.', 'high', NULL, '2025-06-27 10:41:17.174644', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_numeric VALUES (414, 128, 78, 'maximum', 37.0000, '°C', 'Growth range 10-37°C.', 'high', NULL, '2025-06-27 10:41:17.174644', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_numeric VALUES (415, 128, 77, 'optimal', 28.0000, '°C', NULL, 'high', NULL, '2025-06-27 10:41:17.174644', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_numeric VALUES (416, 128, 79, 'minimum', 6.0000, 'pH', 'Growth range 6.0-8.0.', 'high', NULL, '2025-06-27 10:41:17.174644', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_numeric VALUES (219, 138, 44, 'single', 68.2000, '%', NULL, 'high', NULL, '2025-06-26 06:57:10.819485', '2025-06-27 10:51:53.145016');
INSERT INTO lysobacter.test_results_numeric VALUES (437, 139, 76, 'minimum', 5.0000, '°C', 'Growth range 5-40°C.', 'high', NULL, '2025-06-27 10:41:17.341366', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_numeric VALUES (438, 139, 78, 'maximum', 40.0000, '°C', 'Growth range 5-40°C.', 'high', NULL, '2025-06-27 10:41:17.341366', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_numeric VALUES (439, 139, 79, 'minimum', 4.0000, 'pH', 'Growth range 4.0-10.0.', 'high', NULL, '2025-06-27 10:41:17.341366', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_numeric VALUES (440, 139, 81, 'maximum', 10.0000, 'pH', 'Growth range 4.0-10.0.', 'high', NULL, '2025-06-27 10:41:17.341366', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_numeric VALUES (225, 139, 44, 'single', 69.0000, '%', 'Value from BacDive and multiple tables in the PDF.', 'high', NULL, '2025-06-26 07:07:28.925588', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_numeric VALUES (456, 171, 79, 'minimum', 6.0000, 'pH', 'Growth range 6-8 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.525976', '2025-06-27 10:51:53.374602');
INSERT INTO lysobacter.test_results_numeric VALUES (457, 171, 81, 'maximum', 8.0000, 'pH', 'Growth range 6-8 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.525976', '2025-06-27 10:51:53.374602');
INSERT INTO lysobacter.test_results_numeric VALUES (466, 173, 81, 'maximum', 9.0000, 'pH', 'Growth range 5.0-9.0 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.631892', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_numeric VALUES (467, 173, 80, 'optimal', 7.0000, 'pH', 'From BacDive.', 'high', NULL, '2025-06-27 10:41:17.631892', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_numeric VALUES (256, 173, 44, 'single', 69.3000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:31:04.56484', '2025-06-27 10:51:53.478592');
INSERT INTO lysobacter.test_results_numeric VALUES (475, 186, 78, 'maximum', 30.0000, '°C', 'Growth range 10-30°C.', 'high', NULL, '2025-06-27 10:41:17.752763', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_numeric VALUES (266, 186, 44, 'single', 68.6000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:35:10.644027', '2025-06-27 10:51:53.587976');
INSERT INTO lysobacter.test_results_numeric VALUES (484, 191, 78, 'maximum', 40.0000, '°C', 'Growth range 10-40°C.', 'high', NULL, '2025-06-27 10:41:17.861725', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_numeric VALUES (485, 191, 77, 'optimal', 30.0000, '°C', 'Optimal range 28-30°C.', 'high', NULL, '2025-06-27 10:41:17.861725', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_numeric VALUES (486, 191, 79, 'minimum', 4.0000, 'pH', 'Growth range 4-9.', 'high', NULL, '2025-06-27 10:41:17.861725', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_numeric VALUES (487, 191, 81, 'maximum', 9.0000, 'pH', 'Growth range 4-9.', 'high', NULL, '2025-06-27 10:41:17.861725', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_numeric VALUES (496, 195, 78, 'maximum', 30.0000, '°C', 'Growth range 10-30°C.', 'high', NULL, '2025-06-27 10:41:17.976415', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_numeric VALUES (497, 195, 77, 'optimal', 25.0000, '°C', 'From BacDive.', 'high', NULL, '2025-06-27 10:41:17.976415', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_numeric VALUES (498, 195, 79, 'minimum', 5.5000, 'pH', 'Growth range 5.5-8.5.', 'high', NULL, '2025-06-27 10:41:17.976415', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_numeric VALUES (499, 195, 81, 'maximum', 8.5000, 'pH', 'Growth range 5.5-8.5.', 'high', NULL, '2025-06-27 10:41:17.976415', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_numeric VALUES (500, 195, 80, 'optimal', 7.0000, 'pH', 'From BacDive.', 'high', NULL, '2025-06-27 10:41:17.976415', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_numeric VALUES (510, 200, 78, 'maximum', 37.0000, '°C', 'Growth range 15-37°C.', 'high', NULL, '2025-06-27 10:41:18.083889', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (511, 200, 79, 'minimum', 6.0000, 'pH', 'Growth range 6-9.', 'high', NULL, '2025-06-27 10:41:18.083889', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (512, 200, 81, 'maximum', 9.0000, 'pH', 'Growth range 6-9.', 'high', NULL, '2025-06-27 10:41:18.083889', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (514, 203, 76, 'minimum', 5.0000, '°C', 'Growth range 5-37°C.', 'high', NULL, '2025-06-27 10:41:18.083889', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (515, 203, 78, 'maximum', 37.0000, '°C', 'Growth range 5-37°C.', 'high', NULL, '2025-06-27 10:41:18.083889', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (454, 171, 76, 'minimum', 15.0000, '°C', 'Извлечено из диапазона 15-37 в OCR.', 'high', NULL, '2025-06-27 10:41:17.525976', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (455, 171, 78, 'maximum', 37.0000, '°C', 'Извлечено из диапазона 15-37 в OCR.', 'high', NULL, '2025-06-27 10:41:17.525976', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (245, 171, 44, 'single', 68.7000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-26 07:22:26.618307', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (341, 19, 79, 'minimum', 5.0000, 'pH', 'Growth range 5-9', 'high', NULL, '2025-06-27 10:41:16.169451', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_numeric VALUES (366, 83, 78, 'maximum', 50.0000, '°C', 'Growth range 4-50°C. Value is cited.', 'high', NULL, '2025-06-27 10:41:16.602311', '2025-06-27 10:51:52.476509');
INSERT INTO lysobacter.test_results_numeric VALUES (393, 114, 77, 'optimal', 30.0000, '°C', NULL, 'high', NULL, '2025-06-27 10:41:16.893922', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_numeric VALUES (394, 114, 79, 'minimum', 6.0000, 'pH', 'Growth range 6.0-8.0', 'high', NULL, '2025-06-27 10:41:16.893922', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_numeric VALUES (417, 128, 81, 'maximum', 8.0000, 'pH', 'Growth range 6.0-8.0.', 'high', NULL, '2025-06-27 10:41:17.174644', '2025-06-27 10:51:53.033003');
INSERT INTO lysobacter.test_results_numeric VALUES (280, 191, 44, 'single', 68.9000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:40:33.583319', '2025-06-27 10:51:53.695488');
INSERT INTO lysobacter.test_results_numeric VALUES (516, 203, 79, 'minimum', 4.0000, 'pH', 'Growth range 4-9.', 'high', NULL, '2025-06-27 10:41:18.083889', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (294, 195, 5, 'maximum', 1.0000, '%', 'Growth range 0-1%.', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-26 07:48:31.490817');
INSERT INTO lysobacter.test_results_numeric VALUES (302, 196, 5, 'maximum', 7.0000, '%', 'Growth range 0-7%.', 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-26 07:50:15.081584');
INSERT INTO lysobacter.test_results_numeric VALUES (308, 200, 5, 'maximum', 0.5000, '%', 'Growth range 0-0.5%.', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-26 07:57:19.568773');
INSERT INTO lysobacter.test_results_numeric VALUES (320, 206, 5, 'maximum', 1.0000, '%', 'Tolerates up to 1% NaCl.', 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-26 07:59:40.869851');
INSERT INTO lysobacter.test_results_numeric VALUES (502, 196, 76, 'minimum', 20.0000, '°C', 'Growth range 20-40°C.', 'high', NULL, '2025-06-27 10:41:18.029543', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_numeric VALUES (309, 200, 44, 'single', 70.7000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (519, 206, 76, 'minimum', 10.0000, '°C', 'Growth range 10-40°C.', 'high', NULL, '2025-06-27 10:41:18.141803', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_numeric VALUES (398, 115, 76, 'minimum', 4.0000, '°C', 'Извлечено из диапазона 4-30 в OCR.', 'high', NULL, '2025-06-27 10:41:16.952343', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (399, 115, 78, 'maximum', 30.0000, '°C', 'Извлечено из диапазона 4-30 в OCR.', 'high', NULL, '2025-06-27 10:41:16.952343', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (342, 19, 81, 'maximum', 9.0000, 'pH', 'Growth range 5-9', 'high', NULL, '2025-06-27 10:41:16.169451', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_numeric VALUES (368, 105, 76, 'minimum', 10.0000, '°C', 'Growth range 10-37°C (refined from multiple tables).', 'high', NULL, '2025-06-27 10:41:16.725117', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_numeric VALUES (369, 105, 78, 'maximum', 37.0000, '°C', 'Growth range 10-37°C (refined from multiple tables).', 'high', NULL, '2025-06-27 10:41:16.725117', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_numeric VALUES (395, 114, 81, 'maximum', 8.0000, 'pH', 'Growth range 6.0-8.0', 'high', NULL, '2025-06-27 10:41:16.893922', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_numeric VALUES (396, 114, 80, 'optimal', 7.0000, 'pH', NULL, 'high', NULL, '2025-06-27 10:41:16.893922', '2025-06-27 10:51:52.76314');
INSERT INTO lysobacter.test_results_numeric VALUES (459, 172, 76, 'minimum', 10.0000, '°C', 'Источник: Singh et al. (2015). [3, 4]', 'high', NULL, '2025-06-27 10:41:17.57901', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (460, 172, 78, 'maximum', 28.0000, '°C', 'Источник: Singh et al. (2015). [3, 4]', 'high', NULL, '2025-06-27 10:41:17.57901', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (419, 132, 76, 'minimum', 10.0000, '°C', 'Growth range 10-37°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.231007', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_numeric VALUES (420, 132, 78, 'maximum', 37.0000, '°C', 'Growth range 10-37°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.231007', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_numeric VALUES (421, 132, 79, 'minimum', 6.0000, 'pH', 'Growth range 6-9 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.231007', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_numeric VALUES (422, 132, 81, 'maximum', 9.0000, 'pH', 'Growth range 6-9 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.231007', '2025-06-27 10:51:53.088789');
INSERT INTO lysobacter.test_results_numeric VALUES (442, 148, 76, 'minimum', 28.0000, '°C', 'Optimal growth range 28-30°C', 'high', NULL, '2025-06-27 10:41:17.341366', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_numeric VALUES (443, 148, 78, 'maximum', 30.0000, '°C', 'Optimal growth range 28-30°C', 'high', NULL, '2025-06-27 10:41:17.341366', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_numeric VALUES (444, 148, 80, 'optimal', 7.0000, 'pH', NULL, 'high', NULL, '2025-06-27 10:41:17.341366', '2025-06-27 10:51:53.199661');
INSERT INTO lysobacter.test_results_numeric VALUES (445, 145, 76, 'minimum', 10.0000, '°C', 'Growth range 10-40°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.41435', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_numeric VALUES (469, 176, 76, 'minimum', 10.0000, '°C', 'Growth range 10-40°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.688111', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_numeric VALUES (470, 176, 78, 'maximum', 40.0000, '°C', 'Growth range 10-40°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.688111', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_numeric VALUES (471, 176, 79, 'minimum', 4.0000, 'pH', 'Growth range 4-9 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.688111', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_numeric VALUES (472, 176, 81, 'maximum', 9.0000, 'pH', 'Growth range 4-9 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.688111', '2025-06-27 10:51:53.532828');
INSERT INTO lysobacter.test_results_numeric VALUES (477, 187, 76, 'minimum', 15.0000, '°C', 'Growth range 15-42°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.80663', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_numeric VALUES (478, 187, 78, 'maximum', 42.0000, '°C', 'Growth range 15-42°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.80663', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_numeric VALUES (479, 187, 77, 'optimal', 28.0000, '°C', 'Optimal range 28-30°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.80663', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_numeric VALUES (480, 187, 79, 'minimum', 6.0000, 'pH', 'Growth range 6-11.', 'high', NULL, '2025-06-27 10:41:17.80663', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_numeric VALUES (489, 194, 76, 'minimum', 10.0000, '°C', 'Growth range 10-37°C.', 'high', NULL, '2025-06-27 10:41:17.916372', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_numeric VALUES (490, 194, 78, 'maximum', 37.0000, '°C', 'Growth range 10-37°C.', 'high', NULL, '2025-06-27 10:41:17.916372', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_numeric VALUES (491, 194, 77, 'optimal', 28.0000, '°C', 'Optimal range 28-30°C.', 'high', NULL, '2025-06-27 10:41:17.916372', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_numeric VALUES (492, 194, 79, 'minimum', 6.0000, 'pH', 'Growth range 6.0-9.0.', 'high', NULL, '2025-06-27 10:41:17.916372', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_numeric VALUES (295, 195, 44, 'single', 69.1000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:48:31.490817', '2025-06-27 10:51:53.802508');
INSERT INTO lysobacter.test_results_numeric VALUES (503, 196, 78, 'maximum', 40.0000, '°C', 'Growth range 20-40°C.', 'high', NULL, '2025-06-27 10:41:18.029543', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_numeric VALUES (504, 196, 77, 'optimal', 30.0000, '°C', NULL, 'high', NULL, '2025-06-27 10:41:18.029543', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_numeric VALUES (505, 196, 79, 'minimum', 6.0000, 'pH', 'Growth range 6-8.', 'high', NULL, '2025-06-27 10:41:18.029543', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_numeric VALUES (506, 196, 81, 'maximum', 8.0000, 'pH', 'Growth range 6-8.', 'high', NULL, '2025-06-27 10:41:18.029543', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_numeric VALUES (517, 203, 81, 'maximum', 9.0000, 'pH', 'Growth range 4-9.', 'high', NULL, '2025-06-27 10:41:18.083889', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (314, 203, 44, 'single', 62.5000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:57:19.568773', '2025-06-27 10:51:53.90944');
INSERT INTO lysobacter.test_results_numeric VALUES (520, 206, 78, 'maximum', 40.0000, '°C', 'Growth range 10-40°C.', 'high', NULL, '2025-06-27 10:41:18.141803', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_numeric VALUES (521, 206, 77, 'optimal', 30.0000, '°C', 'Optimal range 28-30°C.', 'high', NULL, '2025-06-27 10:41:18.141803', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_numeric VALUES (522, 206, 79, 'minimum', 4.0000, 'pH', 'Growth range 4-9.', 'high', NULL, '2025-06-27 10:41:18.141803', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_numeric VALUES (523, 206, 81, 'maximum', 9.0000, 'pH', 'Growth range 4-9.', 'high', NULL, '2025-06-27 10:41:18.141803', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_numeric VALUES (321, 206, 44, 'single', 66.6000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:59:40.869851', '2025-06-27 10:51:53.965488');
INSERT INTO lysobacter.test_results_numeric VALUES (400, 115, 79, 'minimum', 6.0000, 'pH', 'Извлечено из диапазона 6-10 в OCR.', 'high', NULL, '2025-06-27 10:41:16.952343', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (401, 115, 81, 'maximum', 10.0000, 'pH', 'Извлечено из диапазона 6-10 в OCR.', 'high', NULL, '2025-06-27 10:41:16.952343', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (343, 19, 76, 'minimum', 4.0000, '°C', 'Growth range 4-40°C', 'high', NULL, '2025-06-27 10:41:16.169451', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_numeric VALUES (344, 19, 78, 'maximum', 40.0000, '°C', 'Growth range 4-40°C', 'high', NULL, '2025-06-27 10:41:16.169451', '2025-06-27 10:51:52.043039');
INSERT INTO lysobacter.test_results_numeric VALUES (349, 23, 76, 'minimum', 10.0000, '°C', 'Growth range 10-40°C', 'high', NULL, '2025-06-27 10:41:16.224177', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_numeric VALUES (350, 23, 78, 'maximum', 40.0000, '°C', 'Growth range 10-40°C', 'high', NULL, '2025-06-27 10:41:16.224177', '2025-06-27 10:51:52.098183');
INSERT INTO lysobacter.test_results_numeric VALUES (370, 105, 79, 'minimum', 7.0000, 'pH', 'Growth range 7-10.', 'high', NULL, '2025-06-27 10:41:16.725117', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_numeric VALUES (371, 105, 81, 'maximum', 10.0000, 'pH', 'Growth range 7-10.', 'high', NULL, '2025-06-27 10:41:16.725117', '2025-06-27 10:51:52.593982');
INSERT INTO lysobacter.test_results_numeric VALUES (446, 145, 78, 'maximum', 40.0000, '°C', 'Growth range 10-40°C (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.41435', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_numeric VALUES (447, 145, 79, 'minimum', 6.0000, 'pH', 'Growth range 6-9 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.41435', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_numeric VALUES (448, 145, 81, 'maximum', 9.0000, 'pH', 'Growth range 6-9 (from BacDive).', 'high', NULL, '2025-06-27 10:41:17.41435', '2025-06-27 10:51:53.270357');
INSERT INTO lysobacter.test_results_numeric VALUES (493, 194, 81, 'maximum', 9.0000, 'pH', 'Growth range 6.0-9.0.', 'high', NULL, '2025-06-27 10:41:17.916372', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_numeric VALUES (507, 196, 80, 'optimal', 7.0000, 'pH', NULL, 'high', NULL, '2025-06-27 10:41:18.029543', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_numeric VALUES (481, 187, 81, 'maximum', 11.0000, 'pH', 'Growth range 6-11.', 'high', NULL, '2025-06-27 10:41:17.80663', '2025-06-27 10:51:53.642637');
INSERT INTO lysobacter.test_results_numeric VALUES (287, 194, 44, 'single', 67.9000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:46:04.762326', '2025-06-27 10:51:53.7494');
INSERT INTO lysobacter.test_results_numeric VALUES (303, 196, 44, 'single', 68.6000, '%', 'Value is consistent between PDF and BacDive.', 'high', NULL, '2025-06-26 07:50:15.081584', '2025-06-27 10:51:53.855935');
INSERT INTO lysobacter.test_results_numeric VALUES (931, 684, 76, 'minimum', 5.0000, '°C', 'Рост отмечен как ''слабый''.', 'low', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_numeric VALUES (932, 684, 78, 'maximum', 30.0000, '°C', NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_numeric VALUES (933, 684, 44, 'single', 63.4000, '%', 'В таблице указано 63.4, в статье Margesin et al. (2018) - 63.35%. [4]', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_numeric VALUES (934, 685, 76, 'minimum', 10.0000, '°C', NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_numeric VALUES (935, 685, 77, 'optimal', 30.0000, '°C', 'Исходный источник указывал оптимальный диапазон 25-35°C. Используется среднее значение согласно инструкциям.', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_numeric VALUES (936, 685, 78, 'maximum', 35.0000, '°C', NULL, 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_numeric VALUES (937, 685, 80, 'optimal', 7.0000, 'pH', 'Источник: Singh et al. (2015). [1]', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_numeric VALUES (938, 685, 44, 'single', 62.5000, '%', 'Источник: Singh et al. (2015). [1]', 'high', NULL, '2025-06-28 02:44:37.959633', '2025-06-28 02:44:37.959633');
INSERT INTO lysobacter.test_results_numeric VALUES (939, 686, 76, 'minimum', 15.0000, '°C', 'Источник: BacDive. [3]', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_numeric VALUES (940, 686, 77, 'optimal', 30.0000, '°C', 'Источник: BacDive. [3]', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_numeric VALUES (941, 686, 78, 'maximum', 37.0000, '°C', 'Источник: BacDive. [3]', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_numeric VALUES (942, 686, 79, 'minimum', 6.0000, 'pH', 'Извлечено из диапазона 6.0-9.0 в OCR.', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_numeric VALUES (943, 686, 80, 'optimal', 7.0000, 'pH', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_numeric VALUES (944, 686, 81, 'maximum', 9.0000, 'pH', 'Извлечено из диапазона 6.0-9.0 в OCR.', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_numeric VALUES (945, 686, 44, 'single', 67.1000, '%', 'Источник: Bai et al. (2020). [1, 2]', 'high', NULL, '2025-06-28 07:47:08.669393', '2025-06-28 07:47:08.669393');
INSERT INTO lysobacter.test_results_numeric VALUES (946, 687, 76, 'minimum', 5.0000, '°C', 'Колонии также образовывались при -5°C. [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_numeric VALUES (947, 687, 77, 'optimal', 23.0000, '°C', 'Источник: Fukuda et al. (2013). [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_numeric VALUES (948, 687, 78, 'maximum', 25.0000, '°C', 'Источник: Fukuda et al. (2013). [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_numeric VALUES (949, 687, 79, 'minimum', 6.0000, 'pH', 'Извлечено из диапазона 6.0-9.0. [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_numeric VALUES (950, 687, 80, 'optimal', 7.5000, 'pH', 'Извлечено из диапазона 7.0-8.0. [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_numeric VALUES (951, 687, 81, 'maximum', 9.0000, 'pH', 'Извлечено из диапазона 6.0-9.0. [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_numeric VALUES (952, 687, 44, 'single', 66.1000, '%', 'Источник: Fukuda et al. (2013). [6]', 'high', NULL, '2025-06-28 07:49:04.951662', '2025-06-28 07:49:04.951662');
INSERT INTO lysobacter.test_results_numeric VALUES (953, 688, 77, 'optimal', 28.0000, '°C', 'Извлечено из таблицы ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (954, 688, 80, 'optimal', 7.5000, 'pH', 'Извлечено из диапазона 7-8 в таблице ''Сравнение фенотипических характеристик штаммов R7T и R19Т''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (955, 689, 44, 'single', 67.4000, '%', 'Извлечено из таблицы ''Биохимические и физиологические характеристики штамма THG-SKA3T''.', 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (956, 690, 44, 'single', 66.0000, '%', NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (957, 691, 76, 'minimum', 10.0000, '°C', NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (958, 691, 78, 'maximum', 37.0000, '°C', NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (959, 691, 79, 'minimum', 6.0000, 'pH', NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (960, 691, 81, 'maximum', 8.0000, 'pH', NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (961, 691, 44, 'single', 65.3000, '%', NULL, 'high', NULL, '2025-06-28 07:50:55.242479', '2025-06-28 07:50:55.242479');
INSERT INTO lysobacter.test_results_numeric VALUES (962, 692, 76, 'minimum', 10.0000, '°C', 'Извлечено из диапазона 10-42 в OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_numeric VALUES (963, 692, 77, 'optimal', 30.0000, '°C', 'Извлечено из диапазона 28-30 в OCR и подтверждено Choi et al. (2014). [2, 4]', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_numeric VALUES (964, 692, 78, 'maximum', 42.0000, '°C', 'Извлечено из диапазона 10-42 в OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_numeric VALUES (965, 692, 79, 'minimum', 5.0000, 'pH', 'Извлечено из диапазона 5-11 в OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_numeric VALUES (966, 692, 80, 'optimal', 7.0000, 'pH', 'Извлечено из OCR и подтверждено Choi et al. (2014). [2, 4]', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_numeric VALUES (967, 692, 81, 'maximum', 11.0000, 'pH', 'Извлечено из диапазона 5-11 в OCR.', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_numeric VALUES (968, 692, 44, 'single', 65.6000, '%', 'Источник: Choi et al. (2014). [2, 7]', 'high', NULL, '2025-06-28 07:53:00.30969', '2025-06-28 07:53:00.30969');
INSERT INTO lysobacter.test_results_numeric VALUES (969, 693, 76, 'minimum', 20.0000, '°C', 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (970, 693, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (971, 693, 78, 'maximum', 37.0000, '°C', 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (972, 693, 79, 'minimum', 6.0000, 'pH', 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (973, 693, 80, 'optimal', 7.0000, 'pH', 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (974, 693, 81, 'maximum', 8.0000, 'pH', 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (975, 693, 44, 'single', 67.0000, '%', 'Источник: Ten et al. (2009). [1]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (976, 179, 76, 'minimum', 4.0000, '°C', 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (977, 179, 77, 'optimal', 30.0000, '°C', 'Источник: BacDive. [13]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (978, 179, 78, 'maximum', 42.0000, '°C', 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (979, 179, 79, 'minimum', 5.0000, 'pH', 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (980, 179, 80, 'optimal', 7.2500, 'pH', 'Оптимальный диапазон 7.0-7.5. [13]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (981, 179, 81, 'maximum', 10.0000, 'pH', 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (982, 179, 44, 'single', 65.4000, '%', 'Источник: Srinivasan et al. (2010). [12]', 'high', NULL, '2025-06-28 07:55:31.590866', '2025-06-28 07:55:31.590866');
INSERT INTO lysobacter.test_results_numeric VALUES (983, 695, 76, 'minimum', 10.0000, '°C', 'Источник: Cai et al. (2021). [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_numeric VALUES (984, 695, 77, 'optimal', 25.0000, '°C', 'Оптимальный диапазон 20-30°C. [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_numeric VALUES (985, 695, 78, 'maximum', 45.0000, '°C', 'Источник: Cai et al. (2021). [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_numeric VALUES (986, 695, 79, 'minimum', 5.0000, 'pH', 'Источник: Cai et al. (2021). [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_numeric VALUES (987, 695, 80, 'optimal', 6.5000, 'pH', 'Оптимальный диапазон 6.0-7.0. [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_numeric VALUES (988, 695, 81, 'maximum', 10.0000, 'pH', 'Источник: Cai et al. (2021). [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_numeric VALUES (989, 695, 44, 'single', 68.8000, '%', 'Источник: Cai et al. (2021). [1, 2]', 'high', NULL, '2025-06-28 07:58:48.567273', '2025-06-28 07:58:48.567273');
INSERT INTO lysobacter.test_results_numeric VALUES (990, 696, 76, 'minimum', 4.0000, '°C', 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_numeric VALUES (991, 696, 77, 'optimal', 28.0000, '°C', 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_numeric VALUES (992, 696, 78, 'maximum', 32.0000, '°C', 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_numeric VALUES (993, 696, 79, 'minimum', 5.0000, 'pH', 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_numeric VALUES (994, 696, 80, 'optimal', 7.0000, 'pH', 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_numeric VALUES (995, 696, 81, 'maximum', 9.0000, 'pH', 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_numeric VALUES (996, 696, 44, 'single', 64.8000, '%', 'Источник: Siddiqi & Im (2016). [1, 2]', 'high', NULL, '2025-06-28 08:00:51.681277', '2025-06-28 08:00:51.681277');
INSERT INTO lysobacter.test_results_numeric VALUES (997, 697, 76, 'minimum', 4.0000, '°C', 'Извлечено из диапазона 4-37 в OCR.', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_numeric VALUES (998, 697, 78, 'maximum', 37.0000, '°C', 'Извлечено из диапазона 4-37 в OCR.', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_numeric VALUES (999, 697, 79, 'minimum', 6.0000, 'pH', 'Источник: BacDive. [4]', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_numeric VALUES (1000, 697, 81, 'maximum', 9.0000, 'pH', 'Источник: BacDive. [4]', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_numeric VALUES (1001, 697, 44, 'single', 66.5000, '%', 'Источник: Fang et al. (2020). [2]', 'high', NULL, '2025-06-28 08:02:14.256398', '2025-06-28 08:02:14.256398');
INSERT INTO lysobacter.test_results_numeric VALUES (1002, 698, 76, 'minimum', 18.0000, '°C', 'Извлечено из диапазона 18-28 в OCR.', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_numeric VALUES (1003, 698, 77, 'optimal', 28.0000, '°C', 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_numeric VALUES (1004, 698, 78, 'maximum', 28.0000, '°C', 'Извлечено из диапазона 18-28 в OCR.', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_numeric VALUES (1005, 698, 79, 'minimum', 5.0000, 'pH', 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_numeric VALUES (1006, 698, 80, 'optimal', 7.0000, 'pH', 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_numeric VALUES (1007, 698, 81, 'maximum', 9.0000, 'pH', 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_numeric VALUES (1008, 698, 44, 'single', 66.3000, '%', 'Источник: Du et al. (2015). [1, 2]', 'high', NULL, '2025-06-28 08:04:18.217889', '2025-06-28 08:04:18.217889');
INSERT INTO lysobacter.test_results_numeric VALUES (1016, 700, 76, 'minimum', 10.0000, '°C', 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_numeric VALUES (1017, 700, 77, 'optimal', 28.0000, '°C', 'Оптимальный диапазон 25-30°C. [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_numeric VALUES (1018, 700, 78, 'maximum', 30.0000, '°C', 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_numeric VALUES (1019, 700, 79, 'minimum', 6.0000, 'pH', 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_numeric VALUES (1020, 700, 80, 'optimal', 7.0000, 'pH', 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_numeric VALUES (1021, 700, 81, 'maximum', 8.0000, 'pH', 'Источник: Park et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_numeric VALUES (1022, 700, 44, 'single', 71.5000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:08:11.075227', '2025-06-28 08:08:11.075227');
INSERT INTO lysobacter.test_results_numeric VALUES (1023, 701, 76, 'minimum', 10.0000, '°C', 'Извлечено из диапазона 10-40 в OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_numeric VALUES (1024, 701, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [1, 2]', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_numeric VALUES (1025, 701, 78, 'maximum', 40.0000, '°C', 'Извлечено из диапазона 10-40 в OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_numeric VALUES (1026, 701, 79, 'minimum', 5.0000, 'pH', 'Источник: Kim et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_numeric VALUES (1027, 701, 80, 'optimal', 6.5000, 'pH', 'Оптимальный диапазон 6.0-7.0. [1, 2]', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_numeric VALUES (1028, 701, 81, 'maximum', 9.0000, 'pH', 'Источник: Kim et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_numeric VALUES (1029, 701, 44, 'single', 63.0000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:10:22.874785', '2025-06-28 08:10:22.874785');
INSERT INTO lysobacter.test_results_numeric VALUES (1009, 699, 76, 'minimum', 15.0000, '°C', 'Извлечено из диапазона 15-37 в OCR.', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1010, 699, 77, 'optimal', 28.0000, '°C', 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1011, 699, 78, 'maximum', 37.0000, '°C', 'Извлечено из диапазона 15-37 в OCR.', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1012, 699, 79, 'minimum', 6.0000, 'pH', 'Извлечено из диапазона 6.0-9.0 в OCR.', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1013, 699, 80, 'optimal', 7.0000, 'pH', 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1014, 699, 81, 'maximum', 9.0000, 'pH', 'Извлечено из диапазона 6.0-9.0 в OCR.', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1015, 699, 44, 'single', 67.1000, '%', 'Источник: Wang et al. (2011). [1, 2]', 'high', NULL, '2025-06-28 08:05:41.237309', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1037, 703, 76, 'minimum', 4.0000, '°C', 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1038, 703, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1039, 703, 78, 'maximum', 42.0000, '°C', 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1040, 703, 79, 'minimum', 5.0000, 'pH', 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1041, 703, 80, 'optimal', 7.2500, 'pH', 'Оптимальный диапазон 7.0-7.5. [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1042, 703, 81, 'maximum', 10.5000, 'pH', 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1043, 703, 44, 'single', 65.4000, '%', 'Источник: Srinivasan et al. (2010). [4]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1044, 704, 76, 'minimum', 10.0000, '°C', 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1045, 704, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1046, 704, 78, 'maximum', 37.0000, '°C', 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1047, 704, 79, 'minimum', 5.0000, 'pH', 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1048, 704, 80, 'optimal', 7.0000, 'pH', 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1049, 704, 81, 'maximum', 9.0000, 'pH', 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1050, 704, 44, 'single', 69.2000, '%', 'Источник: Yassin et al. (2011). [6]', 'high', NULL, '2025-06-28 08:17:14.808024', '2025-06-28 08:17:14.808024');
INSERT INTO lysobacter.test_results_numeric VALUES (1051, 705, 77, 'optimal', 28.0000, '°C', 'Источник: Bae et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1052, 705, 80, 'optimal', 7.0000, 'pH', 'Источник: Bae et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1053, 705, 44, 'single', 63.8000, '%', 'Источник: Bae et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1056, 171, 80, 'optimal', 7.0000, 'pH', 'Источник: Yassin et al. (2008). [3, 4]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1058, 106, 77, 'optimal', 26.5000, '°C', 'Оптимальный диапазон 25-28°C. [5, 6]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1060, 106, 80, 'optimal', 7.0000, 'pH', 'Источник: Jung et al. (2012). [5, 6]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1063, 708, 77, 'optimal', 28.0000, '°C', 'Источник: Aslam et al. (2009). [7, 8]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1064, 708, 80, 'optimal', 7.0000, 'pH', 'Источник: Aslam et al. (2009). [7, 8]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1065, 708, 44, 'single', 68.0000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1066, 709, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1067, 709, 80, 'optimal', 7.0000, 'pH', 'Источник: Park et al. (2008). [9, 10]', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1068, 709, 44, 'single', 65.4000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:22:56.033373', '2025-06-28 08:22:56.033373');
INSERT INTO lysobacter.test_results_numeric VALUES (1069, 710, 76, 'minimum', 4.0000, '°C', 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1070, 710, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1071, 710, 78, 'maximum', 37.0000, '°C', 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1072, 710, 79, 'minimum', 5.5000, 'pH', 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1073, 710, 80, 'optimal', 7.2500, 'pH', 'Оптимальный диапазон 7.0-7.5. [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1074, 710, 81, 'maximum', 9.5000, 'pH', 'Источник: Romanenko et al. (2018). [1, 2]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1075, 710, 44, 'single', 69.3000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1076, 711, 76, 'minimum', 10.0000, '°C', 'Источник: Cai et al. (2021). [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1077, 711, 77, 'optimal', 25.0000, '°C', 'Оптимальный диапазон 20-30°C. [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1078, 711, 78, 'maximum', 45.0000, '°C', 'Источник: Cai et al. (2021). [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1079, 711, 79, 'minimum', 5.0000, 'pH', 'Источник: Cai et al. (2021). [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1080, 711, 80, 'optimal', 6.5000, 'pH', 'Оптимальный диапазон 6.0-7.0. [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1081, 711, 81, 'maximum', 10.0000, 'pH', 'Источник: Cai et al. (2021). [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1082, 711, 44, 'single', 68.8000, '%', 'Источник: Cai et al. (2021). [3, 4]', 'high', NULL, '2025-06-28 08:27:25.420929', '2025-06-28 08:27:25.420929');
INSERT INTO lysobacter.test_results_numeric VALUES (1083, 712, 44, 'single', 68.9000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1084, 713, 76, 'minimum', 15.0000, '°C', 'Источник: Liu et al. (2013). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1085, 713, 77, 'optimal', 33.5000, '°C', 'Оптимальный диапазон 25-42°C. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1086, 713, 78, 'maximum', 42.0000, '°C', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1087, 713, 79, 'minimum', 6.0000, 'pH', 'Извлечено из диапазона 6-10 в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1088, 713, 80, 'optimal', 7.0000, 'pH', 'Источник: Liu et al. (2013). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1089, 713, 81, 'maximum', 10.0000, 'pH', 'Извлечено из диапазона 6-10 в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1090, 713, 44, 'single', 70.2000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1091, 714, 76, 'minimum', 15.0000, '°C', 'Источник: Liu et al. (2013). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1092, 714, 77, 'optimal', 33.5000, '°C', 'Оптимальный диапазон 25-42°C. [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1093, 714, 78, 'maximum', 42.0000, '°C', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1094, 714, 79, 'minimum', 6.0000, 'pH', 'Извлечено из диапазона 6-11 в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1095, 714, 80, 'optimal', 7.0000, 'pH', 'Источник: Liu et al. (2013). [3, 4]', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1096, 714, 81, 'maximum', 11.0000, 'pH', 'Извлечено из диапазона 6-11 в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1097, 714, 44, 'single', 70.6000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1103, 716, 76, 'minimum', 4.0000, '°C', 'Извлечено из диапазона 4-37 в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1104, 716, 78, 'maximum', 37.0000, '°C', 'Извлечено из диапазона 4-37 в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1105, 716, 79, 'minimum', 6.0000, 'pH', 'Извлечено из диапазона 6.0-10.0 в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1106, 716, 81, 'maximum', 10.0000, 'pH', 'Извлечено из диапазона 6.0-10.0 в OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1107, 716, 44, 'single', 67.7000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:31:30.960414', '2025-06-28 08:31:30.960414');
INSERT INTO lysobacter.test_results_numeric VALUES (1108, 717, 44, 'single', 69.0000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1109, 718, 80, 'optimal', 6.8000, 'pH', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1110, 718, 44, 'single', 68.1000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1111, 719, 44, 'single', 69.7000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1112, 720, 76, 'minimum', 14.0000, '°C', 'Извлечено из диапазона 14-38 в OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1113, 720, 77, 'optimal', 21.5000, '°C', 'Оптимальный диапазон 18-25°C. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1114, 720, 78, 'maximum', 38.0000, '°C', 'Извлечено из диапазона 14-38 в OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1115, 720, 79, 'minimum', 4.6000, 'pH', 'Извлечено из диапазона 4.6-8.3 в OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1116, 720, 80, 'optimal', 7.3000, 'pH', 'Оптимальный диапазон 6.9-7.7. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1117, 720, 81, 'maximum', 8.3000, 'pH', 'Извлечено из диапазона 4.6-8.3 в OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1118, 720, 44, 'single', 74.4000, '%', 'Извлечено из OCR (74.4±1.5).', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1119, 721, 76, 'minimum', 11.0000, '°C', 'Извлечено из диапазона 11-40 в OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1120, 721, 77, 'optimal', 21.0000, '°C', 'Оптимальный диапазон 16-26°C. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1121, 721, 78, 'maximum', 40.0000, '°C', 'Извлечено из диапазона 11-40 в OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1122, 721, 79, 'minimum', 4.6000, 'pH', 'Извлечено из диапазона 4.6-8.3 в OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1123, 721, 80, 'optimal', 6.7500, 'pH', 'Оптимальный диапазон 6.2-7.3. [7]', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1124, 721, 81, 'maximum', 8.3000, 'pH', 'Извлечено из диапазона 4.6-8.3 в OCR.', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1125, 721, 44, 'single', 75.7000, '%', 'Извлечено из OCR (75.7±1.5).', 'high', NULL, '2025-06-28 08:33:23.64213', '2025-06-28 08:33:23.64213');
INSERT INTO lysobacter.test_results_numeric VALUES (1126, 722, 76, 'minimum', 10.0000, '°C', 'Извлечено из диапазона 10-42 в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1127, 722, 77, 'optimal', 30.0000, '°C', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1128, 722, 78, 'maximum', 42.0000, '°C', 'Извлечено из диапазона 10-42 в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1129, 722, 79, 'minimum', 5.0000, 'pH', 'Извлечено из диапазона 5-11 в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1130, 722, 80, 'optimal', 7.0000, 'pH', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1131, 722, 81, 'maximum', 11.0000, 'pH', 'Извлечено из диапазона 5-11 в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1132, 723, 76, 'minimum', 4.0000, '°C', 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1133, 723, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1134, 723, 78, 'maximum', 37.0000, '°C', 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1135, 723, 79, 'minimum', 5.5000, 'pH', 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1136, 723, 80, 'optimal', 7.2500, 'pH', 'Оптимальный диапазон 7.0-7.5. [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1137, 723, 81, 'maximum', 9.5000, 'pH', 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1138, 723, 44, 'single', 69.3000, '%', 'Источник: Romanenko et al. (2018). [3]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1139, 725, 76, 'minimum', 10.0000, '°C', 'Извлечено из диапазона 10-35 в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1140, 725, 77, 'optimal', 28.0000, '°C', 'Источник: Oh et al. (2011). [5]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1141, 725, 78, 'maximum', 35.0000, '°C', 'Извлечено из диапазона 10-35 в OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1142, 725, 80, 'optimal', 7.0000, 'pH', 'Источник: Oh et al. (2011). [5]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1143, 725, 44, 'single', 66.4000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1144, 726, 76, 'minimum', 10.0000, '°C', 'Источник: Kim et al. (2018). [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1145, 726, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1146, 726, 78, 'maximum', 40.0000, '°C', 'Источник: Kim et al. (2018). [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1147, 726, 79, 'minimum', 5.0000, 'pH', 'Источник: Kim et al. (2018). [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1148, 726, 80, 'optimal', 6.5000, 'pH', 'Оптимальный диапазон 6.0-7.0. [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1149, 726, 81, 'maximum', 9.0000, 'pH', 'Источник: Kim et al. (2018). [7]', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1150, 726, 44, 'single', 66.4000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:39:02.105974', '2025-06-28 08:39:02.105974');
INSERT INTO lysobacter.test_results_numeric VALUES (1151, 727, 77, 'optimal', 30.0000, '°C', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1152, 727, 80, 'optimal', 8.0000, 'pH', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1154, 40, 80, 'optimal', 7.5000, 'pH', 'Извлечено из диапазона 7-8 в OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1155, 731, 76, 'minimum', 10.0000, '°C', 'Извлечено из диапазона 10-30 в OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1156, 731, 77, 'optimal', 21.0000, '°C', 'Оптимальный диапазон 15-27°C. [4]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1157, 731, 78, 'maximum', 30.0000, '°C', 'Извлечено из диапазона 10-30 в OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1158, 731, 79, 'minimum', 5.4000, 'pH', 'Извлечено из диапазона 5.4-7.6 в OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1159, 731, 80, 'optimal', 6.1000, 'pH', 'Оптимальный диапазон 5.6-6.6. [4]', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1160, 731, 81, 'maximum', 7.6000, 'pH', 'Извлечено из диапазона 5.4-7.6 в OCR.', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1161, 731, 44, 'single', 75.8000, '%', 'Извлечено из OCR (75.8±1.5).', 'high', NULL, '2025-06-28 08:41:12.302332', '2025-06-28 08:41:12.302332');
INSERT INTO lysobacter.test_results_numeric VALUES (1162, 732, 76, 'minimum', 4.0000, '°C', 'Источник: Lee et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1163, 732, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [1, 2]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1164, 732, 78, 'maximum', 37.0000, '°C', 'Источник: Lee et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1165, 732, 79, 'minimum', 6.0000, 'pH', 'Источник: Lee et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1166, 732, 80, 'optimal', 7.0000, 'pH', 'Источник: Lee et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1167, 732, 81, 'maximum', 8.0000, 'pH', 'Источник: Lee et al. (2005). [1, 2]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1168, 732, 44, 'single', 68.9000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1169, 733, 76, 'minimum', 10.0000, '°C', 'Извлечено из диапазона 10-37 в OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1170, 733, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1171, 733, 78, 'maximum', 37.0000, '°C', 'Извлечено из диапазона 10-37 в OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1172, 733, 79, 'minimum', 6.0000, 'pH', 'Источник: Siddiqi & Im (2016). [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1173, 733, 80, 'optimal', 7.0000, 'pH', 'Источник: Siddiqi & Im (2016). [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1174, 733, 81, 'maximum', 9.0000, 'pH', 'Источник: Siddiqi & Im (2016). [3, 4]', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1175, 733, 44, 'single', 67.8000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:43:15.469519', '2025-06-28 08:43:15.469519');
INSERT INTO lysobacter.test_results_numeric VALUES (1176, 734, 77, 'optimal', 28.0000, '°C', 'Источник: Weon et al. (2007). [1]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1177, 734, 80, 'optimal', 7.0000, 'pH', 'Источник: Weon et al. (2007). [1]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1178, 734, 44, 'single', 67.3000, '%', 'В первоисточнике указано 66.6%. [1]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1179, 735, 76, 'minimum', 4.0000, '°C', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1180, 735, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1181, 735, 78, 'maximum', 37.0000, '°C', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1182, 735, 79, 'minimum', 5.0000, 'pH', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1183, 735, 80, 'optimal', 6.5000, 'pH', 'Оптимальный диапазон 6.0-7.0. [3]', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1184, 735, 81, 'maximum', 9.0000, 'pH', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1185, 735, 44, 'single', 66.3000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:45:38.897799', '2025-06-28 08:45:38.897799');
INSERT INTO lysobacter.test_results_numeric VALUES (1193, 738, 76, 'minimum', 4.0000, '°C', 'Извлечено из диапазона 4-32 в OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1194, 738, 77, 'optimal', 28.0000, '°C', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1195, 738, 78, 'maximum', 32.0000, '°C', 'Извлечено из диапазона 4-32 в OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1196, 738, 79, 'minimum', 6.5000, 'pH', 'Извлечено из диапазона 6.5-7.5 в OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1197, 738, 80, 'optimal', 7.0000, 'pH', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1198, 738, 81, 'maximum', 7.5000, 'pH', 'Извлечено из диапазона 6.5-7.5 в OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1199, 738, 44, 'single', 67.1000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1201, 172, 77, 'optimal', 25.0000, '°C', 'Источник: Singh et al. (2015). [3, 4]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1203, 172, 79, 'minimum', 5.0000, 'pH', 'Источник: Singh et al. (2015). [3, 4]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1204, 172, 80, 'optimal', 6.5000, 'pH', 'Оптимальный диапазон 6.0-7.0. [3, 4]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1205, 172, 81, 'maximum', 8.0000, 'pH', 'Источник: Singh et al. (2015). [3, 4]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1207, 740, 76, 'minimum', 4.0000, '°C', 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1208, 740, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1209, 740, 78, 'maximum', 37.0000, '°C', 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1210, 740, 79, 'minimum', 5.5000, 'pH', 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1211, 740, 80, 'optimal', 7.2500, 'pH', 'Оптимальный диапазон 7.0-7.5. [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1212, 740, 81, 'maximum', 9.5000, 'pH', 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1213, 740, 44, 'single', 69.3000, '%', 'Источник: Romanenko et al. (2018). [5, 6]', 'high', NULL, '2025-06-28 08:49:51.67424', '2025-06-28 08:49:51.67424');
INSERT INTO lysobacter.test_results_numeric VALUES (1214, 741, 76, 'minimum', 10.0000, '°C', 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_numeric VALUES (1215, 741, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_numeric VALUES (1216, 741, 78, 'maximum', 40.0000, '°C', 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_numeric VALUES (1217, 741, 79, 'minimum', 6.0000, 'pH', 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_numeric VALUES (1218, 741, 80, 'optimal', 7.0000, 'pH', 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_numeric VALUES (1219, 741, 81, 'maximum', 9.0000, 'pH', 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_numeric VALUES (1220, 741, 44, 'single', 63.5000, '%', 'Источник: Wang et al. (2009). [1, 2]', 'high', NULL, '2025-06-28 08:51:38.768394', '2025-06-28 08:51:38.768394');
INSERT INTO lysobacter.test_results_numeric VALUES (1221, 742, 76, 'minimum', 18.0000, '°C', 'Извлечено из диапазона 18-42 в OCR.', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_numeric VALUES (1222, 742, 77, 'optimal', 28.0000, '°C', 'Источник: Luo et al. (2011). [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_numeric VALUES (1223, 742, 78, 'maximum', 42.0000, '°C', 'Извлечено из диапазона 18-42 в OCR.', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_numeric VALUES (1224, 742, 79, 'minimum', 7.0000, 'pH', 'Извлечено из диапазона 7-11 в OCR.', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_numeric VALUES (1225, 742, 80, 'optimal', 7.5000, 'pH', 'Оптимальный диапазон 7.0-8.0. [1]', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_numeric VALUES (1226, 742, 81, 'maximum', 11.0000, 'pH', 'Извлечено из диапазона 7-11 в OCR.', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_numeric VALUES (1227, 742, 44, 'single', 69.7000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:53:23.449789', '2025-06-28 08:53:23.449789');
INSERT INTO lysobacter.test_results_numeric VALUES (1228, 743, 76, 'minimum', 10.0000, '°C', 'Источник: Weon et al. (2006). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1229, 743, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1230, 743, 78, 'maximum', 42.0000, '°C', 'Источник: Weon et al. (2006). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1231, 743, 79, 'minimum', 5.0000, 'pH', 'Источник: Weon et al. (2006). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1232, 743, 80, 'optimal', 6.5000, 'pH', 'Оптимальный диапазон 6.0-7.0. [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1233, 743, 81, 'maximum', 9.0000, 'pH', 'Источник: Weon et al. (2006). [1, 2]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1234, 743, 44, 'single', 67.3000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1235, 744, 76, 'minimum', 10.0000, '°C', 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1236, 744, 77, 'optimal', 29.0000, '°C', 'Оптимальный диапазон 28-30°C. [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1237, 744, 78, 'maximum', 37.0000, '°C', 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1238, 744, 79, 'minimum', 6.0000, 'pH', 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1239, 744, 80, 'optimal', 7.0000, 'pH', 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1240, 744, 81, 'maximum', 8.0000, 'pH', 'Источник: Weon et al. (2007). [3, 4]', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');
INSERT INTO lysobacter.test_results_numeric VALUES (1241, 744, 44, 'single', 61.7000, '%', 'Извлечено из OCR.', 'high', NULL, '2025-06-28 08:55:22.522263', '2025-06-28 08:55:22.522263');


--
-- Data for Name: test_results_text; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--



--
-- Name: audit_log_log_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.audit_log_log_id_seq', 1, false);


--
-- Name: collection_numbers_collection_number_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.collection_numbers_collection_number_id_seq', 66, true);


--
-- Name: data_sources_source_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.data_sources_source_id_seq', 1, false);


--
-- Name: species_species_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.species_species_id_seq', 63, true);


--
-- Name: strains_strain_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.strains_strain_id_seq', 745, true);


--
-- Name: test_categories_category_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_categories_category_id_seq', 24, true);


--
-- Name: test_results_boolean_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_boolean_result_id_seq', 4196, true);


--
-- Name: test_results_numeric_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_numeric_result_id_seq', 1247, true);


--
-- Name: test_results_text_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_text_result_id_seq', 38, true);


--
-- Name: test_values_value_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_values_value_id_seq', 431, true);


--
-- Name: tests_test_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.tests_test_id_seq', 169, true);


--
-- PostgreSQL database dump complete
--

