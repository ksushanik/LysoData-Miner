--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY lysobacter.tests DROP CONSTRAINT IF EXISTS tests_category_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_values DROP CONSTRAINT IF EXISTS test_values_test_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_text DROP CONSTRAINT IF EXISTS test_results_text_test_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_text DROP CONSTRAINT IF EXISTS test_results_text_strain_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_numeric DROP CONSTRAINT IF EXISTS test_results_numeric_test_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_numeric DROP CONSTRAINT IF EXISTS test_results_numeric_strain_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_boolean DROP CONSTRAINT IF EXISTS test_results_boolean_value_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_boolean DROP CONSTRAINT IF EXISTS test_results_boolean_test_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_boolean DROP CONSTRAINT IF EXISTS test_results_boolean_strain_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.strains DROP CONSTRAINT IF EXISTS strains_species_fk;
ALTER TABLE IF EXISTS ONLY lysobacter.strains DROP CONSTRAINT IF EXISTS strains_source_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.strains DROP CONSTRAINT IF EXISTS strains_master_strain_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.strain_collections DROP CONSTRAINT IF EXISTS strain_collections_strain_id_fkey;
ALTER TABLE IF EXISTS ONLY lysobacter.strain_collections DROP CONSTRAINT IF EXISTS strain_collections_collection_number_id_fkey;
DROP TRIGGER IF EXISTS update_strains_updated_at ON lysobacter.strains;
DROP TRIGGER IF EXISTS update_results_numeric_updated_at ON lysobacter.test_results_numeric;
DROP TRIGGER IF EXISTS update_results_boolean_updated_at ON lysobacter.test_results_boolean;
CREATE OR REPLACE VIEW lysobacter.v_category_statistics AS
SELECT
    NULL::character varying(100) AS category_name,
    NULL::text AS description,
    NULL::bigint AS total_tests,
    NULL::bigint AS active_tests,
    NULL::bigint AS strains_with_data;
CREATE OR REPLACE VIEW lysobacter.v_strains_complete AS
SELECT
    NULL::integer AS strain_id,
    NULL::character varying(100) AS strain_identifier,
    NULL::character varying(200) AS scientific_name,
    NULL::character varying(200) AS common_name,
    NULL::text AS description,
    NULL::text AS isolation_source,
    NULL::text AS isolation_location,
    NULL::date AS isolation_date,
    NULL::character varying(200) AS source_name,
    NULL::character varying(50) AS source_type,
    NULL::numeric(5,2) AS gc_content_min,
    NULL::numeric(5,2) AS gc_content_max,
    NULL::numeric(5,2) AS gc_content_optimal,
    NULL::text AS notes,
    NULL::boolean AS is_active,
    NULL::timestamp without time zone AS created_at,
    NULL::timestamp without time zone AS updated_at,
    NULL::text[] AS collection_numbers;
DROP INDEX IF EXISTS lysobacter.idx_tests_type;
DROP INDEX IF EXISTS lysobacter.idx_tests_category;
DROP INDEX IF EXISTS lysobacter.idx_tests_active;
DROP INDEX IF EXISTS lysobacter.idx_strains_text_search;
DROP INDEX IF EXISTS lysobacter.idx_strains_species;
DROP INDEX IF EXISTS lysobacter.idx_strains_source;
DROP INDEX IF EXISTS lysobacter.idx_strains_master_strain_id;
DROP INDEX IF EXISTS lysobacter.idx_strains_is_duplicate;
DROP INDEX IF EXISTS lysobacter.idx_strains_identifier;
DROP INDEX IF EXISTS lysobacter.idx_strains_active;
DROP INDEX IF EXISTS lysobacter.idx_results_text_strain;
DROP INDEX IF EXISTS lysobacter.idx_results_numeric_test;
DROP INDEX IF EXISTS lysobacter.idx_results_numeric_strain;
DROP INDEX IF EXISTS lysobacter.idx_results_boolean_test;
DROP INDEX IF EXISTS lysobacter.idx_results_boolean_strain;
ALTER TABLE IF EXISTS ONLY lysobacter.tests DROP CONSTRAINT IF EXISTS tests_test_code_key;
ALTER TABLE IF EXISTS ONLY lysobacter.tests DROP CONSTRAINT IF EXISTS tests_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.tests DROP CONSTRAINT IF EXISTS tests_category_id_test_name_key;
ALTER TABLE IF EXISTS ONLY lysobacter.test_values DROP CONSTRAINT IF EXISTS test_values_test_id_value_code_key;
ALTER TABLE IF EXISTS ONLY lysobacter.test_values DROP CONSTRAINT IF EXISTS test_values_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_text DROP CONSTRAINT IF EXISTS test_results_text_strain_id_test_id_key;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_text DROP CONSTRAINT IF EXISTS test_results_text_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_numeric DROP CONSTRAINT IF EXISTS test_results_numeric_strain_id_test_id_value_type_key;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_numeric DROP CONSTRAINT IF EXISTS test_results_numeric_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_boolean DROP CONSTRAINT IF EXISTS test_results_boolean_strain_id_test_id_key;
ALTER TABLE IF EXISTS ONLY lysobacter.test_results_boolean DROP CONSTRAINT IF EXISTS test_results_boolean_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_categories DROP CONSTRAINT IF EXISTS test_categories_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.test_categories DROP CONSTRAINT IF EXISTS test_categories_category_name_key;
ALTER TABLE IF EXISTS ONLY lysobacter.strains DROP CONSTRAINT IF EXISTS strains_strain_identifier_key;
ALTER TABLE IF EXISTS ONLY lysobacter.strains DROP CONSTRAINT IF EXISTS strains_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.strain_collections DROP CONSTRAINT IF EXISTS strain_collections_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.species DROP CONSTRAINT IF EXISTS species_scientific_name_key;
ALTER TABLE IF EXISTS ONLY lysobacter.species DROP CONSTRAINT IF EXISTS species_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.data_sources DROP CONSTRAINT IF EXISTS data_sources_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.collection_numbers DROP CONSTRAINT IF EXISTS collection_numbers_pkey;
ALTER TABLE IF EXISTS ONLY lysobacter.collection_numbers DROP CONSTRAINT IF EXISTS collection_numbers_collection_code_collection_number_key;
ALTER TABLE IF EXISTS ONLY lysobacter.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS lysobacter.tests ALTER COLUMN test_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.test_values ALTER COLUMN value_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.test_results_text ALTER COLUMN result_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.test_results_numeric ALTER COLUMN result_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.test_results_boolean ALTER COLUMN result_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.test_categories ALTER COLUMN category_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.strains ALTER COLUMN strain_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.species ALTER COLUMN species_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.data_sources ALTER COLUMN source_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.collection_numbers ALTER COLUMN collection_number_id DROP DEFAULT;
ALTER TABLE IF EXISTS lysobacter.audit_log ALTER COLUMN log_id DROP DEFAULT;
DROP VIEW IF EXISTS lysobacter.v_test_results_summary;
DROP VIEW IF EXISTS lysobacter.v_test_completion;
DROP VIEW IF EXISTS lysobacter.v_strains_complete;
DROP VIEW IF EXISTS lysobacter.v_strain_completeness;
DROP VIEW IF EXISTS lysobacter.v_category_statistics;
DROP SEQUENCE IF EXISTS lysobacter.tests_test_id_seq;
DROP TABLE IF EXISTS lysobacter.tests;
DROP SEQUENCE IF EXISTS lysobacter.test_values_value_id_seq;
DROP TABLE IF EXISTS lysobacter.test_values;
DROP SEQUENCE IF EXISTS lysobacter.test_results_text_result_id_seq;
DROP TABLE IF EXISTS lysobacter.test_results_text;
DROP SEQUENCE IF EXISTS lysobacter.test_results_numeric_result_id_seq;
DROP TABLE IF EXISTS lysobacter.test_results_numeric;
DROP SEQUENCE IF EXISTS lysobacter.test_results_boolean_result_id_seq;
DROP TABLE IF EXISTS lysobacter.test_results_boolean;
DROP SEQUENCE IF EXISTS lysobacter.test_categories_category_id_seq;
DROP TABLE IF EXISTS lysobacter.test_categories;
DROP SEQUENCE IF EXISTS lysobacter.strains_strain_id_seq;
DROP TABLE IF EXISTS lysobacter.strains;
DROP TABLE IF EXISTS lysobacter.strain_collections;
DROP SEQUENCE IF EXISTS lysobacter.species_species_id_seq;
DROP TABLE IF EXISTS lysobacter.species;
DROP SEQUENCE IF EXISTS lysobacter.data_sources_source_id_seq;
DROP TABLE IF EXISTS lysobacter.data_sources;
DROP SEQUENCE IF EXISTS lysobacter.collection_numbers_collection_number_id_seq;
DROP TABLE IF EXISTS lysobacter.collection_numbers;
DROP SEQUENCE IF EXISTS lysobacter.audit_log_log_id_seq;
DROP TABLE IF EXISTS lysobacter.audit_log;
DROP FUNCTION IF EXISTS lysobacter.validate_strain_data();
DROP FUNCTION IF EXISTS lysobacter.update_updated_at_column();
DROP FUNCTION IF EXISTS lysobacter.search_strains_with_tolerance(p_criteria jsonb, p_tolerance integer);
DROP FUNCTION IF EXISTS lysobacter.get_strain_test_profile(p_strain_id integer);
DROP FUNCTION IF EXISTS lysobacter.bulk_import_strain_results(p_strain_identifier character varying, p_test_results jsonb);
DROP SCHEMA IF EXISTS lysobacter;
--
-- Name: lysobacter; Type: SCHEMA; Schema: -; Owner: lysobacter_user
--

CREATE SCHEMA lysobacter;


ALTER SCHEMA lysobacter OWNER TO lysobacter_user;

--
-- Name: bulk_import_strain_results(character varying, jsonb); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.bulk_import_strain_results(p_strain_identifier character varying, p_test_results jsonb) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_strain_id INTEGER;
    test_result JSONB;
    v_test_id INTEGER;
    v_value_id INTEGER;
BEGIN
    -- Get strain ID
    SELECT strain_id INTO v_strain_id 
    FROM lysobacter.strains 
    WHERE strain_identifier = p_strain_identifier AND is_active = TRUE;
    
    IF v_strain_id IS NULL THEN
        RAISE EXCEPTION 'Strain not found: %', p_strain_identifier;
    END IF;
    
    -- Process each test result
    FOR test_result IN SELECT jsonb_array_elements(p_test_results)
    LOOP
        -- Get test ID
        SELECT test_id INTO v_test_id
        FROM lysobacter.tests
        WHERE test_code = test_result->>'test_code' AND is_active = TRUE;
        
        IF v_test_id IS NULL THEN
            CONTINUE; -- Skip unknown tests
        END IF;
        
        -- Handle boolean results
        IF test_result->>'test_type' = 'boolean' THEN
            SELECT value_id INTO v_value_id
            FROM lysobacter.test_values
            WHERE test_id = v_test_id AND value_code = test_result->>'value';
            
            IF v_value_id IS NOT NULL THEN
                INSERT INTO lysobacter.test_results_boolean 
                (strain_id, test_id, value_id, notes, confidence_level)
                VALUES (v_strain_id, v_test_id, v_value_id, 
                       test_result->>'notes', 
                       COALESCE(test_result->>'confidence_level', 'high'))
                ON CONFLICT (strain_id, test_id) 
                DO UPDATE SET 
                    value_id = EXCLUDED.value_id,
                    notes = EXCLUDED.notes,
                    confidence_level = EXCLUDED.confidence_level,
                    updated_at = CURRENT_TIMESTAMP;
            END IF;
            
        -- Handle numeric results
        ELSIF test_result->>'test_type' = 'numeric' THEN
            INSERT INTO lysobacter.test_results_numeric 
            (strain_id, test_id, value_type, numeric_value, measurement_unit, notes, confidence_level)
            VALUES (v_strain_id, v_test_id, 
                   test_result->>'value_type',
                   (test_result->>'numeric_value')::DECIMAL,
                   test_result->>'measurement_unit',
                   test_result->>'notes', 
                   COALESCE(test_result->>'confidence_level', 'high'))
            ON CONFLICT (strain_id, test_id, value_type) 
            DO UPDATE SET 
                numeric_value = EXCLUDED.numeric_value,
                measurement_unit = EXCLUDED.measurement_unit,
                notes = EXCLUDED.notes,
                confidence_level = EXCLUDED.confidence_level,
                updated_at = CURRENT_TIMESTAMP;
                
        -- Handle text results
        ELSIF test_result->>'test_type' = 'text' THEN
            INSERT INTO lysobacter.test_results_text 
            (strain_id, test_id, text_value, notes, confidence_level)
            VALUES (v_strain_id, v_test_id, 
                   test_result->>'text_value',
                   test_result->>'notes', 
                   COALESCE(test_result->>'confidence_level', 'high'))
            ON CONFLICT (strain_id, test_id) 
            DO UPDATE SET 
                text_value = EXCLUDED.text_value,
                notes = EXCLUDED.notes,
                confidence_level = EXCLUDED.confidence_level,
                updated_at = CURRENT_TIMESTAMP;
        END IF;
    END LOOP;
    
    RETURN TRUE;
END;
$$;


ALTER FUNCTION lysobacter.bulk_import_strain_results(p_strain_identifier character varying, p_test_results jsonb) OWNER TO lysobacter_user;

--
-- Name: get_strain_test_profile(integer); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.get_strain_test_profile(p_strain_id integer) RETURNS TABLE(category_name character varying, test_name character varying, test_type character varying, result_value text, confidence_level character varying, tested_date date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tc.category_name,
        t.test_name,
        t.test_type,
        CASE 
            WHEN t.test_type = 'boolean' THEN tv.value_name
            WHEN t.test_type = 'numeric' THEN 
                trn.value_type || ': ' || trn.numeric_value::text || 
                COALESCE(' ' || trn.measurement_unit, '')
            WHEN t.test_type = 'text' THEN trt.text_value
        END as result_value,
        COALESCE(trb.confidence_level, trn.confidence_level, trt.confidence_level) as confidence_level,
        COALESCE(trb.tested_date, trn.tested_date, trt.tested_date) as tested_date
    FROM lysobacter.tests t
    JOIN lysobacter.test_categories tc ON t.category_id = tc.category_id
    LEFT JOIN lysobacter.test_results_boolean trb ON t.test_id = trb.test_id AND trb.strain_id = p_strain_id
    LEFT JOIN lysobacter.test_values tv ON trb.value_id = tv.value_id
    LEFT JOIN lysobacter.test_results_numeric trn ON t.test_id = trn.test_id AND trn.strain_id = p_strain_id
    LEFT JOIN lysobacter.test_results_text trt ON t.test_id = trt.test_id AND trt.strain_id = p_strain_id
    WHERE (trb.result_id IS NOT NULL OR trn.result_id IS NOT NULL OR trt.result_id IS NOT NULL)
    AND t.is_active = TRUE
    ORDER BY tc.sort_order, t.sort_order;
END;
$$;


ALTER FUNCTION lysobacter.get_strain_test_profile(p_strain_id integer) OWNER TO lysobacter_user;

--
-- Name: search_strains_with_tolerance(jsonb, integer); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.search_strains_with_tolerance(p_criteria jsonb, p_tolerance integer DEFAULT 0) RETURNS TABLE(strain_id integer, strain_identifier character varying, scientific_name character varying, match_score integer, total_criteria integer, matching_criteria integer, conflicting_criteria integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    criterion JSONB;
    test_name_key TEXT;
    expected_value TEXT;
    total_criteria_count INTEGER;
BEGIN
    -- Create temporary table for results
    CREATE TEMP TABLE temp_strain_matches (
        strain_id INTEGER,
        match_count INTEGER DEFAULT 0,
        conflict_count INTEGER DEFAULT 0
    );
    
    -- Initialize with all strains
    INSERT INTO temp_strain_matches (strain_id)
    SELECT s.strain_id FROM lysobacter.strains s WHERE s.is_active = TRUE;
    
    -- Count total criteria
    total_criteria_count := jsonb_array_length(p_criteria);
    
    -- Process each criterion
    FOR criterion IN SELECT jsonb_array_elements(p_criteria)
    LOOP
        test_name_key := criterion->>'test_name';
        expected_value := criterion->>'expected_value';
        
        -- Update matches for boolean tests
        UPDATE temp_strain_matches 
        SET match_count = match_count + 1
        WHERE strain_id IN (
            SELECT trb.strain_id
            FROM lysobacter.test_results_boolean trb
            JOIN lysobacter.tests t ON trb.test_id = t.test_id
            JOIN lysobacter.test_values tv ON trb.value_id = tv.value_id
            WHERE t.test_code = test_name_key 
            AND tv.value_code = expected_value
        );
        
        -- Update conflicts for boolean tests
        UPDATE temp_strain_matches 
        SET conflict_count = conflict_count + 1
        WHERE strain_id IN (
            SELECT trb.strain_id
            FROM lysobacter.test_results_boolean trb
            JOIN lysobacter.tests t ON trb.test_id = t.test_id
            JOIN lysobacter.test_values tv ON trb.value_id = tv.value_id
            WHERE t.test_code = test_name_key 
            AND tv.value_code != expected_value
            AND tv.value_code != 'n.d.'
        );
    END LOOP;
    
    -- Return results within tolerance
    RETURN QUERY
    SELECT 
        s.strain_id,
        s.strain_identifier,
        s.scientific_name,
        tsm.match_count as match_score,
        total_criteria_count as total_criteria,
        tsm.match_count as matching_criteria,
        tsm.conflict_count as conflicting_criteria
    FROM temp_strain_matches tsm
    JOIN lysobacter.strains s ON tsm.strain_id = s.strain_id
    WHERE tsm.conflict_count <= p_tolerance
    ORDER BY tsm.match_count DESC, tsm.conflict_count ASC;
    
    -- Clean up
    DROP TABLE temp_strain_matches;
END;
$$;


ALTER FUNCTION lysobacter.search_strains_with_tolerance(p_criteria jsonb, p_tolerance integer) OWNER TO lysobacter_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION lysobacter.update_updated_at_column() OWNER TO lysobacter_user;

--
-- Name: validate_strain_data(); Type: FUNCTION; Schema: lysobacter; Owner: lysobacter_user
--

CREATE FUNCTION lysobacter.validate_strain_data() RETURNS TABLE(validation_type character varying, strain_id integer, strain_identifier character varying, issue_description text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check for strains without any test results
    RETURN QUERY
    SELECT 
        'NO_TEST_RESULTS'::VARCHAR(50),
        s.strain_id,
        s.strain_identifier,
        'Strain has no test results recorded'::TEXT
    FROM lysobacter.strains s
    WHERE s.is_active = TRUE
    AND NOT EXISTS (
        SELECT 1 FROM lysobacter.test_results_boolean trb WHERE trb.strain_id = s.strain_id
        UNION
        SELECT 1 FROM lysobacter.test_results_numeric trn WHERE trn.strain_id = s.strain_id
        UNION
        SELECT 1 FROM lysobacter.test_results_text trt WHERE trt.strain_id = s.strain_id
    );
    
    -- Check for inconsistent numeric ranges
    RETURN QUERY
    SELECT 
        'INVALID_NUMERIC_RANGE'::VARCHAR(50),
        s.strain_id,
        s.strain_identifier,
        'Invalid numeric range: minimum > maximum for test: ' || t.test_name
    FROM lysobacter.strains s
    JOIN lysobacter.test_results_numeric trn_min ON s.strain_id = trn_min.strain_id AND trn_min.value_type = 'minimum'
    JOIN lysobacter.test_results_numeric trn_max ON s.strain_id = trn_max.strain_id AND trn_max.value_type = 'maximum'
    JOIN lysobacter.tests t ON trn_min.test_id = t.test_id AND trn_max.test_id = t.test_id
    WHERE trn_min.numeric_value > trn_max.numeric_value;
    
    -- Check for duplicate test results
    RETURN QUERY
    SELECT 
        'DUPLICATE_BOOLEAN_RESULTS'::VARCHAR(50),
        s.strain_id,
        s.strain_identifier,
        'Duplicate boolean test results for test: ' || t.test_name
    FROM lysobacter.strains s
    JOIN lysobacter.test_results_boolean trb ON s.strain_id = trb.strain_id
    JOIN lysobacter.tests t ON trb.test_id = t.test_id
    GROUP BY s.strain_id, s.strain_identifier, t.test_name, trb.test_id
    HAVING COUNT(*) > 1;
    
END;
$$;


ALTER FUNCTION lysobacter.validate_strain_data() OWNER TO lysobacter_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.audit_log (
    log_id integer NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id integer NOT NULL,
    operation character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_by character varying(100),
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.audit_log OWNER TO lysobacter_user;

--
-- Name: audit_log_log_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.audit_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.audit_log_log_id_seq OWNER TO lysobacter_user;

--
-- Name: audit_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.audit_log_log_id_seq OWNED BY lysobacter.audit_log.log_id;


--
-- Name: collection_numbers; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.collection_numbers (
    collection_number_id integer NOT NULL,
    collection_code character varying(50) NOT NULL,
    collection_number character varying(100) NOT NULL,
    collection_name character varying(200),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.collection_numbers OWNER TO lysobacter_user;

--
-- Name: collection_numbers_collection_number_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.collection_numbers_collection_number_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.collection_numbers_collection_number_id_seq OWNER TO lysobacter_user;

--
-- Name: collection_numbers_collection_number_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.collection_numbers_collection_number_id_seq OWNED BY lysobacter.collection_numbers.collection_number_id;


--
-- Name: data_sources; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.data_sources (
    source_id integer NOT NULL,
    source_name character varying(200) NOT NULL,
    source_type character varying(50),
    contact_info text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.data_sources OWNER TO lysobacter_user;

--
-- Name: data_sources_source_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.data_sources_source_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.data_sources_source_id_seq OWNER TO lysobacter_user;

--
-- Name: data_sources_source_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.data_sources_source_id_seq OWNED BY lysobacter.data_sources.source_id;


--
-- Name: species; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.species (
    species_id integer NOT NULL,
    scientific_name character varying(200) NOT NULL,
    common_name character varying(200),
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.species OWNER TO lysobacter_user;

--
-- Name: species_species_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.species_species_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.species_species_id_seq OWNER TO lysobacter_user;

--
-- Name: species_species_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.species_species_id_seq OWNED BY lysobacter.species.species_id;


--
-- Name: strain_collections; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.strain_collections (
    strain_id integer NOT NULL,
    collection_number_id integer NOT NULL,
    is_primary boolean DEFAULT false,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.strain_collections OWNER TO lysobacter_user;

--
-- Name: strains; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.strains (
    strain_id integer NOT NULL,
    strain_identifier character varying(100) NOT NULL,
    scientific_name character varying(200),
    common_name character varying(200),
    description text,
    isolation_source text,
    isolation_location text,
    isolation_date date,
    source_id integer,
    gc_content_min numeric(5,2),
    gc_content_max numeric(5,2),
    gc_content_optimal numeric(5,2),
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    species_id integer,
    is_duplicate boolean DEFAULT false NOT NULL,
    master_strain_id integer
);


ALTER TABLE lysobacter.strains OWNER TO lysobacter_user;

--
-- Name: COLUMN strains.is_duplicate; Type: COMMENT; Schema: lysobacter; Owner: lysobacter_user
--

COMMENT ON COLUMN lysobacter.strains.is_duplicate IS 'True if this strain is a synonym/duplicate of another master strain.';


--
-- Name: COLUMN strains.master_strain_id; Type: COMMENT; Schema: lysobacter; Owner: lysobacter_user
--

COMMENT ON COLUMN lysobacter.strains.master_strain_id IS 'If this is a duplicate, points to the strain_id of the master record.';


--
-- Name: strains_strain_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.strains_strain_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.strains_strain_id_seq OWNER TO lysobacter_user;

--
-- Name: strains_strain_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.strains_strain_id_seq OWNED BY lysobacter.strains.strain_id;


--
-- Name: test_categories; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_categories (
    category_id integer NOT NULL,
    category_name character varying(100) NOT NULL,
    description text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.test_categories OWNER TO lysobacter_user;

--
-- Name: test_categories_category_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_categories_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_categories_category_id_seq OWNER TO lysobacter_user;

--
-- Name: test_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_categories_category_id_seq OWNED BY lysobacter.test_categories.category_id;


--
-- Name: test_results_boolean; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_results_boolean (
    result_id integer NOT NULL,
    strain_id integer NOT NULL,
    test_id integer NOT NULL,
    value_id integer NOT NULL,
    notes text,
    confidence_level character varying(20) DEFAULT 'high'::character varying,
    tested_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.test_results_boolean OWNER TO lysobacter_user;

--
-- Name: test_results_boolean_result_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_results_boolean_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_results_boolean_result_id_seq OWNER TO lysobacter_user;

--
-- Name: test_results_boolean_result_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_results_boolean_result_id_seq OWNED BY lysobacter.test_results_boolean.result_id;


--
-- Name: test_results_numeric; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_results_numeric (
    result_id integer NOT NULL,
    strain_id integer NOT NULL,
    test_id integer NOT NULL,
    value_type character varying(20) NOT NULL,
    numeric_value numeric(10,4) NOT NULL,
    measurement_unit character varying(20),
    notes text,
    confidence_level character varying(20) DEFAULT 'high'::character varying,
    tested_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT test_results_numeric_value_type_check CHECK (((value_type)::text = ANY ((ARRAY['minimum'::character varying, 'maximum'::character varying, 'optimal'::character varying, 'single'::character varying])::text[])))
);


ALTER TABLE lysobacter.test_results_numeric OWNER TO lysobacter_user;

--
-- Name: test_results_numeric_result_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_results_numeric_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_results_numeric_result_id_seq OWNER TO lysobacter_user;

--
-- Name: test_results_numeric_result_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_results_numeric_result_id_seq OWNED BY lysobacter.test_results_numeric.result_id;


--
-- Name: test_results_text; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_results_text (
    result_id integer NOT NULL,
    strain_id integer NOT NULL,
    test_id integer NOT NULL,
    text_value text NOT NULL,
    notes text,
    confidence_level character varying(20) DEFAULT 'high'::character varying,
    tested_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.test_results_text OWNER TO lysobacter_user;

--
-- Name: test_results_text_result_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_results_text_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_results_text_result_id_seq OWNER TO lysobacter_user;

--
-- Name: test_results_text_result_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_results_text_result_id_seq OWNED BY lysobacter.test_results_text.result_id;


--
-- Name: test_values; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.test_values (
    value_id integer NOT NULL,
    test_id integer NOT NULL,
    value_code character varying(10) NOT NULL,
    value_name character varying(50) NOT NULL,
    description text,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lysobacter.test_values OWNER TO lysobacter_user;

--
-- Name: test_values_value_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.test_values_value_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.test_values_value_id_seq OWNER TO lysobacter_user;

--
-- Name: test_values_value_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.test_values_value_id_seq OWNED BY lysobacter.test_values.value_id;


--
-- Name: tests; Type: TABLE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TABLE lysobacter.tests (
    test_id integer NOT NULL,
    category_id integer NOT NULL,
    test_name character varying(150) NOT NULL,
    test_code character varying(50),
    test_type character varying(20) NOT NULL,
    description text,
    measurement_unit character varying(20),
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tests_test_type_check CHECK (((test_type)::text = ANY ((ARRAY['boolean'::character varying, 'numeric'::character varying, 'text'::character varying])::text[])))
);


ALTER TABLE lysobacter.tests OWNER TO lysobacter_user;

--
-- Name: tests_test_id_seq; Type: SEQUENCE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE SEQUENCE lysobacter.tests_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lysobacter.tests_test_id_seq OWNER TO lysobacter_user;

--
-- Name: tests_test_id_seq; Type: SEQUENCE OWNED BY; Schema: lysobacter; Owner: lysobacter_user
--

ALTER SEQUENCE lysobacter.tests_test_id_seq OWNED BY lysobacter.tests.test_id;


--
-- Name: v_category_statistics; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_category_statistics AS
SELECT
    NULL::character varying(100) AS category_name,
    NULL::text AS description,
    NULL::bigint AS total_tests,
    NULL::bigint AS active_tests,
    NULL::bigint AS strains_with_data;


ALTER TABLE lysobacter.v_category_statistics OWNER TO lysobacter_user;

--
-- Name: v_strain_completeness; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_strain_completeness AS
 SELECT s.strain_id,
    s.strain_identifier,
    s.scientific_name,
    count(DISTINCT t.test_id) AS total_available_tests,
    count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.test_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.test_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.test_id
            ELSE NULL::integer
        END) AS completed_tests,
    round((((count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.test_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.test_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.test_id
            ELSE NULL::integer
        END))::numeric * 100.0) / (NULLIF(count(DISTINCT t.test_id), 0))::numeric), 2) AS completeness_percentage
   FROM ((((lysobacter.strains s
     CROSS JOIN lysobacter.tests t)
     LEFT JOIN lysobacter.test_results_boolean trb ON (((s.strain_id = trb.strain_id) AND (t.test_id = trb.test_id))))
     LEFT JOIN lysobacter.test_results_numeric trn ON (((s.strain_id = trn.strain_id) AND (t.test_id = trn.test_id))))
     LEFT JOIN lysobacter.test_results_text trt ON (((s.strain_id = trt.strain_id) AND (t.test_id = trt.test_id))))
  WHERE ((s.is_active = true) AND (t.is_active = true))
  GROUP BY s.strain_id, s.strain_identifier, s.scientific_name
  ORDER BY (round((((count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.test_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.test_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.test_id
            ELSE NULL::integer
        END))::numeric * 100.0) / (NULLIF(count(DISTINCT t.test_id), 0))::numeric), 2)) DESC;


ALTER TABLE lysobacter.v_strain_completeness OWNER TO lysobacter_user;

--
-- Name: v_strains_complete; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_strains_complete AS
SELECT
    NULL::integer AS strain_id,
    NULL::character varying(100) AS strain_identifier,
    NULL::character varying(200) AS scientific_name,
    NULL::character varying(200) AS common_name,
    NULL::text AS description,
    NULL::text AS isolation_source,
    NULL::text AS isolation_location,
    NULL::date AS isolation_date,
    NULL::character varying(200) AS source_name,
    NULL::character varying(50) AS source_type,
    NULL::numeric(5,2) AS gc_content_min,
    NULL::numeric(5,2) AS gc_content_max,
    NULL::numeric(5,2) AS gc_content_optimal,
    NULL::text AS notes,
    NULL::boolean AS is_active,
    NULL::timestamp without time zone AS created_at,
    NULL::timestamp without time zone AS updated_at,
    NULL::text[] AS collection_numbers;


ALTER TABLE lysobacter.v_strains_complete OWNER TO lysobacter_user;

--
-- Name: v_test_completion; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_test_completion AS
 SELECT t.test_id,
    t.test_name,
    t.test_type,
    tc.category_name,
    count(DISTINCT s.strain_id) AS total_strains,
    count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.strain_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.strain_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.strain_id
            ELSE NULL::integer
        END) AS tested_strains,
    round((((count(DISTINCT
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN trb.strain_id
            WHEN ((t.test_type)::text = 'numeric'::text) THEN trn.strain_id
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.strain_id
            ELSE NULL::integer
        END))::numeric * 100.0) / (NULLIF(count(DISTINCT s.strain_id), 0))::numeric), 2) AS completion_percentage
   FROM (((((lysobacter.tests t
     JOIN lysobacter.test_categories tc ON ((t.category_id = tc.category_id)))
     CROSS JOIN lysobacter.strains s)
     LEFT JOIN lysobacter.test_results_boolean trb ON (((t.test_id = trb.test_id) AND (s.strain_id = trb.strain_id))))
     LEFT JOIN lysobacter.test_results_numeric trn ON (((t.test_id = trn.test_id) AND (s.strain_id = trn.strain_id))))
     LEFT JOIN lysobacter.test_results_text trt ON (((t.test_id = trt.test_id) AND (s.strain_id = trt.strain_id))))
  WHERE ((t.is_active = true) AND (s.is_active = true))
  GROUP BY t.test_id, t.test_name, t.test_type, tc.category_name
  ORDER BY tc.category_name, t.test_name;


ALTER TABLE lysobacter.v_test_completion OWNER TO lysobacter_user;

--
-- Name: v_test_results_summary; Type: VIEW; Schema: lysobacter; Owner: lysobacter_user
--

CREATE VIEW lysobacter.v_test_results_summary AS
 SELECT s.strain_id,
    s.strain_identifier,
    tc.category_name,
    t.test_name,
    t.test_type,
    t.measurement_unit,
        CASE
            WHEN ((t.test_type)::text = 'boolean'::text) THEN tv.value_name
            ELSE NULL::character varying
        END AS boolean_result,
        CASE
            WHEN ((t.test_type)::text = 'numeric'::text) THEN
            CASE trn.value_type
                WHEN 'minimum'::text THEN ('Min: '::text || (trn.numeric_value)::text)
                WHEN 'maximum'::text THEN ('Max: '::text || (trn.numeric_value)::text)
                WHEN 'optimal'::text THEN ('Opt: '::text || (trn.numeric_value)::text)
                ELSE (trn.numeric_value)::text
            END
            ELSE NULL::text
        END AS numeric_result,
        CASE
            WHEN ((t.test_type)::text = 'text'::text) THEN trt.text_value
            ELSE NULL::text
        END AS text_result,
    COALESCE(trb.confidence_level, trn.confidence_level, trt.confidence_level) AS confidence_level,
    COALESCE(trb.tested_date, trn.tested_date, trt.tested_date) AS tested_date
   FROM ((((((lysobacter.strains s
     CROSS JOIN lysobacter.tests t)
     JOIN lysobacter.test_categories tc ON ((t.category_id = tc.category_id)))
     LEFT JOIN lysobacter.test_results_boolean trb ON (((s.strain_id = trb.strain_id) AND (t.test_id = trb.test_id))))
     LEFT JOIN lysobacter.test_values tv ON ((trb.value_id = tv.value_id)))
     LEFT JOIN lysobacter.test_results_numeric trn ON (((s.strain_id = trn.strain_id) AND (t.test_id = trn.test_id))))
     LEFT JOIN lysobacter.test_results_text trt ON (((s.strain_id = trt.strain_id) AND (t.test_id = trt.test_id))))
  WHERE ((s.is_active = true) AND (t.is_active = true) AND ((trb.result_id IS NOT NULL) OR (trn.result_id IS NOT NULL) OR (trt.result_id IS NOT NULL)));


ALTER TABLE lysobacter.v_test_results_summary OWNER TO lysobacter_user;

--
-- Name: audit_log log_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.audit_log ALTER COLUMN log_id SET DEFAULT nextval('lysobacter.audit_log_log_id_seq'::regclass);


--
-- Name: collection_numbers collection_number_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.collection_numbers ALTER COLUMN collection_number_id SET DEFAULT nextval('lysobacter.collection_numbers_collection_number_id_seq'::regclass);


--
-- Name: data_sources source_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.data_sources ALTER COLUMN source_id SET DEFAULT nextval('lysobacter.data_sources_source_id_seq'::regclass);


--
-- Name: species species_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.species ALTER COLUMN species_id SET DEFAULT nextval('lysobacter.species_species_id_seq'::regclass);


--
-- Name: strains strain_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains ALTER COLUMN strain_id SET DEFAULT nextval('lysobacter.strains_strain_id_seq'::regclass);


--
-- Name: test_categories category_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_categories ALTER COLUMN category_id SET DEFAULT nextval('lysobacter.test_categories_category_id_seq'::regclass);


--
-- Name: test_results_boolean result_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean ALTER COLUMN result_id SET DEFAULT nextval('lysobacter.test_results_boolean_result_id_seq'::regclass);


--
-- Name: test_results_numeric result_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric ALTER COLUMN result_id SET DEFAULT nextval('lysobacter.test_results_numeric_result_id_seq'::regclass);


--
-- Name: test_results_text result_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text ALTER COLUMN result_id SET DEFAULT nextval('lysobacter.test_results_text_result_id_seq'::regclass);


--
-- Name: test_values value_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_values ALTER COLUMN value_id SET DEFAULT nextval('lysobacter.test_values_value_id_seq'::regclass);


--
-- Name: tests test_id; Type: DEFAULT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests ALTER COLUMN test_id SET DEFAULT nextval('lysobacter.tests_test_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.audit_log (log_id, table_name, record_id, operation, old_values, new_values, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: collection_numbers; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.collection_numbers (collection_number_id, collection_code, collection_number, collection_name, notes, created_at) FROM stdin;
5	ATCC	29479	\N	\N	2025-06-29 10:43:37.618007
6	ATCC	29480	\N	\N	2025-06-29 10:43:37.618007
7	ATCC	29481	\N	\N	2025-06-29 10:43:37.618007
8	UASM	4045	\N	\N	2025-06-29 10:43:37.618007
9	ATCC	29483	\N	\N	2025-06-29 10:43:37.618007
10	UASM	2	\N	\N	2025-06-29 10:43:37.618007
11	JCM	19212T	\N	\N	2025-06-29 10:43:37.618007
12	KACC	17502T	\N	\N	2025-06-29 10:43:37.618007
13	ATCC	29489	\N	\N	2025-06-29 10:43:37.618007
14	ATCC	29489T	\N	\N	2025-06-29 10:43:37.618007
15	DSM	6980T	\N	\N	2025-06-29 10:43:37.618007
16	KACC	11386T	\N	\N	2025-06-29 10:43:37.618007
17	KCTC	12132T	\N	\N	2025-06-29 10:43:37.618007
18	LMG	8763T	\N	\N	2025-06-29 10:43:37.618007
19	UASM	402	\N	\N	2025-06-29 10:43:37.618007
20	ATCC	29482	\N	\N	2025-06-29 10:43:37.618007
21	ATCC	29482T	\N	\N	2025-06-29 10:43:37.618007
22	ATCC	29484	\N	\N	2025-06-29 10:43:37.618007
23	UASM	6	\N	\N	2025-06-29 10:43:37.618007
24	DSM	19286T	\N	\N	2025-06-29 10:43:37.618007
25	KCTC	12891T	\N	\N	2025-06-29 10:43:37.618007
26	ATCC	29487T	\N	\N	2025-06-29 10:43:37.618007
27	BCRC	11654T	\N	\N	2025-06-29 10:43:37.618007
28	DSM	2043T	\N	\N	2025-06-29 10:43:37.618007
29	KACC	10127T	\N	\N	2025-06-29 10:43:37.618007
30	KCTC	12131T	\N	\N	2025-06-29 10:43:37.618007
31	LMG	8762T	\N	\N	2025-06-29 10:43:37.618007
32	KACC	18720	\N	\N	2025-06-29 10:43:37.618007
33	KCTC	12600	\N	\N	2025-06-29 10:43:37.618007
34	KCTC	12600T	\N	\N	2025-06-29 10:43:37.618007
35	DSM	18482T	\N	\N	2025-06-29 10:43:37.618007
36	KACC	11407T	\N	\N	2025-06-29 10:43:37.618007
37	DSM	17958T	\N	\N	2025-06-29 10:43:37.618007
38	KCTC	12822T	\N	\N	2025-06-29 10:43:37.618007
39	KACC	18711T	\N	\N	2025-06-29 10:43:37.618007
40	NBRC	111306T	\N	\N	2025-06-29 10:43:37.618007
41	ATCC	27796	\N	\N	2025-06-29 10:43:37.618007
42	DSM	16239T	\N	\N	2025-06-29 10:43:37.618007
43	KCTC	12205T	\N	\N	2025-06-29 10:43:37.618007
44	KACC	15381T	\N	\N	2025-06-29 10:43:37.618007
45	KACC	22011T	\N	\N	2025-06-29 10:43:37.618007
46	KCTC	22011T	\N	\N	2025-06-29 10:43:37.618007
47	JCM	32178T	\N	\N	2025-06-29 10:43:37.618007
48	KACC	18656T	\N	\N	2025-06-29 10:43:37.618007
49	ATCC	29488	\N	\N	2025-06-29 10:43:37.618007
50	DSM	17633T	\N	\N	2025-06-29 10:43:37.618007
51	KCTC	12204T	\N	\N	2025-06-29 10:43:37.618007
52	KCTC	42381T	\N	\N	2025-06-29 10:43:37.618007
53	NBRC	110750T	\N	\N	2025-06-29 10:43:37.618007
54	DSM	18244T	\N	\N	2025-06-29 10:43:37.618007
55	DSM	18481T	\N	\N	2025-06-29 10:43:37.618007
56	KACC	11587T	\N	\N	2025-06-29 10:43:37.618007
57	KACC	11588T	\N	\N	2025-06-29 10:43:37.618007
58	KACC	22750T	\N	\N	2025-06-29 10:43:37.618007
59	LMG	24310T	\N	\N	2025-06-29 10:43:37.618007
60	KACC	21942T	\N	\N	2025-06-29 10:43:37.618007
61	KACC	14553T	\N	\N	2025-06-29 10:43:37.618007
62	KCTC	22249T	\N	\N	2025-06-29 10:43:37.618007
63	CECT	9427T	\N	\N	2025-06-29 10:43:37.618007
64	LMG	30077T	\N	\N	2025-06-29 10:43:37.618007
65	JCM	18933T	\N	\N	2025-06-29 10:43:37.618007
66	KACC	16548T	\N	\N	2025-06-29 10:43:37.618007
\.


--
-- Data for Name: data_sources; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.data_sources (source_id, source_name, source_type, contact_info, notes, created_at) FROM stdin;
1	Laboratory Research Data	laboratory	Internal laboratory testing	Primary research data from laboratory experiments	2025-06-26 01:18:03.859223
2	Literature Review	publication	Various scientific publications	Data collected from published research papers	2025-06-26 01:18:03.859223
3	Culture Collection Database	database	International culture collections	Data from established culture collection databases	2025-06-26 01:18:03.859223
\.


--
-- Data for Name: species; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.species (species_id, scientific_name, common_name, description, created_at, updated_at) FROM stdin;
1	Lysobacter yangpyeongensis	\N	\N	2025-06-26 01:55:33.94069	2025-06-26 01:55:33.94069
2	Lysobacter antrifimi	\N	\N	2025-06-26 01:55:33.94069	2025-06-26 01:55:33.94069
3	Lysobacter alkalisoli	\N	\N	2025-06-26 01:55:33.94069	2025-06-26 01:55:33.94069
4	Lysobacter agilis	\N	\N	2025-06-26 01:55:33.94069	2025-06-26 01:55:33.94069
5	Lysobacter aestuarii	\N	\N	2025-06-26 01:55:33.94069	2025-06-26 01:55:33.94069
6	Lysobacter antibioticus	\N	\N	2025-06-26 02:05:40.181	2025-06-26 02:05:40.181
7	Lysobacter arenosi	\N	\N	2025-06-26 02:45:09.04858	2025-06-26 02:45:09.04858
8	Lysobacter arseniciresistens	\N	\N	2025-06-26 02:51:18.044327	2025-06-26 02:51:18.044327
9	Lysobacter brunescens	\N	\N	2025-06-26 02:56:46.609219	2025-06-26 02:56:46.609219
10	Lysobacter bugurensis	\N	\N	2025-06-26 06:08:48.097892	2025-06-26 06:08:48.097892
11	Lysobacter caeni	\N	\N	2025-06-26 06:11:46.884141	2025-06-26 06:11:46.884141
12	Lysobacter capsici	\N	\N	2025-06-26 06:20:20.109378	2025-06-26 06:20:20.109378
13	Lysobacter caseinilyticus	\N	\N	2025-06-26 06:21:59.494506	2025-06-26 06:21:59.494506
14	Lysobacter cavernae	\N	\N	2025-06-26 06:24:48.508178	2025-06-26 06:24:48.508178
15	Lysobacter concretionis	\N	\N	2025-06-26 06:27:04.328668	2025-06-26 06:27:04.328668
16	Lysobacter cucumeris	\N	\N	2025-06-26 06:30:03.856434	2025-06-26 06:30:03.856434
17	Lysobacter daejeonensis	\N	\N	2025-06-26 06:34:41.601951	2025-06-26 06:34:41.601951
18	Lysobacter defluvii	\N	\N	2025-06-26 06:52:03.607207	2025-06-26 06:52:03.607207
19	Lysobacter dokdonensis	\N	\N	2025-06-26 06:57:10.819485	2025-06-26 06:57:10.819485
20	Lysobacter tongrenensis	\N	\N	2025-06-26 06:57:10.819485	2025-06-26 06:57:10.819485
21	Lysobacter enzymogenes	\N	\N	2025-06-26 07:07:28.925588	2025-06-26 07:07:28.925588
22	Lysobacter enzymogenes subsp. cookii	\N	\N	2025-06-26 07:15:30.110978	2025-06-26 07:15:30.110978
23	Lysobacter enzymogenes subsp. enzymogenes	\N	\N	2025-06-26 07:17:39.437709	2025-06-26 07:17:39.437709
24	Lysobacter firmicutimachus	\N	\N	2025-06-26 07:22:26.618307	2025-06-26 07:22:26.618307
25	Lysobacter fragariae	\N	\N	2025-06-26 07:25:02.810458	2025-06-26 07:25:02.810458
26	Lysobacter ginsengisoli	\N	\N	2025-06-26 07:31:04.56484	2025-06-26 07:31:04.56484
27	Lysobacter gummosus	\N	\N	2025-06-26 07:33:14.429692	2025-06-26 07:33:14.429692
28	Lysobacter hankyongensis	\N	\N	2025-06-26 07:35:10.644027	2025-06-26 07:35:10.644027
29	Lysobacter humi	\N	\N	2025-06-26 07:37:24.903408	2025-06-26 07:37:24.903408
30	Lysobacter koreensis	\N	\N	2025-06-26 07:40:33.583319	2025-06-26 07:40:33.583319
31	Lysobacter korlensis	\N	\N	2025-06-26 07:46:04.762326	2025-06-26 07:46:04.762326
32	Lysobacter lacus	\N	\N	2025-06-26 07:48:31.490817	2025-06-26 07:48:31.490817
33	Lysobacter maris	\N	\N	2025-06-26 07:50:15.081584	2025-06-26 07:50:15.081584
34	Lysobacter mephitis	\N	\N	2025-06-26 07:57:19.568773	2025-06-26 07:57:19.568773
35	Lysobacter mobilis	\N	\N	2025-06-26 07:57:19.568773	2025-06-26 07:57:19.568773
36	Lysobacter niabensis	\N	\N	2025-06-26 07:57:19.568773	2025-06-26 07:57:19.568773
37	Lysobacter niastensis	\N	\N	2025-06-26 07:59:40.869851	2025-06-26 07:59:40.869851
38	Lysobacter silvestris	\N	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
39	Lysobacter novalis	\N	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
40	Lysobacter oculi	\N	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
41	Lysobacter oligotrophicus	\N	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
42	Lysobacter oryzae	\N	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
43	Lysobacter terrae	\N	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
44	Lysobacter panacisoli	\N	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
45	Lysobacter panaciterrae	\N	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
46	Lysobacter soli	\N	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
47	Lysobacter penaei	\N	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
48	Lysobacter pocheonensis	\N	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
49	Lysobacter prati	\N	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
50	Lysobacter rhizosphaerae	\N	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
51	Lysobacter ruishenii	\N	\N	2025-06-28 08:05:41.237309	2025-06-28 08:05:41.237309
52	Lysobacter sediminicola	\N	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
53	Lysobacter solanacearum	\N	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
54	Lysobacter zonguldakensis	\N	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
55	Lysobacter erysipheiresistens	\N	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
56	Lysobacter spongiae	\N	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
57	Lysobacter xinjiangensis	\N	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
58	Lysobacter lactamgenus	\N	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
59	Lysobacter vadosa	\N	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
60	Lysobacter sp.	\N	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
61	Luteimonas tolerans	\N	\N	2025-06-28 08:47:18.018991	2025-06-28 08:47:18.018991
62	Lysobacter tyrosinilyticus	\N	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
63	Lysobacter ximonensis	\N	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
\.


--
-- Data for Name: strain_collections; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.strain_collections (strain_id, collection_number_id, is_primary, notes, created_at) FROM stdin;
26	5	f	\N	2025-06-29 10:43:37.618007
37	6	f	\N	2025-06-29 10:43:37.618007
27	7	f	\N	2025-06-29 10:43:37.618007
27	8	f	\N	2025-06-29 10:43:37.618007
84	9	f	\N	2025-06-29 10:43:37.618007
84	10	f	\N	2025-06-29 10:43:37.618007
692	11	f	\N	2025-06-29 10:43:37.618007
692	12	f	\N	2025-06-29 10:43:37.618007
176	13	f	\N	2025-06-29 10:43:37.618007
176	14	f	\N	2025-06-29 10:43:37.618007
176	15	f	\N	2025-06-29 10:43:37.618007
176	16	f	\N	2025-06-29 10:43:37.618007
176	17	f	\N	2025-06-29 10:43:37.618007
176	18	f	\N	2025-06-29 10:43:37.618007
176	19	f	\N	2025-06-29 10:43:37.618007
77	20	f	\N	2025-06-29 10:43:37.618007
77	21	f	\N	2025-06-29 10:43:37.618007
97	22	f	\N	2025-06-29 10:43:37.618007
97	23	f	\N	2025-06-29 10:43:37.618007
109	24	f	\N	2025-06-29 10:43:37.618007
109	25	f	\N	2025-06-29 10:43:37.618007
139	26	f	\N	2025-06-29 10:43:37.618007
139	27	f	\N	2025-06-29 10:43:37.618007
139	28	f	\N	2025-06-29 10:43:37.618007
139	29	f	\N	2025-06-29 10:43:37.618007
139	30	f	\N	2025-06-29 10:43:37.618007
139	31	f	\N	2025-06-29 10:43:37.618007
125	32	f	\N	2025-06-29 10:43:37.618007
125	33	f	\N	2025-06-29 10:43:37.618007
125	34	f	\N	2025-06-29 10:43:37.618007
133	35	f	\N	2025-06-29 10:43:37.618007
133	36	f	\N	2025-06-29 10:43:37.618007
137	37	f	\N	2025-06-29 10:43:37.618007
137	38	f	\N	2025-06-29 10:43:37.618007
136	39	f	\N	2025-06-29 10:43:37.618007
136	40	f	\N	2025-06-29 10:43:37.618007
142	41	f	\N	2025-06-29 10:43:37.618007
122	42	f	\N	2025-06-29 10:43:37.618007
122	43	f	\N	2025-06-29 10:43:37.618007
703	44	f	\N	2025-06-29 10:43:37.618007
703	45	f	\N	2025-06-29 10:43:37.618007
703	46	f	\N	2025-06-29 10:43:37.618007
701	47	f	\N	2025-06-29 10:43:37.618007
701	48	f	\N	2025-06-29 10:43:37.618007
145	49	f	\N	2025-06-29 10:43:37.618007
193	50	f	\N	2025-06-29 10:43:37.618007
193	51	f	\N	2025-06-29 10:43:37.618007
197	52	f	\N	2025-06-29 10:43:37.618007
197	53	f	\N	2025-06-29 10:43:37.618007
206	54	f	\N	2025-06-29 10:43:37.618007
206	55	f	\N	2025-06-29 10:43:37.618007
206	56	f	\N	2025-06-29 10:43:37.618007
206	57	f	\N	2025-06-29 10:43:37.618007
206	58	f	\N	2025-06-29 10:43:37.618007
206	59	f	\N	2025-06-29 10:43:37.618007
711	60	f	\N	2025-06-29 10:43:37.618007
688	61	f	\N	2025-06-29 10:43:37.618007
688	62	f	\N	2025-06-29 10:43:37.618007
710	63	f	\N	2025-06-29 10:43:37.618007
710	64	f	\N	2025-06-29 10:43:37.618007
713	65	f	\N	2025-06-29 10:43:37.618007
713	66	f	\N	2025-06-29 10:43:37.618007
16	5	f	\N	2025-06-29 11:44:13.145438
17	6	f	\N	2025-06-29 11:44:13.145438
79	9	f	\N	2025-06-29 11:44:13.145438
79	10	f	\N	2025-06-29 11:44:13.145438
78	20	f	\N	2025-06-29 11:44:13.145438
78	21	f	\N	2025-06-29 11:44:13.145438
126	32	f	\N	2025-06-29 11:44:13.145438
126	33	f	\N	2025-06-29 11:44:13.145438
126	34	f	\N	2025-06-29 11:44:13.145438
135	37	f	\N	2025-06-29 11:44:13.145438
135	38	f	\N	2025-06-29 11:44:13.145438
198	52	f	\N	2025-06-29 11:44:13.145438
198	53	f	\N	2025-06-29 11:44:13.145438
18	7	f	\N	2025-06-29 11:44:13.145438
18	8	f	\N	2025-06-29 11:44:13.145438
119	42	f	\N	2025-06-29 11:44:13.145438
119	43	f	\N	2025-06-29 11:44:13.145438
695	60	f	\N	2025-06-29 11:44:13.145438
714	65	f	\N	2025-06-29 11:44:13.145438
714	66	f	\N	2025-06-29 11:44:13.145438
\.


--
-- Data for Name: strains; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.strains (strain_id, strain_identifier, scientific_name, common_name, description, isolation_source, isolation_location, isolation_date, source_id, gc_content_min, gc_content_max, gc_content_optimal, notes, is_active, created_at, updated_at, species_id, is_duplicate, master_strain_id) FROM stdin;
2	DCY117T	Lysobacter aestuarii	Strain DCY117T	Strain isolated from contaminated soil.	Загрязненная почва	\N	\N	\N	\N	\N	\N	Data from table on page 48.	t	2025-06-26 01:25:32.136319	2025-06-29 11:51:58.568418	5	f	\N
3	DSM 19680T	Lysobacter aestuarii	Strain DSM 19680T	\N	\N	\N	\N	\N	\N	\N	\N	Detailed test results for this strain were not found in the provided source document.	t	2025-06-26 01:25:32.136319	2025-06-29 11:51:58.568418	5	f	\N
26	UASM 3C	Lysobacter antibioticus	Strain ATCC 29479	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 16 (ATCC 29479).\nOriginal notes: Data from Table 9 on page 1. Also known as ATCC 29479.	t	2025-06-26 02:08:58.160833	2025-06-29 11:51:58.568418	6	f	\N
37	UASM L17	Lysobacter antibioticus	Strain ATCC 29480	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 17 (ATCC 29480).\nOriginal notes: Data from Table 9 on page 1. Also known as ATCC 29480.	t	2025-06-26 02:40:27.452518	2025-06-29 11:51:58.568418	6	f	\N
84	UASM 2	Lysobacter brunescens	Strain ATCC 29483	Strain of Lysobacter brunescens.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 79 (ATCC 29483).\nOriginal notes: Data from Table 9 on page 2. Also known as ATCC 29483.	t	2025-06-26 02:56:46.609219	2025-06-29 11:51:58.568418	9	f	\N
20	DSM 2044T	Lysobacter antibioticus	Strain DSM 2044T	Type strain of Lysobacter antibioticus, frequently used in comparative studies.	\N	\N	\N	\N	\N	\N	\N	Data compiled from tables on pages 20, 21, 23, 30, 35, 43.	t	2025-06-26 02:08:43.428969	2025-06-29 11:51:58.568418	6	f	\N
21	KACC 11383T	Lysobacter antibioticus	Strain KACC 11383T	Strain of Lysobacter antibioticus.	\N	\N	\N	\N	\N	\N	\N	Data from tables on pages 25-27.	t	2025-06-26 02:08:43.428969	2025-06-29 11:51:58.568418	6	f	\N
22	KCTC 12129T	Lysobacter antibioticus	Strain KCTC 12129T	Strain of Lysobacter antibioticus.	\N	\N	\N	\N	\N	\N	\N	Data from tables on pages 12-13.	t	2025-06-26 02:08:43.428969	2025-06-29 11:51:58.568418	6	f	\N
107	D-14T	Lysobacter caeni	Strain D-14T	Type strain of Lysobacter caeni.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 45.	t	2025-06-26 06:11:46.884141	2025-06-29 11:51:58.568418	11	f	\N
24	UASM 101	Lysobacter antibioticus	Strain UASM 101	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:08:58.160833	2025-06-29 11:51:58.568418	6	f	\N
25	UASM 121	Lysobacter antibioticus	Strain UASM 121	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:08:58.160833	2025-06-29 11:51:58.568418	6	f	\N
28	UASM 4169	Lysobacter antibioticus	Strain UASM 4169	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:17:20.062616	2025-06-29 11:51:58.568418	6	f	\N
29	UASM 4551	Lysobacter antibioticus	Strain UASM 4551	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:17:20.062616	2025-06-29 11:51:58.568418	6	f	\N
30	UASM 4572	Lysobacter antibioticus	Strain UASM 4572	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:17:20.062616	2025-06-29 11:51:58.568418	6	f	\N
31	UASM 4574	Lysobacter antibioticus	Strain UASM 4574	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:17:20.062616	2025-06-29 11:51:58.568418	6	f	\N
32	UASM 4578	Lysobacter antibioticus	Strain UASM 4578	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:23:11.891632	2025-06-29 11:51:58.568418	6	f	\N
33	UASM 4593	Lysobacter antibioticus	Strain UASM 4593	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:23:11.891632	2025-06-29 11:51:58.568418	6	f	\N
34	UASM 4598	Lysobacter antibioticus	Strain UASM 4598	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:23:11.891632	2025-06-29 11:51:58.568418	6	f	\N
35	UASM 66	Lysobacter antibioticus	Strain UASM 66	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:23:11.891632	2025-06-29 11:51:58.568418	6	f	\N
36	UASM 81	Lysobacter antibioticus	Strain UASM 81	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:40:27.452518	2025-06-29 11:51:58.568418	6	f	\N
38	UASM Q15	Lysobacter antibioticus	Strain UASM Q15	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:40:27.452518	2025-06-29 11:51:58.568418	6	f	\N
39	UASM Q9	Lysobacter antibioticus	Strain UASM Q9	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 1.	t	2025-06-26 02:40:27.452518	2025-06-29 11:51:58.568418	6	f	\N
41	CGMCC 1.10752T	Lysobacter arseniciresistens	Strain CGMCC 1.10752T	Strain isolated from iron ore soil, used for comparison with Lysobacter agilis.	Почва с железорудного месторождения	\N	\N	\N	\N	\N	\N	Data from Table 1 on pages 1 and 84. Most data is inferred from the note comparing it to ZGLJ7-1T.	t	2025-06-26 02:51:18.044327	2025-06-29 11:51:58.568418	8	f	\N
155	UASM 4556	Lysobacter enzymogenes	Strain UASM 4556	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
156	UASM 4557	Lysobacter enzymogenes	Strain UASM 4557	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
692	CJ29T	Lysobacter panacisoli	\N	Грамотрицательная, факультативно-анаэробная, палочковидная, неподвижная бактерия. [2, 4, 5] Образует ярко-желтые колонии. [7]	Почва из женьшеневого поля	Ансон, Южная Корея	\N	\N	\N	\N	\N	Также известен как KACC 17502T и JCM 19212T. [2, 3]	t	2025-06-28 07:53:00.30969	2025-06-29 11:51:58.568418	44	f	\N
745	TEST01-01	Lysobacter aestuarii	\N				2025-06-27	\N	11.00	57.00	45.00		f	2025-06-29 06:36:17.577276	2025-06-29 11:51:58.568418	\N	f	\N
10	ZGLJ7-1T	Lysobacter agilis	Strain ZGLJ7-1T	Type strain of Lysobacter agilis, distinguished from Lysobacter arseniciresistens.	Грязь из ямы	\N	\N	\N	\N	\N	\N	Data from Table 1 on page 1 and 84.	t	2025-06-26 01:39:52.018094	2025-06-29 11:51:58.568418	4	f	\N
11	CGMCC 1.16756T	Lysobacter alkalisoli	Strain CGMCC 1.16756T	Type strain of Lysobacter alkalisoli.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 52.	t	2025-06-26 01:39:52.018094	2025-06-29 11:51:58.568418	3	f	\N
12	5-21aT	Lysobacter antrifimi	Strain 5-21aT	Type strain of Lysobacter antrifimi.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 11.	t	2025-06-26 01:39:52.018094	2025-06-29 11:51:58.568418	2	f	\N
23	LMG 8760T	Lysobacter antibioticus	Strain LMG 8760T	Strain of Lysobacter antibioticus.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 29. All data points are cited from another source (Christensen & Cook, 1978).	t	2025-06-26 02:08:43.428969	2025-06-29 11:51:58.568418	6	f	\N
42	KCTC 23365T	Lysobacter arseniciresistens	Strain ZS79T	Type strain of Lysobacter arseniciresistens. Also known as ZS79T.	\N	\N	\N	\N	\N	\N	\N	This is the KCTC designation for the type strain ZS79T. Data is identical to ZS79T.	t	2025-06-26 02:51:18.044327	2025-06-29 11:51:58.568418	8	f	\N
105	ZLD-29T	Lysobacter bugurensis	Strain ZLD-29T	Type strain of Lysobacter bugurensis, isolated from soil.	Почва	\N	\N	\N	\N	\N	\N	This strain is also referred to as ZLD-29 in some contexts.	t	2025-06-26 06:08:48.097892	2025-06-29 11:51:58.568418	10	f	\N
117	KCTC 42875T	Lysobacter cavernae	Type strain of Lysobacter cavernae	\N	\N	\N	\N	\N	\N	\N	\N	This is the KCTC designation for the type strain C8-1T. All test data is listed under the C8-1T entry.	t	2025-06-26 06:24:48.508178	2025-06-29 11:51:58.568418	14	f	\N
77	ATCC 29482	Lysobacter brunescens	Strain UASM D, ATCC 29482T	Type strain of Lysobacter brunescens.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 78 (ATCC 29482T).\nOriginal notes: Data compiled from pages 2, 20, 21, 30. This is the type strain, also designated as ATCC 29482T and UASM D.	t	2025-06-26 02:56:46.609219	2025-06-29 11:51:58.568418	9	f	\N
96	UASM 4541	Lysobacter brunescens	Strain UASM 4541	Strain of Lysobacter brunescens with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 2.	t	2025-06-26 03:04:32.422276	2025-06-29 11:51:58.568418	9	f	\N
97	UASM 6	Lysobacter brunescens	Strain ATCC 29484	Strain of Lysobacter brunescens with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 2. Also known as ATCC 29484.	t	2025-06-26 03:04:32.422276	2025-06-29 11:51:58.568418	9	f	\N
98	UASM CB1	Lysobacter brunescens	Strain UASM CB1	Strain of Lysobacter brunescens with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 2.	t	2025-06-26 03:04:32.422276	2025-06-29 11:51:58.568418	9	f	\N
109	DSM 19286T	Lysobacter capsici	Type strain of Lysobacter capsici	\N	\N	\N	\N	\N	\N	\N	\N	This is the DSM designation for the type strain YC5194T. All test data is listed under the YC5194T entry.	t	2025-06-26 06:20:20.109378	2025-06-29 11:51:58.568418	12	f	\N
110	KACC 14554T	Lysobacter capsici	Type strain of Lysobacter capsici	\N	\N	\N	\N	\N	\N	\N	\N	This is the KACC designation for the type strain YC5194T. All test data is listed under the YC5194T entry.	t	2025-06-26 06:20:20.109378	2025-06-29 11:51:58.568418	12	f	\N
111	KCTC 22007T	Lysobacter capsici	Type strain of Lysobacter capsici	\N	\N	\N	\N	\N	\N	\N	\N	This is the KCTC designation for the type strain YC5194T. All test data is listed under the YC5194T entry.	t	2025-06-26 06:20:20.109378	2025-06-29 11:51:58.568418	12	f	\N
112	YC 5194T	Lysobacter capsici	Type strain of Lysobacter capsici	Type strain of Lysobacter capsici. Also known as DSM 19286T, KACC 14554T, KCTC 22007T.	\N	\N	\N	\N	\N	\N	\N	This is the primary designation for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms.	t	2025-06-26 06:20:20.109378	2025-06-29 11:51:58.568418	12	f	\N
114	KACC 19816T	Lysobacter caseinilyticus	Strain KACC 19816T	Type strain of Lysobacter caseinilyticus.	\N	\N	\N	\N	\N	\N	\N	All data points except colony size are cited from Chhetri et al. 2019 in the source document.	t	2025-06-26 06:21:59.494506	2025-06-29 11:51:58.568418	13	f	\N
190	KCTC 42810T	Lysobacter humi	Type strain of Lysobacter humi	\N	\N	\N	\N	\N	\N	\N	\N	This is the KCTC designation for the type strain FJY8T. All test data is listed under the FJY8T entry.	t	2025-06-26 07:37:24.903408	2025-06-29 11:51:58.568418	29	f	\N
78	ATCC 29482T	Lysobacter brunescens	Strain UASM D, ATCC 29482	Type strain of Lysobacter brunescens.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 77 (ATCC 29482). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 77 (ATCC 29482).\nOriginal notes: This is the type strain designation for ATCC 29482. Data is identical.	t	2025-06-26 02:56:46.609219	2025-06-29 11:52:07.11539	9	f	\N
108	KACC 17141T	Lysobacter caeni	Strain KACC 17141T	Type strain of Lysobacter caeni, isolated from pesticide sediment.	Осадок пестицида	\N	\N	\N	\N	\N	\N	Data compiled from pages 5, 48, 69, 70. Conflicting data for salt tolerance and GC content was found between tables.	t	2025-06-26 06:11:46.884141	2025-06-29 11:51:58.568418	11	f	\N
113	YC5194T	Lysobacter capsici	Type strain of Lysobacter capsici	\N	\N	\N	\N	\N	\N	\N	\N	This is a duplicate entry for YC 5194T. All test data is listed under the primary YC 5194T entry.	t	2025-06-26 06:20:20.109378	2025-06-29 11:51:58.568418	12	f	\N
151	UASM 18L	Lysobacter enzymogenes	Strain ATCC 29485/6	Strain of Lysobacter enzymogenes. Also known as ATCC 29485/6.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
152	UASM 4553	Lysobacter enzymogenes	Strain UASM 4553	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
153	UASM 4554	Lysobacter enzymogenes	Strain UASM 4554	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
154	UASM 4555	Lysobacter enzymogenes	Strain UASM 4555	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
149	KCTC 12131T	Lysobacter enzymogenes	Type strain of Lysobacter enzymogenes	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: This is the KCTC designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.	t	2025-06-26 07:07:28.925588	2025-06-29 11:52:07.11539	21	f	\N
150	LMG 8762T	Lysobacter enzymogenes	Type strain of Lysobacter enzymogenes	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: This is the LMG designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.	t	2025-06-26 07:07:28.925588	2025-06-29 11:52:07.11539	21	f	\N
106	BUT-8T	Lysobacter caeni	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желто-зеленые колонии. [5, 6]	Активный ил с очистных сооружений	Порён, Южная Корея	\N	\N	\N	\N	\N	Также известен как KCTC 23221T и CCUG 59800T. [5, 6]	t	2025-06-26 06:11:46.884141	2025-06-29 11:51:58.568418	11	f	\N
115	C8-1T	Lysobacter cavernae	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [7, 8]	Стена пещеры	Пещера Ёнчхон, провинция Кёнсан-Пукто, Южная Корея	\N	\N	\N	\N	\N	Также известен как YIM C01544T и KCTC 42504T. [7, 8]	t	2025-06-26 06:24:48.508178	2025-06-29 11:51:58.568418	14	f	\N
4	KACC 18502T	Lysobacter aestuarii	Strain KACC 18502T	Strain isolated from estuarine sediments.	Эстуарные отложения	\N	\N	\N	\N	\N	\N	Data from tables on pages 48 and 52.	t	2025-06-26 01:25:32.136319	2025-06-29 11:51:58.568418	5	f	\N
5	S2-CT	Lysobacter aestuarii	Strain S2-CT	Type strain of Lysobacter aestuarii.	Estuarine environment	\N	\N	\N	\N	\N	\N	Data from table on page 5.	t	2025-06-26 01:25:32.136319	2025-06-29 11:51:58.568418	5	f	\N
99	UASM CB2	Lysobacter brunescens	Strain UASM CB2	Strain of Lysobacter brunescens with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 2.	t	2025-06-26 03:04:32.422276	2025-06-29 11:51:58.568418	9	f	\N
125	KACC 18720	Lysobacter daejeonensis	Type strain of Lysobacter daejeonensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 126 (KCTC 12600).\nOriginal notes: This is the KACC designation for the type strain KCTC 12600T. All test data is listed under the KCTC 12600T entry.	t	2025-06-26 06:34:41.601951	2025-06-29 11:51:58.568418	17	f	\N
128	Dae08T	Lysobacter daejeonensis	Type strain of Lysobacter daejeonensis	Type strain isolated from a freshwater stream sediment in Daejeon, South Korea. Also known as DSM 17634T, GH1-9T, KACC 11406T, KACC 18720.	freshwater stream sediment	Daejeon, South Korea	\N	\N	\N	\N	\N	Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 06:48:31.463937	2025-06-29 11:51:58.568418	17	f	\N
129	DSM 17634T	Lysobacter daejeonensis	Type strain of Lysobacter daejeonensis	\N	\N	\N	\N	\N	\N	\N	\N	This is the DSM designation for the type strain Dae08T. All test data is listed under the Dae08T entry.	t	2025-06-26 06:48:31.463937	2025-06-29 11:51:58.568418	17	f	\N
130	GH1-9T	Lysobacter daejeonensis	Type strain of Lysobacter daejeonensis	\N	\N	\N	\N	\N	\N	\N	\N	This is a designation for the type strain Dae08T. All test data is listed under the Dae08T entry.	t	2025-06-26 06:48:31.463937	2025-06-29 11:51:58.568418	17	f	\N
127	KCTC 12600T	Lysobacter daejeonensis	Type strain of Lysobacter daejeonensis	Type strain of Lysobacter daejeonensis, isolated from stream sediment. Also known as KACC 18720.	Осадок ручья	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 125 (KACC 18720). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 126 (KCTC 12600).\nOriginal notes: DUPLICATE of Strain ID 125 (KACC 18720).\nOriginal notes: Data is a compilation from all tables mentioning this strain or its synonyms. Significant conflicts were found for GC content, salt tolerance, catalase, and trypsin activity.	t	2025-06-26 06:34:41.601951	2025-06-29 11:52:07.11539	17	f	\N
132	DSM 18482T	Lysobacter defluvii	Type strain of Lysobacter defluvii	Type strain isolated from activated sludge in Braunschweig, Germany. Also known as IMMIB APB-9T.	activated sludge	Braunschweig, Germany	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 133 (IMMIB APB-9T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 133 (IMMIB APB-9T).\nOriginal notes: DUPLICATE of Strain ID 133 (IMMIB APB-9T).\nOriginal notes: Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive. Conflicting data was resolved using BacDive as the primary source.	t	2025-06-26 06:52:03.607207	2025-06-29 11:52:07.11539	18	f	\N
133	IMMIB APB-9T	Lysobacter defluvii	Type strain of Lysobacter defluvii	\N	\N	\N	\N	\N	\N	\N	\N	This is the IMMIB designation for the type strain DSM 18482T. All test data is listed under the DSM 18482T entry.	t	2025-06-26 06:52:03.607207	2025-06-29 11:51:58.568418	18	f	\N
126	KCTC 12600	Lysobacter daejeonensis	Type strain of Lysobacter daejeonensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 125 (KACC 18720). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 125 (KACC 18720).\nOriginal notes: This is a designation for the type strain KCTC 12600T. All test data is listed under the KCTC 12600T entry.	t	2025-06-26 06:34:41.601951	2025-06-29 11:52:07.11539	17	f	\N
134	DS-58T	Lysobacter dokdonensis	Type strain of Lysobacter dokdonensis	Type strain isolated from soil on Dokdo island, South Korea. Also known as DSM 17958T, KACC 18711T, KCTC 12822T.	soil	Dokdo, South Korea	\N	\N	\N	\N	\N	Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive. Conflicting data for nitrate reduction was resolved.	t	2025-06-26 06:57:10.819485	2025-06-29 11:51:58.568418	19	f	\N
137	KCTC 12822T	Lysobacter dokdonensis	Type strain of Lysobacter dokdonensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 135 (DSM 17958T).\nOriginal notes: This is the KCTC designation for the type strain DS-58T. All test data is listed under the DS-58T entry.	t	2025-06-26 06:57:10.819485	2025-06-29 11:51:58.568418	19	f	\N
136	KACC 18711T	Lysobacter dokdonensis	Type strain of Lysobacter dokdonensis	\N	\N	\N	\N	\N	\N	\N	\N	This is a KACC designation for the type strain DS-58T. All test data is listed under the DS-58T entry.	t	2025-06-26 06:57:10.819485	2025-06-29 11:51:58.568418	19	f	\N
139	DSM 2043T	Lysobacter enzymogenes	Type strain of Lysobacter enzymogenes	Type strain isolated from soil in Wisconsin, USA. Also known as ATCC 29487T, LMG 8762T, KACC 10127T, BCRC 11654T, KCTC 12131T.	soil	Wisconsin, USA	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive. Conflicting data was resolved.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
140	495T	Lysobacter enzymogenes	Strain UASM 495, ATCC 29488	Strain of Lysobacter enzymogenes. Also known as UASM 495 and ATCC 29488.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
141	ATCC 21123	Lysobacter enzymogenes	Strain ATCC 21123	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
142	ATCC 27796	Lysobacter enzymogenes	Strain UASM AL-1	Strain of Lysobacter enzymogenes. Also known as UASM AL-1.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
120	K007T	Lysobacter concretionis	Type strain of Lysobacter concretionis	Type strain of Lysobacter concretionis. Also known as DSM 16239T, KACC 11484T, KCTC 12205T, Ko07T.	\N	\N	\N	\N	\N	\N	\N	Data is a compilation from all tables mentioning this strain or its synonyms. Conflicting data was found for aesculin hydrolysis and GC content.	t	2025-06-26 06:27:04.328668	2025-06-29 11:51:58.568418	15	f	\N
124	BZ	Lysobacter cucumeris	Strain BZ	Strain of Lysobacter cucumeris used in a comparative study.	\N	\N	\N	\N	\N	\N	\N	All data points are from the table on page 57.	t	2025-06-26 06:30:03.856434	2025-06-29 11:51:58.568418	16	f	\N
131	KACC 11406T	Lysobacter daejeonensis	Type strain of Lysobacter daejeonensis	\N	\N	\N	\N	\N	\N	\N	\N	This is the KACC designation for the type strain Dae08T. All test data is listed under the Dae08T entry.	t	2025-06-26 06:48:31.463937	2025-06-29 11:51:58.568418	17	f	\N
143	ATCC 29485/6	Lysobacter enzymogenes	Strain UASM 18L	Strain of Lysobacter enzymogenes. Also known as UASM 18L.	\N	\N	\N	\N	\N	\N	\N	This is a designation for the strain UASM 18L. All test data is listed under the UASM 18L entry.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
684	AM20-91T	Lysobacter silvestris	\N	Грамотрицательная, палочковидная, подвижная, каталазоположительная и оксидазоположительная бактерия.	Альпийская лесная почва	Монтиггл, Южный Тироль, Италия	\N	\N	\N	\N	\N	Дополнительные тесты, не входящие в канонический список, включают: полярный жгутик (+), липаза (C14) (-), β-галактозидаза (+), β-глюкозидаза (+), N-ацетил-β-D-глюкозаминидаза (+).	t	2025-06-28 02:44:37.959633	2025-06-29 11:51:58.568418	38	f	\N
685	CCTCC AB2014319T	Lysobacter novalis	\N	Грамотрицательная, темно-желтая, аэробная, палочковидная бактерия со скользящей подвижностью.	Почва с парового поля	Йонъин, Южная Корея	\N	\N	\N	\N	\N	Также известен как THG-PC7T. [1] Дополнительные тесты, не входящие в канонический список, включают: полярный жгутик (-), липаза (C14) (+), β-галактозидаза (+), β-глюкозидаза (+), N-ацетил-β-D-глюкозаминидаза (+).	t	2025-06-28 02:44:37.959633	2025-06-29 11:51:58.568418	39	f	\N
171	PB-6250T	Lysobacter firmicutimachus	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует кремово-желтые колонии. [3, 4]	Речная вода	Река Тафф, Кардифф, Великобритания	\N	\N	\N	\N	\N	Также известен как LMG 24580T и CCUG 55848T. [3, 4]	t	2025-06-26 07:22:26.618307	2025-06-29 11:51:58.568418	24	f	\N
135	DSM 17958T	Lysobacter dokdonensis	Type strain of Lysobacter dokdonensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 137 (KCTC 12822T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 137 (KCTC 12822T).\nOriginal notes: This is the DSM designation for the type strain DS-58T. All test data is listed under the DS-58T entry.	t	2025-06-26 06:57:10.819485	2025-06-29 11:52:07.11539	19	f	\N
177	ATCC 29489	Lysobacter gummosus	Type strain of Lysobacter gummosus	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: This is a designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.	t	2025-06-26 07:33:14.429692	2025-06-29 11:52:07.11539	27	f	\N
693	KCTC 12601T	Lysobacter panaciterrae	\N	Грамотрицательная, аэробная, палочковидная, неспорообразующая бактерия. [1] Обладает скользящей подвижностью. [4]	Почва с поля женьшеня	Провинция Почхон, Южная Корея	\N	\N	\N	\N	\N	Также известен как CC-Bw-6T и Gsoil 068T (согласно публикации Ten et al., 2009, но позже Gsoil 068T был переклассифицирован). [1] Впоследствии был переклассифицирован в Luteimonas panaciterrae. [10]	t	2025-06-28 07:55:31.590866	2025-06-29 11:51:58.568418	45	f	\N
698	5GH18-14T	Lysobacter rhizosphaerae	\N	Грамотрицательная, аэробная, палочковидная, подвижная бактерия. Образует желтые, круглые, гладкие колонии. [1, 2]	Ризосфера Aglaia odorata	Гуанчжоу, провинция Гуандун, Китай	\N	\N	\N	\N	\N	Также известен как KACC 18544T и CCTCC AB 2015201T. [1, 2]	t	2025-06-28 08:04:18.217889	2025-06-29 11:51:58.568418	50	f	\N
701	T20R-70T	Lysobacter solanacearum	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует бледно-желтые, круглые, выпуклые колонии. [1, 2]	Почва	Провинция Кёнгидо, Южная Корея	\N	\N	\N	\N	\N	Также известен как CHu50b-3-2T, KACC 18656T и JCM 32178T. [1, 2]	t	2025-06-28 08:10:22.874785	2025-06-29 11:51:58.568418	53	f	\N
157	UASM 4558	Lysobacter enzymogenes	Strain UASM 4558	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
158	UASM 4559	Lysobacter enzymogenes	Strain UASM 4559	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
159	UASM 4560	Lysobacter enzymogenes	Strain UASM 4560	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
160	UASM 4561	Lysobacter enzymogenes	Strain UASM 4561	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
170	BCRC 11	Lysobacter enzymogenes subsp. enzymogenes	Strain BCRC 11	Strain of the subspecies Lysobacter enzymogenes subsp. enzymogenes.	\N	\N	\N	\N	\N	\N	\N	All data points are from the table on page 40.	t	2025-06-26 07:17:39.437709	2025-06-29 11:51:58.568418	23	f	\N
173	Gsoil 357T	Lysobacter ginsengisoli	Strain KCTC 12602T	Type strain of Lysobacter ginsengisoli, isolated from soil of a ginseng field. Also known as KCTC 12602T.	soil of a ginseng field	Pocheon, Gyeonggi Province, South Korea	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 07:31:04.56484	2025-06-29 11:51:58.568418	26	f	\N
174	KCTC 12602	Lysobacter ginsengisoli	Type strain of Lysobacter ginsengisoli	\N	\N	\N	\N	\N	\N	\N	\N	This is the KCTC designation for the type strain Gsoil 357T. All test data is listed under the Gsoil 357T entry.	t	2025-06-26 07:31:04.56484	2025-06-29 11:51:58.568418	26	f	\N
175	KCTC 12602T	Lysobacter ginsengisoli	Type strain of Lysobacter ginsengisoli	\N	\N	\N	\N	\N	\N	\N	\N	This is the KCTC designation for the type strain Gsoil 357T. All test data is listed under the Gsoil 357T entry.	t	2025-06-26 07:31:04.56484	2025-06-29 11:51:58.568418	26	f	\N
176	ATCC 29489T	Lysobacter gummosus	Type strain of Lysobacter gummosus	Type strain of Lysobacter gummosus, isolated from soil. Also known as DSM 6980T, LMG 8763T, etc.	soil	USA, Iowa	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive. Conflicting data was resolved.	t	2025-06-26 07:33:14.429692	2025-06-29 11:51:58.568418	27	f	\N
188	17J68-2T	Lysobacter humi	Type strain of Lysobacter humi	\N	\N	\N	\N	\N	\N	\N	\N	This is a designation for the type strain FJY8T. All test data is listed under the FJY8T entry.	t	2025-06-26 07:37:24.903408	2025-06-29 11:51:58.568418	29	f	\N
189	17J7-1T	Lysobacter humi	Type strain of Lysobacter humi	\N	\N	\N	\N	\N	\N	\N	\N	This is a designation for the type strain FJY8T. All test data is listed under the FJY8T entry.	t	2025-06-26 07:37:24.903408	2025-06-29 11:51:58.568418	29	f	\N
191	Dae16T	Lysobacter koreensis	Strain KACC 11581T, KCTC 12204T, DSM 17633	Type strain of Lysobacter koreensis, isolated from greenhouse soil. Also known as KACC 11581T and KCTC 12204T.	greenhouse soil	Suwon, Gyeonggi Province, South Korea	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 07:40:33.583319	2025-06-29 11:51:58.568418	30	f	\N
192	KACC 11581T	Lysobacter koreensis	Type strain of Lysobacter koreensis	\N	\N	\N	\N	\N	\N	\N	\N	This is the KACC designation for the type strain Dae16T. All test data is listed under the Dae16T entry.	t	2025-06-26 07:40:33.583319	2025-06-29 11:51:58.568418	30	f	\N
193	KCTC 12204T	Lysobacter koreensis	Type strain of Lysobacter koreensis	\N	\N	\N	\N	\N	\N	\N	\N	This is the KCTC designation for the type strain Dae16T. All test data is listed under the Dae16T entry.	t	2025-06-26 07:40:33.583319	2025-06-29 11:51:58.568418	30	f	\N
194	ZLD-17T	Lysobacter korlensis	Strain KCTC 42168, CGMCC 1.12943	Type strain of Lysobacter korlensis, isolated from a soil sample.	soil	Korla, Xinjiang, China	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain, cross-referenced with BacDive.	t	2025-06-26 07:46:04.762326	2025-06-29 11:51:58.568418	31	f	\N
195	UKS-15T	Lysobacter lacus	Strain KCTC 42810T, NBRC 109678T	Type strain of Lysobacter lacus, isolated from freshwater lake sediment.	freshwater lake sediment	Uksan, Republic of Korea	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from the PDF and BacDive.	t	2025-06-26 07:48:31.490817	2025-06-29 11:51:58.568418	32	f	\N
196	KMU-14T	Lysobacter maris	Strain KCTC 42381T, NBRC 110750T	Type strain of Lysobacter maris, isolated from seawater. Also known as KCTC 42381T and NBRC 110750T.	seawater	Jeju Island, Republic of Korea	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 07:50:15.081584	2025-06-29 11:51:58.568418	33	f	\N
197	KCTC 42381T	Lysobacter maris	Type strain of Lysobacter maris	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 198 (NBRC 110750T).\nOriginal notes: This is the KCTC designation for the type strain KMU-14T. All test data is listed under the KMU-14T entry.	t	2025-06-26 07:50:15.081584	2025-06-29 11:51:58.568418	33	f	\N
199	CIP 107229T	Lysobacter mephitis	Type strain of Lysobacter mephitis	Type strain of Lysobacter mephitis.	\N	\N	\N	\N	\N	\N	\N	Data extracted from the table on page 57.	t	2025-06-26 07:57:19.568773	2025-06-29 11:51:58.568418	34	f	\N
200	9NM-14T	Lysobacter mobilis	Strain DSM 27574T, KCTC 52627T	Type strain of Lysobacter mobilis, isolated from zinc-lead mine tailings.	zinc-lead mine tailings	Dongshengmiao, Inner Mongolia, China	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 07:57:19.568773	2025-06-29 11:51:58.568418	35	f	\N
201	DSM 27574T	Lysobacter mobilis	Type strain of Lysobacter mobilis	\N	\N	\N	\N	\N	\N	\N	\N	This is the DSM designation for the type strain 9NM-14T. All test data is listed under the 9NM-14T entry.	t	2025-06-26 07:57:19.568773	2025-06-29 11:51:58.568418	35	f	\N
202	KCTC 52627T	Lysobacter mobilis	Type strain of Lysobacter mobilis	\N	\N	\N	\N	\N	\N	\N	\N	This is the KCTC designation for the type strain 9NM-14T. All test data is listed under the 9NM-14T entry.	t	2025-06-26 07:57:19.568773	2025-06-29 11:51:58.568418	35	f	\N
206	DSM 18481T	Lysobacter niastensis	Strain GH41-7T, KACC 11588T, KACC 22750T	Type strain of Lysobacter niastensis, isolated from greenhouse soil. Also known as GH41-7T, KACC 11588T, KACC 22750T.	greenhouse soil	Yongin, Gyeonggi Province, South Korea	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 07:59:40.869851	2025-06-29 11:51:58.568418	37	f	\N
686	83-4T	Lysobacter oculi	\N	Грамотрицательная, палочковидная, каталазо- и оксидазоположительная бактерия, образующая желтые колонии. [1, 2, 3]	Секрет мейбомиевых желез человека	Пекин, Китай	\N	\N	\N	\N	\N	Также известен как CGMCC 1.13464T и NRBC 113451T. [2] Размер клеток 2.7 × 1.3 мкм. [3]	t	2025-06-28 07:47:08.669393	2025-06-29 11:51:58.568418	40	f	\N
699	CTN-1T	Lysobacter ruishenii	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые, круглые, выпуклые колонии. [1, 2, 3]	Почва	Пекин, Китай	\N	\N	\N	\N	\N	Также известен как DSM 22393T и KCTC 23715T. [1, 2, 3]	t	2025-06-28 08:05:41.237309	2025-06-29 11:51:58.568418	51	f	\N
184	KACC 16618	Lysobacter hankyongensis	Type strain of Lysobacter hankyongensis	\N	\N	\N	\N	\N	\N	\N	\N	This is the KACC designation for the type strain KTCe-2T. All test data is listed under the KTCe-2T entry.	t	2025-06-26 07:35:10.644027	2025-06-29 11:51:58.568418	28	f	\N
185	KACC 16618T	Lysobacter hankyongensis	Type strain of Lysobacter hankyongensis	\N	\N	\N	\N	\N	\N	\N	\N	This is the KACC designation for the type strain KTCe-2T. All test data is listed under the KTCe-2T entry.	t	2025-06-26 07:35:10.644027	2025-06-29 11:51:58.568418	28	f	\N
186	KTCe-2T	Lysobacter hankyongensis	Strain KACC 16618T	Type strain of Lysobacter hankyongensis, isolated from activated sludge. Also known as KACC 16618T.	activated sludge	Anseong, South Korea	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 07:35:10.644027	2025-06-29 11:51:58.568418	28	f	\N
187	FJY8T	Lysobacter humi	Strain KCTC 42810T, DSM 27573	Type strain of Lysobacter humi, isolated from forest soil. Also known as KCTC 42810T, 17J68-2T, 17J7-1T.	forest soil	South Korea	\N	\N	\N	\N	\N	This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 07:37:24.903408	2025-06-29 11:51:58.568418	29	f	\N
27	UASM 4045	Lysobacter antibioticus	Strain ATCC 29481	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 18 (ATCC 29481).\nOriginal notes: Data from Table 9 on page 1. Also known as ATCC 29481.	t	2025-06-26 02:08:58.160833	2025-06-29 11:51:58.568418	6	f	\N
118	YIM C01544T	Lysobacter cavernae	Type strain of Lysobacter cavernae	\N	\N	\N	\N	\N	\N	\N	\N	This is the YIM designation for the type strain C8-1T. All test data is listed under the C8-1T entry.	t	2025-06-26 06:24:48.508178	2025-06-29 11:51:58.568418	14	f	\N
121	KACC 11484T	Lysobacter concretionis	Type strain of Lysobacter concretionis	\N	\N	\N	\N	\N	\N	\N	\N	This is the KACC designation for the type strain K007T. All test data is listed under the K007T entry.	t	2025-06-26 06:27:04.328668	2025-06-29 11:51:58.568418	15	f	\N
123	Ko07T	Lysobacter concretionis	Type strain of Lysobacter concretionis	\N	\N	\N	\N	\N	\N	\N	\N	This is a variant spelling for the type strain K007T. All test data is listed under the K007T entry.	t	2025-06-26 06:27:04.328668	2025-06-29 11:51:58.568418	15	f	\N
138	YJ15T	Lysobacter tongrenensis	Type strain of Lysobacter tongrenensis	Type strain of Lysobacter tongrenensis. Also known as KCTC 52206T.	\N	\N	\N	\N	\N	\N	\N	Data extracted from the table on page 73.	t	2025-06-26 06:57:10.819485	2025-06-29 11:51:58.568418	20	f	\N
122	KCTC 12205T	Lysobacter concretionis	Type strain of Lysobacter concretionis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 119 (DSM 16239T).\nOriginal notes: This is the KCTC designation for the type strain K007T. All test data is listed under the K007T entry.	t	2025-06-26 06:27:04.328668	2025-06-29 11:51:58.568418	15	f	\N
148	KACC 11382T	Lysobacter enzymogenes	Strain KACC 11382T	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 7.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
708	RS-LYSO-3T	Lysobacter erysipheiresistens	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [7, 8]	Почва	Тэджон, Южная Корея	\N	\N	\N	\N	\N	Также известен как KCTC 12900T и DSM 19330T. [7, 8]	t	2025-06-28 08:22:56.033373	2025-06-29 11:51:58.568418	55	f	\N
198	NBRC 110750T	Lysobacter maris	Type strain of Lysobacter maris	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 197 (KCTC 42381T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 197 (KCTC 42381T).\nOriginal notes: This is the NBRC designation for the type strain KMU-14T. All test data is listed under the KMU-14T entry.	t	2025-06-26 07:50:15.081584	2025-06-29 11:52:07.11539	33	f	\N
687	JCM 18257T	Lysobacter oligotrophicus	\N	Грамотрицательная, неспорообразующая, палочковидная, аэробная бактерия. [6, 7] Проявляет олиготрофные свойства, не растет в средах с высокой концентрацией органических соединений. [6]	Пресная вода с микробными матами	Озеро Танаго Ике, Скарвснес, Антарктида	\N	\N	\N	\N	\N	Также известен как 107-E2T и ATCC BAA-2438T. [6] В поздней стационарной фазе образует водорастворимый темно-коричневый пигмент (меланин). [3, 6]	t	2025-06-28 07:49:04.951662	2025-06-29 11:51:58.568418	41	f	\N
696	KCTC 12624T	Lysobacter pocheonensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2, 3]	Почва с поля женьшеня	Пхочхон, провинция Кёнгидо, Южная Корея	\N	\N	\N	\N	\N	Также известен как 50T, Gsoil 193T и YS-37T. [1, 2, 3]	t	2025-06-28 08:00:51.681277	2025-06-29 11:51:58.568418	48	f	\N
700	7C-9T	Lysobacter sediminicola	\N	Грамотрицательная, аэробная, неподвижная, палочковидная бактерия. Образует желтые, круглые, выпуклые колонии. [1, 2, 3]	Осадок пресной воды	Плотина Тэчхон, Южная Корея	\N	\N	\N	\N	\N	Также известен как KCTC 22340T и CCUG 56350T. [1, 2, 3]	t	2025-06-28 08:08:11.075227	2025-06-29 11:51:58.568418	52	f	\N
703	DCY21T	Lysobacter soli	\N	Грамотрицательная, аэробная, палочковидная бактерия со скользящей подвижностью. Образует желтоватые колонии. [4, 5]	Почва с поля женьшеня	Пхочхон, провинция Кёнгидо, Южная Корея	\N	\N	\N	\N	\N	Также известен как KCTC 22011T, KACC 15381T и KACC 22011T. [4, 5]	t	2025-06-28 08:17:14.808024	2025-06-29 11:51:58.568418	46	f	\N
704	zong215T	Lysobacter zonguldakensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые, круглые колонии. [6, 7]	Почва	Зонгулдак, Турция	\N	\N	\N	\N	\N	Также известен как DSM 22241T и CCUG 57973T. [6, 7]	t	2025-06-28 08:17:14.808024	2025-06-29 11:51:58.568418	54	f	\N
1	GH19-3	Lysobacter yangpyeongensis	Strain GH19-3	Automated test by Gemini AI - it finally works!	Soil from a greenhouse	Yangpyeong, Gyeonggi province, Republic of Korea	2009-08-01	\N	\N	\N	\N	Also known as KACC 13310 or DSM 22445. The paper describing the strain was published in 2009.	t	2025-06-26 01:19:03.170621	2025-06-29 11:51:58.568418	1	f	\N
19	BCRC 11653T	Lysobacter antibioticus	Strain BCRC 11653T	Type strain of Lysobacter antibioticus.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 14.	t	2025-06-26 02:05:40.181	2025-06-29 11:51:58.568418	6	f	\N
43	ZS79T	Lysobacter arseniciresistens	Strain ZS79T	Type strain of Lysobacter arseniciresistens.	\N	\N	\N	\N	\N	\N	\N	Data compiled from tables on pages 5, 8, and 27. Some conflicting data points were noted and resolved.	t	2025-06-26 02:51:18.044327	2025-06-29 11:51:58.568418	8	f	\N
81	DSM 6979T	Lysobacter brunescens	Strain DSM 6979T	Type strain of Lysobacter brunescens.	\N	\N	\N	\N	\N	\N	\N	Data compiled from table on page 24.	t	2025-06-26 02:56:46.609219	2025-06-29 11:51:58.568418	9	f	\N
82	KACC 11385T	Lysobacter brunescens	Strain KACC 11385T	Type strain of Lysobacter brunescens.	\N	\N	\N	\N	\N	\N	\N	Data compiled from tables on pages 25-27.	t	2025-06-26 02:56:46.609219	2025-06-29 11:51:58.568418	9	f	\N
83	KCTC 12130T	Lysobacter brunescens	Strain KCTC 12130T	Strain of Lysobacter brunescens isolated from soil.	Почва	\N	\N	\N	\N	\N	\N	Data compiled from table on page 31.	t	2025-06-26 02:56:46.609219	2025-06-29 11:51:58.568418	9	f	\N
116	IPC6T	Lysobacter cavernae	Type strain of Lysobacter cavernae	\N	\N	\N	\N	\N	\N	\N	\N	This is a designation for the type strain C8-1T. All test data is listed under the C8-1T entry.	t	2025-06-26 06:24:48.508178	2025-06-29 11:51:58.568418	14	f	\N
688	KACC 14553T	Lysobacter oryzae	\N	Грамотрицательная, палочковидная, аэробная бактерия, образующая бледно-желтые колонии.	Почва из теплицы	Корея	\N	\N	\N	\N	\N	Также известен как L. oryzae KCTC 22249T. Данные для этого штамма были собраны из разных таблиц в предоставленном документе.	t	2025-06-28 07:50:55.242479	2025-06-29 11:51:58.568418	42	f	\N
690	THG-DN8.2T	Lysobacter terrae	\N	Грамотрицательная, палочковидная, аэробная бактерия, образующая бледно-желтые колонии. [1]	Почва	Остров Чеджу, Южная Корея	\N	\N	\N	\N	\N	Все штаммы положительны на гидролиз Твин 80, L-тирозина, казеина и желатина. Отрицательны на восстановление нитратов, продукцию индола, подкисление глюкозы и аргининдигидролазу; гидролиз хитина, мочевины и эскулина.	t	2025-06-28 07:50:55.242479	2025-06-29 11:51:58.568418	43	f	\N
691	THG-YS3.6T	Lysobacter terrae	\N	Палочковидные бактерии, отрицательные на восстановление нитратов и продукцию индола.	Почва	Остров Чеджу, Южная Корея	\N	\N	\N	\N	\N	Данные из таблицы 'Физиологические характеристики штамма THG-YS3.6T'.	t	2025-06-28 07:50:55.242479	2025-06-29 11:51:58.568418	43	f	\N
697	SYSU H10001T	Lysobacter prati	\N	Грамотрицательная, аэробная, палочковидная бактерия, образующая желтые, круглые колонии. [2, 4]	Почва с луга на плато	Округ Хунъюань, провинция Сычуань, Китай	\N	\N	\N	\N	\N	Также известен как KCTC 72062T и CGMCC 1.16662T. [2, 3]	t	2025-06-28 08:02:14.256398	2025-06-29 11:51:58.568418	49	f	\N
100	UASM CB4	Lysobacter brunescens	Strain UASM CB4	Strain of Lysobacter brunescens with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 2.	t	2025-06-26 03:04:32.422276	2025-06-29 11:51:58.568418	9	f	\N
101	UASM CB5	Lysobacter brunescens	Strain UASM CB5	Strain of Lysobacter brunescens with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 2.	t	2025-06-26 03:04:32.422276	2025-06-29 11:51:58.568418	9	f	\N
102	UASM CB6	Lysobacter brunescens	Strain UASM CB6	Strain of Lysobacter brunescens with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 2.	t	2025-06-26 03:04:32.422276	2025-06-29 11:51:58.568418	9	f	\N
103	UASM CB7	Lysobacter brunescens	Strain UASM CB7	Strain of Lysobacter brunescens with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	Data from Table 9 on page 2.	t	2025-06-26 03:04:32.422276	2025-06-29 11:51:58.568418	9	f	\N
161	UASM 4562	Lysobacter enzymogenes	Strain UASM 4562	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
162	UASM 4563	Lysobacter enzymogenes	Strain UASM 4563	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
163	UASM 4564	Lysobacter enzymogenes	Strain UASM 4564	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
164	UASM 4565	Lysobacter enzymogenes	Strain UASM 4565	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
165	UASM 495	Lysobacter enzymogenes	Strain ATCC 29488, 495T	\N	\N	\N	\N	\N	\N	\N	\N	This is the UASM designation for the strain 495T. All test data is listed under the 495T entry.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
167	UASM Q1	Lysobacter enzymogenes	Strain UASM Q1	Strain of Lysobacter enzymogenes.	\N	\N	\N	\N	\N	\N	\N	Data from table on page 2.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	21	f	\N
145	ATCC 29488	Lysobacter enzymogenes subsp. cookii	Strain UASM 13B	Type strain of the subspecies Lysobacter enzymogenes subsp. cookii. Also known as UASM 13B.	soil	USA, Wisconsin	\N	\N	\N	\N	\N	Data is a compilation from the PDF (page 2) and BacDive. BacDive provided core physiological data, while the PDF provided specific acid production results.	t	2025-06-26 07:07:28.925588	2025-06-29 11:51:58.568418	22	f	\N
710	LMG 30077T	Lysobacter spongiae	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые, круглые, блестящие колонии. [1, 2]	Морская губка Aplysina aerophoba	Средиземное море, Кала-Монтго, Испания	\N	\N	\N	\N	\N	Также известен как KMM 9005T и CECT 9427T. [1, 2]	t	2025-06-28 08:27:25.420929	2025-06-29 11:51:58.568418	56	f	\N
718	UCT	Lysobacter soli	\N	Грамотрицательная, аэробная, палочковидная бактерия. Образует бледно-желтые колонии. [3]	Почва	Неизвестно	\N	\N	\N	\N	\N	Данные для этого штамма взяты из таблицы 'Дифференциальные фенотипические характеристики штамма UCT'. Вероятно, является синонимом DCY21T (Lysobacter soli) из-за почти идентичных характеристик.	t	2025-06-28 08:33:23.64213	2025-06-29 11:51:58.568418	46	f	\N
719	YIM 77875T	Lysobacter xinjiangensis	\N	Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует желтые, круглые колонии. [5, 6]	Почва	Синьцзян, Китай	\N	\N	\N	\N	\N	Также известен как CCTCC AB 2011043T и KCTC 23558T. [5, 6]	t	2025-06-28 08:33:23.64213	2025-06-29 11:51:58.568418	57	f	\N
720	YK-278	Lysobacter lactamgenus	\N	Грамотрицательная, аэробная, палочковидная бактерия, продуцирующая антибиотики цефабацины. [7, 8]	Почва	Япония	\N	\N	\N	\N	\N	Штамм-продуцент цефабацина. [7]	t	2025-06-28 08:33:23.64213	2025-06-29 11:51:58.568418	58	f	\N
721	YK-280	Lysobacter lactamgenus	\N	Грамотрицательная, аэробная, палочковидная бактерия, продуцирующая антибиотики цефабацины. [7, 8]	Почва	Япония	\N	\N	\N	\N	\N	Штамм-продуцент цефабацина. [7]	t	2025-06-28 08:33:23.64213	2025-06-29 11:51:58.568418	58	f	\N
724	812/17	Lysobacter sp.	\N	Неидентифицированный штамм Lysobacter.	Неизвестно	Неизвестно	\N	\N	\N	\N	\N	Данные для этого штамма взяты из таблицы 'Гидролиз:' в OCR.	t	2025-06-28 08:39:02.105974	2025-06-29 11:51:58.568418	60	f	\N
711	SG-8T	Lysobacter penaei	\N	Грамотрицательная, аэробная, не обладающая скользящей подвижностью, палочковидная бактерия. Образует светло-желтые колонии. [3, 4]	Содержимое кишечника тихоокеанской белой креветки (Penaeus vannamei)	Гуанчжоу, Китай	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 695 (GDMCC 1.1817T).\nOriginal notes: Также известен как GDMCC 1.1817T и KACC 21942T. [3, 4]	t	2025-06-28 08:27:25.420929	2025-06-29 11:51:58.568418	47	f	\N
727	R19T	Lysobacter niabensis	\N	Грамотрицательная, аэробная, палочковидная бактерия. Образует бледно-желтые колонии. [1, 2]	Почва с поля женьшеня	Провинция Кёнгидо, Южная Корея	\N	\N	\N	\N	\N	Данные для этого штамма взяты из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	t	2025-06-28 08:41:12.302332	2025-06-29 11:51:58.568418	36	f	\N
40	R7T	Lysobacter arenosi	\N	Грамотрицательная, аэробная, палочковидная бактерия. Образует бледно-желтые колонии.	Неизвестно	Неизвестно	\N	\N	\N	\N	\N	Данные для этого штамма взяты из таблиц 'Сравнение фенотипических характеристик штаммов R7T и R19Т' и 'Характеристики, отличающие штамм 5-21aT'. Название 'L. arenosi' используется условно, как в OCR.	t	2025-06-26 02:45:09.04858	2025-06-29 11:51:58.568418	7	f	\N
729	H21R20T	Lysobacter sp.	\N	Неидентифицированный штамм Lysobacter.	Неизвестно	Неизвестно	\N	\N	\N	\N	\N	Данные для этого штамма взяты из таблицы 'Дифференциальные фенотипические характеристики штамма H21R20T...'. Многие тесты не соответствуют каноническому списку.	t	2025-06-28 08:41:12.302332	2025-06-29 11:51:58.568418	60	f	\N
730	H23M41T	Lysobacter sp.	\N	Неидентифицированный штамм Lysobacter.	Неизвестно	Неизвестно	\N	\N	\N	\N	\N	Данные для этого штамма взяты из таблицы 'Дифференциальные фенотипические характеристики штамма H21R20T...'. Многие тесты не соответствуют каноническому списку.	t	2025-06-28 08:41:12.302332	2025-06-29 11:51:58.568418	60	f	\N
731	YK-90	Lysobacter lactamgenus	\N	Грамотрицательная, аэробная/факультативно-анаэробная, палочковидная бактерия, продуцирующая антибиотики цефабацины. [4, 5]	Почва	Япония	\N	\N	\N	\N	\N	Штамм-продуцент цефабацина. [4]	t	2025-06-28 08:41:12.302332	2025-06-29 11:51:58.568418	58	f	\N
735	THG-A13T	Lysobacter terrae	\N	Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует желтые колонии. [3, 4]	Почва	Остров Чеджу, Южная Корея	\N	\N	\N	\N	\N	Также известен как KACC 17646T и JCM 30600T. [3, 4]	t	2025-06-28 08:45:38.897799	2025-06-29 11:51:58.568418	43	f	\N
736	THG-DN8.7T	Lysobacter terrae	\N	Штамм Lysobacter terrae с некоторыми отличительными биохимическими характеристиками.	Почва	Остров Чеджу, Южная Корея	\N	\N	\N	\N	\N	Данные для этого штамма взяты из таблицы 'Дифференциальные биохимические и физиологические характеристики штаммов THG-DN8.7T и THG-DN8.3T'.	t	2025-06-28 08:45:38.897799	2025-06-29 11:51:58.568418	43	f	\N
738	KCTC 52206T	Lysobacter tongrenensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2]	Ризосферная почва риса (Oryza sativa L.)	Тунжэнь, провинция Гуйчжоу, Китай	\N	\N	\N	\N	\N	Также известен как YJ15T и MCCC 1K03268T. [1, 2]	t	2025-06-28 08:49:51.67424	2025-06-29 11:51:58.568418	20	f	\N
16	ATCC 29479	Lysobacter antibioticus	Strain UASM 3C	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 26 (UASM 3C). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 26 (UASM 3C).\nOriginal notes: Data from Table 9 on page 1. Also known as UASM 3C.	t	2025-06-26 02:05:40.181	2025-06-29 11:52:07.11539	6	f	\N
172	KACC 18545	Lysobacter tyrosinilyticus	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]	Ризосфера капусты, зараженной килой	Провинция Канвондо, Южная Корея	\N	\N	\N	\N	\N	Также известен как JCM 30601T. [3, 4]	t	2025-06-26 07:25:02.810458	2025-06-29 11:51:58.568418	62	f	\N
741	DSM 23410T	Lysobacter ximonensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2]	Почва	Округ Симэн, провинция Юньнань, Китай	\N	\N	\N	\N	\N	Также известен как KACC 14084T, KCTC 22336T, THG-PC7T, XM415T, CCTCC AB 208043T. [1, 2]	t	2025-06-28 08:51:38.768394	2025-06-29 11:51:58.568418	63	f	\N
742	KCTC 22558T	Lysobacter xinjiangensis	\N	Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует желтые, круглые колонии. [1, 2]	Почва	Синьцзян, Китай	\N	\N	\N	\N	\N	Также известен как RCML-52T, YIM 77875T и CCTCC AB 2011043T. [1, 2]	t	2025-06-28 08:53:23.449789	2025-06-29 11:51:58.568418	57	f	\N
743	YC6269T	Lysobacter yangpyeongensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2]	Почва	Янпхён, Южная Корея	\N	\N	\N	\N	\N	Также известен как DSM 17635T и KCTC 12890T. [1, 2]	t	2025-06-28 08:55:22.522263	2025-06-29 11:51:58.568418	1	f	\N
737	UM1T	Luteimonas tolerans	\N	Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует желтые, круглые, гладкие колонии. [1, 2] - Edited successfully!	Почва	Уттар-Прадеш, Индия	\N	\N	\N	\N	\N	Также известен как DSM 28473T и KCTC 42502T. [1, 2]	t	2025-06-28 08:47:18.018991	2025-06-29 11:51:58.568418	61	f	\N
714	U8T	Lysobacter humi	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]	Почва	Тэджон, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 713 (D10T).\nOriginal notes: Также известен как KACC 16548T и JCM 18933T. [3, 4]	t	2025-06-28 08:31:30.960414	2025-06-29 11:51:58.568418	29	f	\N
79	ATCC 29483	Lysobacter brunescens	Strain UASM 2	Strain of Lysobacter brunescens.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 84 (UASM 2). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 84 (UASM 2).\nOriginal notes: Data from Table 9 on page 2. Also known as UASM 2.	t	2025-06-26 02:56:46.609219	2025-06-29 11:52:07.11539	9	f	\N
705	GW1-59T	Lysobacter concretionis	\N	Грамотрицательная, аэробная, палочковидная бактерия, обладающая скользящей подвижностью. Образует желтые колонии. [1, 2]	Микробный мат в стоке термальных вод	Тэджон, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 122 (KCTC 12205T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 119 (DSM 16239T).\nOriginal notes: DUPLICATE of Strain ID 122 (KCTC 12205T).\nOriginal notes: Также известен как Ko07T, DSM 16239T, KCTC 12205T. [1, 2]	t	2025-06-28 08:22:56.033373	2025-06-29 11:52:07.11539	15	f	\N
179	Gsoil 068T	Lysobacter soli	\N	Грамотрицательная, аэробная, палочковидная бактерия со скользящей подвижностью. [12, 13]	Почва с поля женьшеня	Республика Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 703 (DCY21T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 703 (DCY21T).\nOriginal notes: DUPLICATE of Strain ID 703 (DCY21T).\nOriginal notes: Также известен как KCTC 22011T. [12] В OCR GC-содержание указано как 67.0%, в то время как в первоисточнике 65.4%. [12]	t	2025-06-26 07:33:14.429692	2025-06-29 11:52:07.11539	46	f	\N
689	KCTC 22249T	Lysobacter oryzae	\N	Грамотрицательная, палочковидная, аэробная бактерия, образующая желтые колонии. [1]	Почва из теплицы	Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 688 (KACC 14553T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 688 (KACC 14553T).\nOriginal notes: DUPLICATE of Strain ID 688 (KACC 14553T).\nOriginal notes: Также известен как L. oryzae KACC 14553T. Данные для этого штамма были собраны из разных таблиц в предоставленном документе.	t	2025-06-28 07:50:55.242479	2025-06-29 11:52:07.11539	42	f	\N
169	UASM 13B	Lysobacter enzymogenes subsp. cookii	Strain ATCC 29488	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 145 (ATCC 29488). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 145 (ATCC 29488).\nOriginal notes: DUPLICATE of Strain ID 145 (ATCC 29488).\nOriginal notes: This is the UASM designation for the strain ATCC 29488. All test data is listed under the ATCC 29488 entry.	t	2025-06-26 07:15:30.110978	2025-06-29 11:52:07.11539	22	f	\N
723	4284/11T	Lysobacter vadosa	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]	Морская губка Aplysina aerophoba	Средиземное море, Кала-Монтго, Испания	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 710 (LMG 30077T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 710 (LMG 30077T).\nOriginal notes: DUPLICATE of Strain ID 710 (LMG 30077T).\nOriginal notes: Также известен как KMM 9005T и CECT 9427T. [3, 4]	t	2025-06-28 08:39:02.105974	2025-06-29 11:52:07.11539	59	f	\N
740	KMM 9005T	Lysobacter vadosa	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [5, 6]	Морская губка Aplysina aerophoba	Средиземное море, Кала-Монтго, Испания	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 710 (LMG 30077T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 710 (LMG 30077T).\nOriginal notes: DUPLICATE of Strain ID 710 (LMG 30077T).\nOriginal notes: Также известен как LMG 30077T и CECT 9427T. [5, 6]	t	2025-06-28 08:49:51.67424	2025-06-29 11:52:07.11539	59	f	\N
17	ATCC 29480	Lysobacter antibioticus	Strain UASM L17	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 37 (UASM L17). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 37 (UASM L17).\nOriginal notes: Data from Table 9 on page 1. Also known as UASM L17.	t	2025-06-26 02:05:40.181	2025-06-29 11:52:07.11539	6	f	\N
722	CM-3-T8T	Lysobacter panacisoli	\N	Грамотрицательная, аэробная, палочковидная, неподвижная бактерия. Образует ярко-желтые колонии. [1, 2]	Почва с поля женьшеня	Ансон, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 692 (CJ29T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 692 (CJ29T).\nOriginal notes: DUPLICATE of Strain ID 692 (CJ29T).\nOriginal notes: Также известен как KACC 17502T и JCM 19212T. [1, 2] Данные для этого штамма взяты из таблицы 'Дифференциальные фенотипические характеристики штамма СМ-3-Т8Т'.	t	2025-06-28 08:39:02.105974	2025-06-29 11:52:07.11539	44	f	\N
104	UASM D	Lysobacter brunescens	Strain ATCC 29482	Type strain of Lysobacter brunescens.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 77 (ATCC 29482). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 78 (ATCC 29482T).\nOriginal notes: DUPLICATE of Strain ID 77 (ATCC 29482).\nOriginal notes: Data from Table 9 on page 2. Also known as ATCC 29482.	t	2025-06-26 03:04:32.422276	2025-06-29 11:52:07.11539	9	f	\N
80	ATCC 29484	Lysobacter brunescens	Strain UASM 6	Strain of Lysobacter brunescens.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 97 (UASM 6). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 97 (UASM 6).\nOriginal notes: DUPLICATE of Strain ID 97 (UASM 6).\nOriginal notes: Data from Table 9 on page 2. Also known as UASM 6.	t	2025-06-26 02:56:46.609219	2025-06-29 11:52:07.11539	9	f	\N
709	PAGU 1119T	Lysobacter capsici	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желто-кремовые колонии. [9, 10]	Ризосфера перца (Capsicum annuum L.)	Чинджу, провинция Кёнсан-Намдо, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 109 (DSM 19286T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 109 (DSM 19286T).\nOriginal notes: DUPLICATE of Strain ID 109 (DSM 19286T).\nOriginal notes: Также известен как YC5194T, KCTC 12891T, DSM 19286T. [9, 10]	t	2025-06-28 08:22:56.033373	2025-06-29 11:52:07.11539	12	f	\N
144	ATCC 29487T	Lysobacter enzymogenes	Type strain of Lysobacter enzymogenes	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: This is the ATCC designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.	t	2025-06-26 07:07:28.925588	2025-06-29 11:52:07.11539	21	f	\N
146	BCRC 11654T	Lysobacter enzymogenes	Type strain of Lysobacter enzymogenes	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: This is the BCRC designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.	t	2025-06-26 07:07:28.925588	2025-06-29 11:52:07.11539	21	f	\N
147	KACC 10127T	Lysobacter enzymogenes	Type strain of Lysobacter enzymogenes	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 139 (DSM 2043T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: DUPLICATE of Strain ID 139 (DSM 2043T).\nOriginal notes: This is a KACC designation for the type strain DSM 2043T. All test data is listed under the DSM 2043T entry.	t	2025-06-26 07:07:28.925588	2025-06-29 11:52:07.11539	21	f	\N
744	KACC 11407T	Lysobacter daejeonensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]	Микробный мат в стоке термальных вод	Тэджон, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 133 (IMMIB APB-9T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 133 (IMMIB APB-9T).\nOriginal notes: DUPLICATE of Strain ID 133 (IMMIB APB-9T).\nOriginal notes: Также известен как DSM 18482T. [3, 4]	t	2025-06-28 08:55:22.522263	2025-06-29 11:52:07.11539	17	f	\N
725	HX-5-24T	Lysobacter dokdonensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует бледно-желтые колонии. [5, 6]	Почва	Остров Токто, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 137 (KCTC 12822T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 135 (DSM 17958T).\nOriginal notes: DUPLICATE of Strain ID 137 (KCTC 12822T).\nOriginal notes: Также известен как KCTC 12822T и DSM 17958T. [5, 6]	t	2025-06-28 08:39:02.105974	2025-06-29 11:52:07.11539	19	f	\N
733	KVB24T	Lysobacter hankyongensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желто-оранжевые колонии. [3, 4]	Морская вода	Желтое море, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 136 (KACC 18711T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 136 (KACC 18711T).\nOriginal notes: DUPLICATE of Strain ID 136 (KACC 18711T).\nOriginal notes: Также известен как KACC 18711T и NBRC 111306T. [3, 4]	t	2025-06-28 08:43:15.469519	2025-06-29 11:52:07.11539	28	f	\N
166	UASM AL-1	Lysobacter enzymogenes	Strain ATCC 27796	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 142 (ATCC 27796). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 142 (ATCC 27796).\nOriginal notes: DUPLICATE of Strain ID 142 (ATCC 27796).\nOriginal notes: This is the UASM designation for the strain ATCC 27796. All test data is listed under the ATCC 27796 entry.	t	2025-06-26 07:07:28.925588	2025-06-29 11:52:07.11539	21	f	\N
178	DSM6980T	Lysobacter gummosus	Type strain of Lysobacter gummosus	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: This is the DSM designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.	t	2025-06-26 07:33:14.429692	2025-06-29 11:52:07.11539	27	f	\N
180	KACC 11386T	Lysobacter gummosus	Type strain of Lysobacter gummosus	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: This is the KACC designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.	t	2025-06-26 07:33:14.429692	2025-06-29 11:52:07.11539	27	f	\N
181	KCTC 12132T	Lysobacter gummosus	Type strain of Lysobacter gummosus	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: This is the KCTC designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.	t	2025-06-26 07:33:14.429692	2025-06-29 11:52:07.11539	27	f	\N
182	LMG 8763T	Lysobacter gummosus	Type strain of Lysobacter gummosus	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: This is the LMG designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.	t	2025-06-26 07:33:14.429692	2025-06-29 11:52:07.11539	27	f	\N
183	UASM 402	Lysobacter gummosus	Type strain of Lysobacter gummosus	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 176 (ATCC 29489T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: DUPLICATE of Strain ID 176 (ATCC 29489T).\nOriginal notes: This is the UASM designation for the type strain ATCC 29489T. All test data is listed under the ATCC 29489T entry.	t	2025-06-26 07:33:14.429692	2025-06-29 11:52:07.11539	27	f	\N
726	CHu40b-3-1	Lysobacter solanacearum	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует бледно-желтые колонии. [7, 8]	Почва	Провинция Кёнгидо, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 701 (T20R-70T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 701 (T20R-70T).\nOriginal notes: DUPLICATE of Strain ID 701 (T20R-70T).\nOriginal notes: Также известен как KACC 18656T и JCM 32178T. [7, 8]	t	2025-06-28 08:39:02.105974	2025-06-29 11:52:07.11539	53	f	\N
732	2-5T	Lysobacter koreensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует кремовые колонии. [1, 2]	Почва с поля женьшеня	Пхочхон, провинция Кёнгидо, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 193 (KCTC 12204T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 193 (KCTC 12204T).\nOriginal notes: DUPLICATE of Strain ID 193 (KCTC 12204T).\nOriginal notes: Также известен как KCTC 12204T и DSM 17633T. [1, 2]	t	2025-06-28 08:43:15.469519	2025-06-29 11:52:07.11539	30	f	\N
717	TLK-CK17T	Lysobacter maris	\N	Грамотрицательная, аэробная, палочковидная бактерия. Образует абрикосовые колонии. [1, 2]	Компост из коровьего навоза	Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 197 (KCTC 42381T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 198 (NBRC 110750T).\nOriginal notes: DUPLICATE of Strain ID 197 (KCTC 42381T).\nOriginal notes: Также известен как KCTC 42381T и NBRC 110750T. [1, 2]	t	2025-06-28 08:33:23.64213	2025-06-29 11:52:07.11539	33	f	\N
203	DSM 18244T	Lysobacter niabensis	Type strain of Lysobacter niabensis	Type strain of Lysobacter niabensis, isolated from greenhouse soil. Also known as GH34-4T and KACC 11587T.	greenhouse soil	Gyeonggi Province, South Korea	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: This is the master entry for the type strain. Data is a compilation from all tables mentioning this strain or its synonyms, cross-referenced with BacDive.	t	2025-06-26 07:57:19.568773	2025-06-29 11:52:07.11539	36	f	\N
204	GH34-4T	Lysobacter niabensis	Type strain of Lysobacter niabensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: This is a designation for the type strain DSM 18244T. All test data is listed under the DSM 18244T entry.	t	2025-06-26 07:57:19.568773	2025-06-29 11:52:07.11539	36	f	\N
205	KACC 11587T	Lysobacter niabensis	Type strain of Lysobacter niabensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: This is the KACC designation for the type strain DSM 18244T. All test data is listed under the DSM 18244T entry.	t	2025-06-26 07:57:19.568773	2025-06-29 11:52:07.11539	36	f	\N
207	GH41-7T	Lysobacter niastensis	Type strain of Lysobacter niastensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: This is a designation for the type strain DSM 18481T. All test data is listed under the DSM 18481T entry.	t	2025-06-26 07:59:40.869851	2025-06-29 11:52:07.11539	37	f	\N
208	KACC 11588T	Lysobacter niastensis	Type strain of Lysobacter niastensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: This is a KACC designation for the type strain DSM 18481T. All test data is listed under the DSM 18481T entry.	t	2025-06-26 07:59:40.869851	2025-06-29 11:52:07.11539	37	f	\N
209	KACC 22750T	Lysobacter niastensis	Type strain of Lysobacter niastensis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: This is a KACC designation for the type strain DSM 18481T. All test data is listed under the DSM 18481T entry.	t	2025-06-26 07:59:40.869851	2025-06-29 11:52:07.11539	37	f	\N
712	THG-SKA3T	Lysobacter mobilis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует белые колонии. [1, 2]	Почва из теплицы	Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: Также известен как KACC 11588T и LMG 24310T. [1, 2]	t	2025-06-28 08:31:30.960414	2025-06-29 11:52:07.11539	35	f	\N
734	GH19-3T	Lysobacter niabensis	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [1, 2]	Почва из теплицы	Провинция Кёнгидо, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 206 (DSM 18481T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: DUPLICATE of Strain ID 206 (DSM 18481T).\nOriginal notes: Также известен как KACC 11587T и DSM 18481T. [1, 2]	t	2025-06-28 08:45:38.897799	2025-06-29 11:52:07.11539	36	f	\N
18	ATCC 29481	Lysobacter antibioticus	Strain UASM 4045	Strain of Lysobacter antibioticus with specific biochemical reactions.	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 27 (UASM 4045). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 27 (UASM 4045).\nOriginal notes: Data from Table 9 on page 1. Also known as UASM 4045.	t	2025-06-26 02:05:40.181	2025-06-29 11:52:07.11539	6	f	\N
119	DSM 16239T	Lysobacter concretionis	Type strain of Lysobacter concretionis	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 122 (KCTC 12205T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 122 (KCTC 12205T).\nOriginal notes: This is the DSM designation for the type strain K007T. All test data is listed under the K007T entry.	t	2025-06-26 06:27:04.328668	2025-06-29 11:52:07.11539	15	f	\N
695	GDMCC 1.1817T	Lysobacter penaei	\N	Грамотрицательная, аэробная, не обладающая скользящей подвижностью, палочковидная бактерия. Образует светло-желтые колонии. [1, 2]	Содержимое кишечника тихоокеанской белой креветки (Penaeus vannamei)	Гуанчжоу, Китай	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 711 (SG-8T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 711 (SG-8T).\nOriginal notes: Также известен как SG-8T и KACC 21942T. [1, 2]	t	2025-06-28 07:58:48.567273	2025-06-29 11:52:07.11539	47	f	\N
713	D10T	Lysobacter humi	\N	Грамотрицательная, аэробная, палочковидная, подвижная (скользящая) бактерия. Образует желтые колонии. [3, 4]	Почва	Тэджон, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 714 (U8T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 714 (U8T).\nOriginal notes: Также известен как KACC 16548T и JCM 18933T. [3, 4]	t	2025-06-28 08:31:30.960414	2025-06-29 11:52:07.11539	29	f	\N
716	ZS60T	Lysobacter humi	\N	Грамотрицательная, аэробная, палочковидная бактерия. Образует желтые колонии. [3, 4]	Почва	Тэджон, Южная Корея	\N	\N	\N	\N	\N	DUPLICATE of Strain ID 714 (U8T). See master record for consolidated data.\nOriginal notes: DUPLICATE of Strain ID 714 (U8T).\nOriginal notes: DUPLICATE of Strain ID 713 (D10T).\nOriginal notes: Также известен как KACC 16548T и JCM 18933T. [3, 4]	t	2025-06-28 08:31:30.960414	2025-06-29 11:52:07.11539	29	f	\N
\.


--
-- Data for Name: test_categories; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_categories (category_id, category_name, description, sort_order, created_at) FROM stdin;
4	biochemical_breakdown	Biochemical_breakdown	4	2025-06-26 01:18:03.824687
1	morphological	Morphological	1	2025-06-26 01:18:03.824687
2	physiological	Physiological	2	2025-06-26 01:18:03.824687
5	biochemical_utilization	Biochemical_utilization	5	2025-06-26 01:18:03.824687
3	biochemical_enzymes	Biochemical_enzymes	3	2025-06-26 01:18:03.824687
14	biochemical_other	Other_biochemical	6	2025-06-27 09:22:49.359803
\.


--
-- Data for Name: test_results_boolean; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_results_boolean (result_id, strain_id, test_id, value_id, notes, confidence_level, tested_date, created_at, updated_at) FROM stdin;
37	2	2	5	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
38	2	19	65	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
39	4	2	5	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
3379	684	2	5	Источник: Margesin et al. (2018). [4]	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
40	4	19	65	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
3380	684	5	269	Проверено при 2-3% NaCl.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3381	684	7	17	Источник: Margesin et al. (2018). [4]	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
97	16	27	97	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
98	16	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
41	4	7	17	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
42	5	7	17	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
43	5	17	57	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
44	5	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
59	10	2	5	\N	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
45	5	10	29	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
46	5	18	61	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
100	17	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
101	17	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
60	10	9	25	From 'Гидролиз мочевины'	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
515	77	2	5	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
516	77	8	21	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
517	77	7	17	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
518	77	10	30	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
614	99	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
724	114	8	21	\N	high	\N	2025-06-26 06:21:59.494506	2025-06-27 10:51:52.76314
725	114	7	17	\N	high	\N	2025-06-26 06:21:59.494506	2025-06-27 10:51:52.76314
726	114	9	25	\N	high	\N	2025-06-26 06:21:59.494506	2025-06-27 10:51:52.76314
727	114	33	121	Assimilation test	high	\N	2025-06-26 06:21:59.494506	2025-06-27 10:51:52.76314
3382	684	8	21	Источник: Margesin et al. (2018). [4]	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3383	684	9	26	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3384	684	10	30	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3385	684	11	34	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3386	684	12	37	Положителен на щелочную и кислую фосфатазу.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3387	684	13	41	Положителен на эстеразу липазу (C8).	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3388	684	19	66	Определено по гидролизу обезжиренного молока (протеаза).	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3389	684	25	90	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3390	684	27	98	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
61	10	18	61	Inferred from the note: 'положительны на гидролиз желатина'	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
62	10	13	41	Inferred from the note: 'положительны на ... эстеразу (С4), эстеразу липазу (C8)'	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
63	11	2	6	From 'Скользящая подвижность'	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
64	11	7	17	\N	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
65	11	18	61	\N	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
66	11	19	65	\N	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
67	11	10	29	\N	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
68	12	10	29	\N	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
47	5	32	117	Assimilation of D-Mannose	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
679	107	8	21	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
680	107	7	18	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
681	107	10	29	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
682	107	17	57	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
683	107	13	43	Weak reaction (w) for C4 and C8	low	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
685	108	2	6	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
686	108	8	21	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
687	108	7	17	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
688	108	9	25	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
3391	684	30	110	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
668	106	8	21	Извлечено из OCR.	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
140	24	27	97	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
164	28	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
165	28	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
166	28	41	154	Acid production from sucrose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
167	28	29	106	Acid production from lactose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
170	29	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
171	29	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
172	29	41	154	Acid production from sucrose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
173	29	29	106	Acid production from lactose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
176	30	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
593	96	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
594	96	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
106	19	7	17	\N	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
595	96	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
596	96	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
599	97	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
600	97	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
601	97	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
602	97	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
605	98	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
606	98	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
1016	158	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1017	158	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1018	158	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1021	159	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1022	159	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1023	159	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
3392	684	31	114	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3393	684	33	123	Результат 'w'.	low	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3394	684	36	133	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3395	684	38	141	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3396	684	28	101	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3397	685	2	5	Скользящая подвижность. [1]	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3398	685	5	269	Проверено при 2-3% NaCl.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3399	685	7	17	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3400	685	8	21	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3401	685	9	26	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3402	685	10	30	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3403	685	11	34	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3404	685	12	37	Положителен на щелочную и кислую фосфатазу.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3405	685	13	41	Положителен на эстеразу липазу (C8).	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3406	685	19	65	Определено по гидролизу обезжиренного молока (протеаза).	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
117	20	2	5	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
118	20	7	17	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
119	20	8	21	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
120	20	10	29	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
121	20	17	57	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
122	20	9	26	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
123	20	11	34	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
124	20	27	98	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
125	21	7	17	Value is cited from another source.	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
126	21	10	29	Value is cited from another source.	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
127	21	17	58	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
129	21	29	107	Result is weak (w).	low	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
141	24	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
142	24	41	154	Acid production from sucrose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
143	24	29	105	Acid production from lactose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
146	25	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
147	25	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
148	25	41	154	Acid production from sucrose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
149	25	29	106	Acid production from lactose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
152	26	27	97	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
177	30	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
607	98	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
608	98	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
611	99	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
612	99	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
613	99	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
128	21	16	54	Value is cited from another source.	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
130	21	28	101	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
131	21	32	117	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
132	22	8	21	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
240	40	9	26	\N	high	\N	2025-06-26 02:45:09.04858	2025-06-27 10:51:52.367638
631	102	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
632	102	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
635	103	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
636	103	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
637	103	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
638	103	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
689	108	19	65	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
690	108	18	61	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
1024	159	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1027	160	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
3407	685	25	90	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3408	685	27	98	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3409	685	30	111	Результат 'w'.	low	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3410	685	31	114	Из примечания в таблице.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3411	685	33	122	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3412	685	36	133	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3413	685	38	142	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3414	685	28	101	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
3624	700	2	6	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3625	700	5	268	Рост при 0-2.0% NaCl. [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3626	700	7	17	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3627	700	8	21	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3628	700	9	25	Извлечено из OCR.	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
188	32	27	97	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
189	32	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
190	32	41	154	Acid production from sucrose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
191	32	29	106	Acid production from lactose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
194	33	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
212	36	27	97	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
213	36	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
214	36	41	154	Acid production from sucrose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
215	36	29	105	Acid production from lactose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
218	37	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
219	37	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
220	37	41	154	Acid production from sucrose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
221	37	29	106	Acid production from lactose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
224	38	27	99	From 'ОФ-тест (Ферментативный)', result was 'weak'	low	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
225	38	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
227	38	29	106	Acid production from lactose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
230	39	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
231	39	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
232	39	41	154	Acid production from sucrose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
233	39	29	106	Acid production from lactose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
617	100	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
618	100	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
619	100	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
620	100	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
623	101	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
624	101	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
625	101	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
626	101	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
629	102	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
3629	700	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3630	700	11	34	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
226	38	41	154	Acid production from sucrose	high	\N	2025-06-26 02:40:27.452518	2025-06-27 10:51:52.314742
630	102	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
3631	700	12	37	Положителен на кислую фосфатазу (из OCR).	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3632	700	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8) (из OCR).	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3633	700	16	54	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3634	700	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3635	700	18	61	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3636	700	19	65	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3637	700	20	69	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
137	23	13	41	Esterase (C4)	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
153	26	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
154	26	41	154	Acid production from sucrose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
258	41	2	6	\N	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
259	41	9	26	From 'Гидролиз мочевины'	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
641	104	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
642	104	40	150	Acid production from cellobiose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
643	104	41	154	Acid production from sucrose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
644	104	29	106	Acid production from lactose	high	\N	2025-06-26 03:04:32.422276	2025-06-27 10:51:52.534672
693	112	2	5	From 'Скользящая подвижность'	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
694	112	8	21	\N	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
695	112	7	17	\N	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
696	112	10	30	\N	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
697	112	9	26	\N	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
698	112	17	57	\N	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
699	112	23	81	\N	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
716	112	33	121	Assimilation test	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
717	112	40	149	Assimilation test	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
718	112	30	109	Assimilation test	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
719	112	38	141	Assimilation test	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
3415	686	1	2	Источник: BacDive. [3]	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
3416	686	2	6	Источник: BacDive. [3]	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
3417	686	7	17	Источник: Bai et al. (2020). [1, 2]	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
3418	686	8	21	Источник: Bai et al. (2020). [1, 2]	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
3419	686	12	37	Положителен на кислую фосфатазу (из OCR).	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
3420	686	18	61	Гидролиз желатина (из OCR).	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
3638	700	21	73	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3639	700	25	90	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3640	700	28	101	Ассимиляция мальтозы (из OCR).	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3641	700	32	118	Ассимиляция D-маннозы (из OCR).	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3642	700	35	130	Ассимиляция D-маннита (из OCR).	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3643	700	36	134	Ассимиляция D-глюкозы (из OCR).	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
3754	708	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3755	708	9	26	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3756	708	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3757	708	11	34	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3758	708	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
103	18	27	97	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
104	18	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
105	19	2	5	From 'Скользящая подвижность'	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
107	19	17	57	\N	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
108	19	10	29	\N	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
109	19	9	26	\N	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
110	19	40	150	Assimilation test	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
111	19	28	101	Assimilation test	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
112	19	35	129	Assimilation test	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
113	19	32	117	Assimilation test	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
114	19	31	113	Assimilation test	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
115	19	41	153	Assimilation test	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
116	19	33	121	Assimilation test	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
133	22	7	17	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
134	22	23	81	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
135	22	17	57	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
264	41	18	61	Inferred from the note: 'положительны на гидролиз желатина'	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
265	41	13	41	Inferred from the note: 'положительны на ... эстеразу (С4), эстеразу липазу (C8)'	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
266	41	12	37	Inferred from the note: 'положительны на ... щелочную фосфатазу, кислую фосфатазу'	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
269	43	2	5	Gliding motility (G) observed on page 8.	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
700	112	16	55	Conflicting data: Positive on pages 12, 21, 22 but negative (cited) on page 26.	low	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
701	112	21	73	\N	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
710	112	13	41	Positive for Esterase (C4)	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
711	112	12	37	Positive for acid phosphatase	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
715	112	28	101	Assimilation test	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
720	112	29	105	Assimilation test	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
136	22	16	53	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
3759	708	19	65	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3760	708	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3421	687	1	2	Источник: Fukuda et al. (2013). [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3422	687	5	268	Растет при 0.0-0.5% NaCl. [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3423	687	6	13	Источник: Fukuda et al. (2013). [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3424	687	7	18	Источник: BacDive. [7]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3425	687	8	21	Источник: BacDive. [7]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3426	687	9	26	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3427	687	10	30	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3428	687	12	37	Положителен на кислую фосфатазу (из OCR).	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3429	687	13	41	Источник: Fukuda et al. (2013). [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
155	26	29	106	Acid production from lactose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
158	27	27	97	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
159	27	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
160	27	41	154	Acid production from sucrose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
161	27	29	106	Acid production from lactose	high	\N	2025-06-26 02:08:58.160833	2025-06-27 10:51:52.1528
178	30	41	154	Acid production from sucrose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
179	30	29	106	Acid production from lactose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
182	31	27	99	From 'ОФ-тест (Ферментативный)', result was 'weak'	low	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
183	31	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
184	31	41	154	Acid production from sucrose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
185	31	29	106	Acid production from lactose	high	\N	2025-06-26 02:17:20.062616	2025-06-27 10:51:52.207024
195	33	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
196	33	41	154	Acid production from sucrose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
197	33	29	105	Acid production from lactose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
200	34	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
201	34	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
202	34	41	154	Acid production from sucrose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
203	34	29	105	Acid production from lactose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
206	35	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
207	35	40	149	Acid production from cellobiose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
208	35	41	154	Acid production from sucrose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
209	35	29	106	Acid production from lactose	high	\N	2025-06-26 02:23:11.891632	2025-06-27 10:51:52.261307
267	41	11	34	Inferred from the note: 'отрицательны на ... продукцию индола'	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
268	41	27	98	Inferred from the note: 'отрицательны на ... ферментацию глюкозы'	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
270	43	8	21	\N	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
271	43	7	17	\N	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
272	43	10	29	Data from page 8. Pages 5 and 27 show negative.	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
273	43	11	34	\N	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
274	43	17	58	\N	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
275	43	18	61	\N	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
276	43	19	65	\N	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
277	43	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
281	43	12	37	Positive for acid and BI-phosphohydrolase	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
285	43	31	114	Assimilation test	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
286	43	32	118	Assimilation test	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
287	43	35	130	Assimilation test	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
3430	687	16	53	Продукция амилазы. [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3431	687	17	57	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3432	687	28	101	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3433	687	29	106	Источник: BacDive. [7]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3434	687	30	110	Источник: BacDive. [7]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3435	687	31	113	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3436	687	32	118	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3437	687	33	122	Источник: BacDive. [7]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3438	687	34	125	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3439	687	35	130	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3440	687	36	133	Ассимиляция D-глюкозы (из OCR).	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3441	687	37	138	Источник: BacDive. [7]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3442	687	38	142	Источник: BacDive. [7]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3443	687	41	153	Извлечено из OCR.	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
3644	701	2	5	Скользящая подвижность. [1, 2]	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3645	701	5	268	Рост при 0-1% NaCl. [1, 2]	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3646	701	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3647	701	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3648	701	9	26	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3649	701	10	30	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3650	701	11	34	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3651	701	12	37	Положителен на щелочную и кислую фосфатазу (из OCR).	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3652	701	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8) (из OCR).	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3653	701	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
69	12	9	25	\N	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
70	12	31	113	Acid production from L-Арабинозы. Value is cited.	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
519	77	9	25	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
520	77	17	57	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
521	77	25	89	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
523	79	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
524	79	40	150	Acid production from cellobiose	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
526	80	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
527	80	40	150	Acid production from cellobiose	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
3444	688	8	21	Извлечено из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3445	688	17	57	Извлечено из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3446	688	20	69	Извлечено из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
528	81	2	5	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
3447	688	21	73	Извлечено из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3448	688	19	65	Извлечено из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
529	81	10	29	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
3449	688	10	30	Извлечено из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3450	688	25	90	Извлечено из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3451	688	36	133	Ассимиляция D-глюкозы (из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3452	688	32	117	Ассимиляция D-маннозы (из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3453	688	28	101	Ассимиляция D-мальтозы (из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3454	689	2	5	Скользящая подвижность (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3455	689	7	17	Извлечено из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3456	689	10	29	Восстановление нитратов (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3457	689	19	65	Все штаммы были положительны на гидролиз казеина (примечание к таблице 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3458	689	23	81	Гидролиз хитина (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3459	689	18	61	Гидролиз желатина (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3460	689	17	57	Гидролиз эскулина (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
530	81	17	57	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
3461	689	31	114	Утилизация L-Арабинозы (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3462	689	36	133	Утилизация D-Глюкозы (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
531	82	7	17	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
532	82	10	30	Value is cited.	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
533	82	17	57	Value is cited.	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
534	82	16	53	Value is cited.	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
535	83	9	25	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
536	83	17	57	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
537	83	13	41	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
539	84	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
540	84	40	150	Acid production from cellobiose	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
646	105	2	5	Gliding motility observed.	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
647	105	7	17	\N	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
648	105	10	29	\N	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
649	105	9	25	\N	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
650	105	25	89	\N	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
651	105	6	13	From 'Ассимиляция Протеаза'	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
655	105	16	53	\N	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
656	105	23	81	\N	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
657	105	24	85	From 'Гидролиз КМ-целлюлоза'	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
659	105	26	94	\N	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
665	105	35	130	Assimilation test	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
721	112	32	117	Assimilation test	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
728	114	12	37	Positive for alkaline phosphatase	high	\N	2025-06-26 06:21:59.494506	2025-06-27 10:51:52.76314
3654	701	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3655	701	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
760	120	8	21	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
794	124	41	153	Assimilation test	high	\N	2025-06-26 06:30:03.856434	2025-06-27 10:51:52.92726
795	124	33	121	Assimilation test	high	\N	2025-06-26 06:30:03.856434	2025-06-27 10:51:52.92726
796	127	8	23	Conflicting data: Positive on page 79, negative on page 66.	low	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
797	127	7	17	\N	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
798	127	10	30	\N	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
799	127	9	26	\N	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
800	127	17	57	\N	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
801	127	19	65	\N	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
802	127	18	61	\N	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
803	127	16	53	\N	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
806	127	25	90	\N	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
810	127	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
3463	689	32	118	Утилизация D-Маннозы (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3464	689	35	130	Утилизация D-Маннитола (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3465	689	28	102	Утилизация D-Мальтозы (из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T').	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3466	690	2	5	Скольжение.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3467	690	20	69	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3468	690	16	53	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3469	690	24	86	Гидролиз КМЦ.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3470	690	13	41	Липаза (C14) - отрицательно.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3471	690	31	114	Ассимиляция L-арабинозы.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3472	690	28	102	Ассимиляция D-мальтозы.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3473	691	2	5	Скользящая подвижность.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3474	691	5	268	Толерантность к NaCl до 2%.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3475	691	8	22	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3476	691	7	18	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3477	691	17	57	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3478	691	20	69	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3479	691	21	73	Извлечено из Твин 80.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3480	691	22	77	Извлечено из Твин 80.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3481	691	16	54	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3482	691	24	86	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3483	691	19	65	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
3484	691	12	37	Нафтол-AS-BI-фосфогидролаза.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
729	114	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 06:21:59.494506	2025-06-27 10:51:52.76314
741	115	19	65	\N	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
742	115	18	61	\N	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
743	115	20	69	\N	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
744	115	21	73	\N	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
745	115	22	77	\N	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
749	115	40	150	Assimilation test	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
750	115	30	110	Assimilation test	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
751	115	29	106	Assimilation test	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
755	115	37	138	Assimilation test	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
757	115	41	154	Assimilation test	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
758	115	33	121	Assimilation test	high	\N	2025-06-26 06:24:48.508178	2025-06-27 10:51:52.817563
759	120	2	5	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
761	120	7	17	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
762	120	10	29	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
763	120	9	26	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
764	120	17	59	Conflicting data: Positive on pages 6, 20 but negative on page 27.	low	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
765	120	18	61	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
766	120	19	65	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
767	120	16	54	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
769	120	11	34	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
770	120	27	98	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
771	120	25	90	\N	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
773	120	13	41	Positive for Esterase (C4)	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
777	120	12	37	Positive for acid phosphatase	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
779	120	31	114	Assimilation test	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
780	120	32	118	Assimilation test	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
781	120	35	130	Assimilation test	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
783	120	28	101	Assimilation test	high	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
787	124	17	57	Value is cited.	high	\N	2025-06-26 06:30:03.856434	2025-06-27 10:51:52.92726
789	124	40	149	Assimilation test	high	\N	2025-06-26 06:30:03.856434	2025-06-27 10:51:52.92726
790	124	30	109	Assimilation test	high	\N	2025-06-26 06:30:03.856434	2025-06-27 10:51:52.92726
792	124	32	117	Assimilation test	high	\N	2025-06-26 06:30:03.856434	2025-06-27 10:51:52.92726
793	124	28	101	Assimilation test	high	\N	2025-06-26 06:30:03.856434	2025-06-27 10:51:52.92726
3656	701	19	65	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3485	692	2	6	Источник: Choi et al. (2014). [2, 4]	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3486	692	5	268	Растет в присутствии 0-1% NaCl (из OCR).	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3487	692	7	17	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3488	692	8	21	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3489	692	9	25	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3490	692	10	30	В OCR есть противоречивые данные (+/-). Choi et al. (2014) указывает на отрицательный результат. [1]	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3491	692	12	37	Положителен на щелочную и кислую фосфатазу (из примечания в OCR).	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3492	692	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8) (из OCR).	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
814	127	12	37	Positive for acid and Naphthol-AS-BI-phosphohydrolase	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
819	127	28	101	Assimilation test	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
821	127	40	149	Assimilation test	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
822	127	30	109	Assimilation test	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
824	127	35	129	Assimilation test	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
825	127	34	125	Assimilation test	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
826	127	31	113	Assimilation test	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
827	127	41	153	Assimilation test	high	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
828	128	2	5	Gliding motility observed.	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
829	128	8	21	Confirmed by BacDive. Some tables in the PDF showed a negative result.	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
830	128	7	17	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
831	128	10	29	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
832	128	9	26	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
833	128	11	34	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
834	128	27	98	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
835	128	17	57	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
836	128	18	61	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
837	128	19	65	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
838	128	16	53	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
841	128	25	90	\N	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
845	128	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
848	128	12	37	Positive for acid and alkaline phosphatase	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
853	128	28	101	Assimilation test	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
854	128	32	117	Assimilation test	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
857	132	2	5	Gliding motility observed.	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
858	132	8	21	\N	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
859	132	7	17	\N	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
860	132	10	29	Confirmed by BacDive, resolving conflicting data in the PDF.	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
861	132	9	26	Confirmed by BacDive, resolving conflicting data in the PDF.	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
862	132	11	34	\N	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
863	132	17	57	Confirmed by BacDive, resolving conflicting data in the PDF.	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
864	132	18	61	\N	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
865	132	19	65	\N	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
866	132	16	54	Confirmed by BacDive.	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
869	132	25	90	\N	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
876	132	32	117	Assimilation test, confirmed by BacDive.	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
877	132	28	101	Assimilation test, confirmed by BacDive.	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
880	134	2	5	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
881	134	8	21	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
882	134	7	17	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
883	134	10	29	Confirmed by BacDive. PDF table on page 26 shows a negative result.	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
884	134	17	58	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
3493	692	16	53	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3494	692	17	57	Гидролиз эскулина (из OCR).	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3495	692	18	61	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3496	692	19	65	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3497	692	23	82	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3498	692	25	90	В OCR есть противоречивые данные (+/-). Choi et al. (2014) указывает на отрицательный результат.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3499	692	28	101	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3500	692	29	106	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3501	692	30	109	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3502	692	31	113	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3503	692	32	119	Результат 'w' (слабоположительный) из OCR.	low	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3504	692	33	121	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3505	692	35	130	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3506	692	36	133	Ассимиляция D-глюкозы (из OCR).	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3507	692	37	137	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3508	692	38	141	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3509	692	40	149	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3510	692	41	153	Извлечено из OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
3657	701	23	81	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3658	701	24	85	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3659	701	25	90	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3660	701	27	98	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3661	701	28	101	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3511	693	2	5	Скользящая подвижность. [4]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3512	693	5	268	Рост при 0-1.0% NaCl. [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3513	693	7	17	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3514	693	8	21	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3515	693	9	26	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3516	693	10	30	Извлечено из OCR.	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3517	693	11	34	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3518	693	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3519	693	16	53	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3520	693	17	57	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3521	693	18	61	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3522	693	19	65	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3523	693	25	90	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3524	693	36	133	Ассимиляция D-глюкозы. [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
885	134	16	54	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
886	134	21	73	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
889	134	30	109	Assimilation test	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
890	134	38	141	Assimilation test	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
892	134	28	101	Assimilation test	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
893	134	32	117	Assimilation test	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
894	134	34	125	Assimilation test	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
895	134	33	121	Assimilation test	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
896	138	8	21	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
897	138	7	17	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
898	138	9	26	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
899	138	33	121	Assimilation test	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
900	138	12	39	Weakly positive for alkaline phosphatase	low	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
901	138	13	43	Weakly positive for Esterase (C4)	low	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
906	139	2	5	Gliding motility observed.	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
907	139	8	21	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
908	139	7	17	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
909	139	10	29	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
910	139	9	26	Confirmed by BacDive, resolving conflicting data in the PDF.	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
911	139	11	34	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
912	139	27	98	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
913	139	17	57	Confirmed by BacDive, resolving conflicting data in the PDF.	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
914	139	18	61	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
915	139	19	65	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
916	139	16	53	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
917	139	23	81	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
918	139	20	69	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
921	139	25	90	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
925	139	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
929	139	12	37	Positive for acid and alkaline phosphatase	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
934	139	28	101	Assimilation test	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
937	140	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
938	140	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
939	140	41	154	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
940	140	29	106	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
943	141	27	99	From 'ОФ-тест (Ферментативный)', result was 'slow'	low	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
944	141	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
945	141	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
946	141	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
949	142	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
950	142	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
951	142	41	155	Acid production from sucrose. Result was 'weak'.	low	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
952	142	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
954	148	8	21	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
955	148	10	30	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
956	148	17	57	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
957	148	19	65	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
958	148	20	69	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
3525	693	28	101	Ассимиляция D-мальтозы. [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3526	179	2	5	Скользящая подвижность. [13]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3527	179	5	268	Рост при 0-1.0% NaCl. [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3528	179	7	17	Извлечено из OCR.	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3529	179	8	21	Извлечено из OCR.	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3530	179	9	26	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3531	179	10	30	Извлечено из OCR.	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3532	179	11	34	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3533	179	16	53	Извлечено из OCR.	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3534	179	17	57	Извлечено из OCR.	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3535	179	18	61	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3536	179	19	65	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3537	179	20	69	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3538	179	21	73	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
962	148	25	90	\N	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
969	148	32	117	Assimilation test	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
971	148	28	101	Assimilation test	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
973	151	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
974	151	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
975	151	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
976	151	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
979	152	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
980	152	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
981	152	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
982	152	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
985	153	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
986	153	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
987	153	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
988	153	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
991	154	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
992	154	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
993	154	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
994	154	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
997	155	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
998	155	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
999	155	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1000	155	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
3539	179	22	77	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3540	179	36	133	Ассимиляция D-глюкозы. [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
3541	179	28	101	Ассимиляция D-мальтозы. [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
1003	156	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1004	156	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
3662	701	30	109	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3663	701	31	113	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3664	701	32	117	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3665	701	33	121	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1005	156	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1006	156	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
3666	701	35	129	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1009	157	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1010	157	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1011	157	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1012	157	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1015	158	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
3667	701	36	133	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3668	701	41	153	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
3761	708	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3762	708	23	82	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3763	708	36	133	Ассимиляция D-глюкозы. [7, 8]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3764	708	31	114	Ассимиляция L-арабинозы. [7, 8]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3765	708	32	118	Ассимиляция D-маннозы. [7, 8]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3766	709	2	5	Скользящая подвижность. [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3767	709	5	268	Рост при 0-2% NaCl. [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3768	709	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3769	709	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3770	709	9	26	Источник: Park et al. (2008). [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3771	709	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3772	709	18	61	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3773	709	19	65	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3774	709	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3775	709	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3776	709	20	69	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3777	709	23	81	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3778	709	36	133	Ассимиляция D-глюкозы. [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3779	709	31	113	Ассимиляция L-арабинозы. [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3780	709	32	117	Ассимиляция D-маннозы. [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3781	709	28	101	Ассимиляция мальтозы. [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3791	710	17	57	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3792	710	18	61	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3793	710	19	65	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3794	710	20	69	Извлечено из OCR.	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3795	710	23	81	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3796	710	36	133	Ассимиляция D-глюкозы. [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3542	695	2	6	В первоисточнике указано 'non-gliding'. [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3543	695	5	268	Рост при 0-6.0% NaCl. [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3544	695	7	17	Извлечено из OCR.	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3545	695	8	21	Извлечено из OCR.	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3546	695	10	29	Извлечено из OCR.	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3547	695	20	69	Извлечено из OCR.	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3548	695	36	133	Ассимиляция D-глюкозы (из OCR).	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3549	695	31	114	Ассимиляция L-арабинозы (из OCR).	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3550	695	32	117	Ассимиляция D-маннозы (из OCR).	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3551	695	28	101	Ассимиляция мальтозы (из OCR).	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
3688	703	2	5	Скользящая подвижность. [5]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3689	703	5	268	Рост при 0-1.0% NaCl. [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3690	703	7	17	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3691	703	8	21	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3692	703	9	26	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3693	703	10	30	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3694	703	11	34	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3695	703	16	53	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3696	703	17	57	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3697	703	18	61	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3698	703	19	65	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1028	160	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1029	160	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1030	160	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1033	161	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1034	161	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1035	161	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1036	161	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1039	162	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1040	162	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1041	162	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1042	162	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1045	163	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1046	163	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1047	163	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1048	163	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1051	164	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1052	164	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1053	164	41	153	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1054	164	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1057	167	27	98	From 'ОФ-тест (Ферментативный)'	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1058	167	40	149	Acid production from cellobiose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1059	167	41	154	Acid production from sucrose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1060	167	29	105	Acid production from lactose	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
1062	145	2	5	Gliding motility observed (from BacDive).	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1063	145	8	21	From BacDive.	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1064	145	7	17	From BacDive.	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1065	145	10	29	From BacDive.	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1066	145	9	26	From BacDive.	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1067	145	19	65	From BacDive.	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1068	145	18	61	From BacDive.	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1069	145	16	53	From BacDive.	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1072	145	27	98	From 'ОФ-тест (Ферментативный)' (from PDF).	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1073	145	40	149	Acid production from cellobiose (from PDF).	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1074	145	41	154	Acid production from sucrose (from PDF).	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1075	145	29	105	Acid production from lactose (from PDF).	high	\N	2025-06-26 07:15:30.110978	2025-06-27 10:51:53.270357
1077	170	40	149	Carbon source utilization.	high	\N	2025-06-26 07:17:39.437709	2025-06-27 10:51:53.323451
1078	170	30	109	Carbon source utilization.	high	\N	2025-06-26 07:17:39.437709	2025-06-27 10:51:53.323451
1080	170	28	101	Carbon source utilization.	high	\N	2025-06-26 07:17:39.437709	2025-06-27 10:51:53.323451
1089	171	10	30	From BacDive.	high	\N	2025-06-26 07:22:26.618307	2025-06-27 10:51:53.374602
1090	171	9	26	From BacDive.	high	\N	2025-06-26 07:22:26.618307	2025-06-27 10:51:53.374602
3699	703	20	69	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3700	703	21	73	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3552	696	2	5	Скользящая подвижность. В одной из таблиц OCR указано 'Неподвижный', но первоисточник подтверждает подвижность. [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3553	696	5	268	Рост при 0-0.5% NaCl. [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3554	696	7	18	В OCR указано '+', но первоисточник и BacDive указывают '-'. [1, 2, 3]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3555	696	8	21	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3556	696	9	26	В OCR указано '+', но первоисточник указывает '-'. [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3557	696	12	37	Положителен на щелочную и кислую фосфатазу. [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3558	696	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3559	696	16	54	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3560	696	17	57	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3561	696	18	61	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3562	696	19	65	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3563	696	20	69	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
1118	173	2	5	Gliding motility observed.	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1119	173	8	21	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1120	173	7	17	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1121	173	10	29	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1122	173	9	26	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1123	173	17	57	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1124	173	18	61	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1125	173	19	65	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1126	173	16	53	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1129	173	25	90	\N	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1131	173	27	97	From 'Подкисление глюкозы'	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1133	173	28	101	Assimilation test	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1135	173	31	113	Assimilation test	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
1137	176	2	5	Gliding motility observed.	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1138	176	8	21	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1139	176	7	17	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1140	176	10	30	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1141	176	9	26	Confirmed by BacDive, resolving conflicting data in the PDF.	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1142	176	11	34	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1143	176	27	98	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1144	176	17	57	Confirmed by BacDive, resolving conflicting data in the PDF.	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1145	176	18	61	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1146	176	19	65	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1147	176	16	53	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1150	176	25	90	\N	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1154	176	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1157	176	12	37	Positive for acid and alkaline phosphatase	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1162	176	28	101	Assimilation test	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1164	176	41	155	Acid production from sucrose. Result was 'weak'.	low	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1165	176	29	105	Acid production from lactose.	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
1167	186	2	5	From BacDive.	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1168	186	8	21	\N	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1169	186	7	17	\N	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1170	186	10	30	\N	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1171	186	9	25	\N	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1172	186	17	57	\N	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1173	186	18	61	\N	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1174	186	19	65	\N	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1175	186	16	53	\N	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1176	186	13	41	Positive for Esterase (C4) and Esterase Lipase (C8).	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
3564	696	21	73	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3565	696	22	77	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3566	696	25	90	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3567	696	28	101	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3568	696	29	106	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3569	696	30	109	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3570	696	31	113	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3571	696	32	117	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3572	696	33	121	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3573	696	35	130	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3574	696	36	133	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3575	696	37	137	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3576	696	38	141	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3577	696	41	153	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
3701	703	22	77	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3702	703	36	133	Ассимиляция D-глюкозы. [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1180	186	12	37	Positive for acid and Naphthol-AS-BI-phosphohydrolase	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1188	186	28	101	Assimilation test	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1189	186	32	117	Assimilation test	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1190	186	35	129	Assimilation test	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
1193	187	2	5	Gliding motility observed.	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1194	187	8	21	\N	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1195	187	7	17	\N	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1196	187	10	29	\N	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1197	187	9	26	From BacDive.	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1198	187	17	57	\N	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1199	187	18	61	From BacDive.	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1200	187	19	65	From BacDive.	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1201	187	16	53	From BacDive.	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1211	187	31	113	Assimilation test	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
1213	191	2	5	Gliding motility observed.	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1214	191	8	21	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1215	191	7	17	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1216	191	10	30	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1217	191	9	25	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1218	191	17	57	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1219	191	18	61	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1220	191	19	65	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1221	191	16	53	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1224	191	25	90	\N	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1229	191	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1233	191	12	37	Positive for acid and alkaline phosphatase	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1238	191	28	101	Assimilation test	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1239	191	32	117	Assimilation test	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
1241	194	2	5	Gliding motility observed.	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1242	194	8	21	\N	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1243	194	7	17	\N	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1244	194	10	31	Result was weak (w).	low	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1245	194	9	26	\N	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1246	194	17	57	\N	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1247	194	18	61	\N	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1248	194	19	65	\N	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1249	194	16	54	\N	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
3578	697	5	268	Рост при 0-1.5% NaCl (из OCR).	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3579	697	7	17	Источник: Fang et al. (2020). [8]	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3580	697	8	21	Источник: Fang et al. (2020). [8]	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3581	697	9	26	Источник: Fang et al. (2020). [8]	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3582	697	10	29	Извлечено из OCR.	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3583	697	13	41	Положителен на эстеразу липазу (C8) (из OCR).	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3584	697	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3585	697	21	73	Извлечено из OCR.	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3586	697	22	77	Извлечено из OCR.	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3587	697	31	114	Ассимиляция D-Арабинозы (из OCR).	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3588	697	33	121	Ассимиляция D-Трегалозы (из OCR).	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3589	697	34	126	Ассимиляция D-Сорбита (из OCR).	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3590	697	36	133	Ассимиляция D-глюкозы (из OCR).	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3591	697	37	137	Ассимиляция D-Ксилозы (из OCR).	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3592	697	40	149	Ассимиляция D-Целлобиозы (из OCR).	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
3703	703	28	101	Ассимиляция D-мальтозы. [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3704	704	2	5	Скользящая подвижность. [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3705	704	5	268	Рост при 0-2% NaCl. [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3706	704	7	17	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3707	704	8	21	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3708	704	9	26	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3709	704	10	30	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3710	704	11	34	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3711	704	16	54	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3712	704	17	57	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3713	704	18	61	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3714	704	19	65	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3715	704	36	133	Ассимиляция D-глюкозы. [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3716	704	28	101	Ассимиляция D-мальтозы. [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
3782	710	2	5	Скользящая подвижность. [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3783	710	5	268	Рост при 0-7.0% NaCl. [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3784	710	7	17	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3785	710	8	21	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3786	710	9	26	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3787	710	10	30	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3788	710	11	34	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3789	710	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3790	710	16	54	Извлечено из OCR.	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3593	698	2	5	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3594	698	5	269	Рост отсутствует при 1% NaCl (из OCR).	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3595	698	7	19	Результат 'w/+' (слабоположительный/положительный) из OCR.	low	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3596	698	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3597	698	13	41	Положителен на эстеразу (C4). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3598	698	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3599	698	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3600	698	36	133	Ассимиляция D-глюкозы (из OCR).	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
1254	194	12	37	Positive for acid and alkaline phosphatase.	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1259	194	28	101	Assimilation test	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1260	194	32	118	Assimilation test	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
1262	195	2	5	From BacDive.	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1263	195	8	21	From BacDive.	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1264	195	7	17	From BacDive.	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1265	195	9	26	\N	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1266	195	17	57	\N	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1267	195	18	61	\N	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1268	195	19	65	From BacDive.	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1269	195	16	53	From BacDive.	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1270	195	25	90	\N	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1271	195	13	41	Positive for Esterase Lipase (C8).	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1279	195	35	130	Assimilation test	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
1281	196	2	5	From BacDive.	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1282	196	8	21	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1283	196	7	17	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1284	196	10	29	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1285	196	9	25	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1286	196	17	57	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1287	196	18	61	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1288	196	19	65	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1289	196	20	69	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1292	196	25	89	\N	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1293	196	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1296	196	12	37	Positive for acid and Naphthol-AS-BI-phosphohydrolase	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1302	196	32	117	Assimilation test	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
1306	199	17	58	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1308	199	40	149	Assimilation test	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1309	199	30	109	Assimilation test	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1311	199	32	117	Assimilation test	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1312	199	28	101	Assimilation test	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1313	199	41	153	Assimilation test	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1314	199	33	121	Assimilation test	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1315	200	2	5	Motile (M) from page 42.	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1316	200	7	17	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1317	200	10	29	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1318	200	16	54	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1321	200	26	93	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1322	203	2	5	Gliding motility observed.	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1323	203	8	21	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1324	203	7	17	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1325	203	10	30	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1326	203	17	57	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1327	203	16	53	\N	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
3601	698	28	101	Извлечено из OCR.	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3602	698	32	118	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3603	698	31	114	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3604	698	41	154	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
3717	705	2	5	Скользящая подвижность. [1, 2]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3718	705	5	268	Рост при 0-2% NaCl. [1, 2]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3719	705	7	17	Источник: Bae et al. (2005). [1, 2]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3720	705	8	21	Источник: Bae et al. (2005). [1, 2]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3721	705	9	25	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3722	705	10	29	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3723	705	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3724	705	19	65	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3725	705	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3726	705	16	54	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1086	171	2	5	Скользящая подвижность. [3, 4]	high	\N	2025-06-26 07:22:26.618307	2025-06-28 08:22:56.033373
3728	171	5	268	Рост при 0-0.5% NaCl. [3, 4]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1088	171	7	17	Источник: Yassin et al. (2008). [3, 4]	high	\N	2025-06-26 07:22:26.618307	2025-06-28 08:22:56.033373
1087	171	8	21	Источник: Yassin et al. (2008). [3, 4]	high	\N	2025-06-26 07:22:26.618307	2025-06-28 08:22:56.033373
1096	171	13	41	Положителен на эстеразу (C4). [3, 4]	high	\N	2025-06-26 07:22:26.618307	2025-06-28 08:22:56.033373
1091	171	18	61	Источник: Yassin et al. (2008). [3, 4]	high	\N	2025-06-26 07:22:26.618307	2025-06-28 08:22:56.033373
1092	171	19	65	Источник: Yassin et al. (2008). [3, 4]	high	\N	2025-06-26 07:22:26.618307	2025-06-28 08:22:56.033373
3734	171	17	57	Источник: Yassin et al. (2008). [3, 4]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1093	171	16	53	Источник: Yassin et al. (2008). [3, 4]	high	\N	2025-06-26 07:22:26.618307	2025-06-28 08:22:56.033373
667	106	2	5	Скользящая подвижность. [5, 6]	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
3737	106	5	268	Рост при 0-2% NaCl. [5, 6]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1334	203	32	117	Assimilation test	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1335	203	28	101	Assimilation test	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
1336	206	2	5	Gliding motility observed.	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1337	206	8	21	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1338	206	7	17	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1339	206	10	29	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1340	206	9	25	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1341	206	17	57	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1342	206	18	61	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1343	206	19	65	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1344	206	16	53	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1347	206	25	90	\N	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1352	206	13	41	Positive for Esterase (C4) and Esterase lipase (C8)	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1356	206	12	37	Positive for acid and alkaline phosphatase	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1361	206	28	101	Assimilation test	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1362	206	32	117	Assimilation test	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
1363	206	35	129	Assimilation test	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
3605	699	2	5	Скользящая подвижность. [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3606	699	5	268	Рост при 0-1% NaCl. [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3607	699	7	17	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3608	699	8	21	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3609	699	9	25	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3610	699	10	29	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3611	699	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3612	699	16	54	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3613	699	17	57	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3614	699	18	61	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3615	699	19	65	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3616	699	23	81	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3617	699	25	89	Извлечено из OCR.	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3618	699	36	133	Ассимиляция D-глюкозы. [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3619	699	28	101	Извлечено из OCR.	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3620	699	32	117	Извлечено из OCR.	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3621	699	31	114	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3622	699	41	153	Извлечено из OCR.	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
3623	699	35	130	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
669	106	7	17	Источник: Jung et al. (2012). [5, 6]	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
670	106	9	27	Слабоположительный (+). [5, 6]	low	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
671	106	10	29	Источник: Jung et al. (2012). [5, 6]	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
3742	106	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [5, 6]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
674	106	18	61	Источник: Jung et al. (2012). [5, 6]	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
3744	106	19	65	Источник: Jung et al. (2012). [5, 6]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
673	106	17	57	Источник: Jung et al. (2012). [5, 6]	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
3746	106	16	53	Источник: Jung et al. (2012). [5, 6]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
672	106	25	89	Извлечено из OCR.	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
3748	106	36	133	Ассимиляция D-глюкозы. [5, 6]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
678	106	32	117	Ассимиляция маннозы. [5, 6]	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
677	106	28	101	Ассимиляция мальтозы. [5, 6]	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
3751	708	2	5	Скользящая подвижность. [7, 8]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3752	708	5	268	Рост при 0-2.0% NaCl. [7, 8]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3753	708	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
3797	710	28	101	Ассимиляция D-мальтозы. [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3798	711	2	6	В первоисточнике указано 'non-gliding'. [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3799	711	5	268	Рост при 0-6.0% NaCl. [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3800	711	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3801	711	8	21	Источник: Cai et al. (2021). [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3802	711	10	29	Извлечено из OCR.	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3803	711	13	43	Липаза (C14) - отрицательно, Валин ариламидаза - слабоположительно (w). [3, 4]	low	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3804	711	20	69	Извлечено из OCR.	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3805	711	16	54	Извлечено из OCR.	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3806	711	36	133	Ассимиляция D-глюкозы. [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3807	711	31	114	Ассимиляция L-арабинозы. [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3808	711	32	117	Ассимиляция D-маннозы. [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3809	711	28	101	Ассимиляция мальтозы. [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
3810	712	2	5	Скользящая подвижность. [1]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3811	712	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3812	712	8	21	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3813	712	10	29	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3814	712	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3815	712	19	65	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3816	712	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3817	712	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3818	712	23	82	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3819	712	24	85	Гидролиз КМЦ. [1]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3820	712	25	90	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3821	712	36	133	Ассимиляция D-глюкозы. [1]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3822	712	31	113	Ассимиляция L-арабинозы. [1]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3823	712	32	117	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3824	712	35	129	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3825	712	28	101	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3826	713	2	5	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3827	713	5	268	Рост при 0% NaCl. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3828	713	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3829	713	8	21	Источник: Liu et al. (2013). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3830	713	9	26	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3831	713	25	90	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3832	713	13	41	Положителен на липазу (C14). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3833	713	23	81	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3834	713	24	85	Гидролиз КМ-целлюлозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3835	713	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3836	713	36	133	Ассимиляция D-глюкозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3837	713	35	129	Ассимиляция D-маннитола. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3838	713	28	101	Продукция кислоты из D-мальтозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3839	713	29	105	Продукция кислоты из D-лактозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3840	713	33	121	Продукция кислоты из D-трегалозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3841	714	2	5	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3842	714	5	268	Рост при 0% NaCl. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3843	714	7	18	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3844	714	8	21	Источник: Liu et al. (2013). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3845	714	9	25	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3846	714	25	89	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3847	714	13	43	Слабоположителен на липазу (C14) и валин-ариламидазу. [3, 4]	low	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3848	714	23	81	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3849	714	24	85	Гидролиз КМ-целлюлозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3850	714	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3851	714	36	134	Ассимиляция D-глюкозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3852	714	35	130	Ассимиляция D-маннитола. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3853	714	28	102	Продукция кислоты из D-мальтозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3854	714	29	106	Продукция кислоты из D-лактозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3855	714	33	122	Продукция кислоты из D-трегалозы. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
733	115	2	5	Скользящая подвижность. [7, 8]	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
3857	115	5	268	Рост при 0-1% NaCl. [7, 8]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
735	115	7	18	Извлечено из OCR.	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
734	115	8	21	Извлечено из OCR.	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
737	115	9	26	Извлечено из OCR.	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
736	115	10	29	Извлечено из OCR.	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
738	115	17	57	Извлечено из OCR.	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
740	115	16	54	Извлечено из OCR.	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
3864	115	36	134	Ассимиляция D-глюкозы. [7, 8]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
748	115	31	113	Ассимиляция L-арабинозы. [7, 8]	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
754	115	32	117	Ассимиляция D-маннозы. [7, 8]	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
752	115	28	101	Ассимиляция D-мальтозы. [7, 8]	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
753	115	35	131	Слабоположительный (w). [7, 8]	low	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
3869	716	5	268	Рост при 0-0.5% NaCl. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3870	716	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3871	716	8	21	Источник: Liu et al. (2013). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3872	716	9	26	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3873	716	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3874	716	13	41	Положителен на липазу (C14). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3875	716	20	69	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3876	716	25	90	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3877	716	36	133	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3878	716	28	102	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
3879	717	5	268	Рост при 0-7.0% NaCl. [1, 2]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3880	717	20	69	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3881	717	7	19	Слабоположительный (w). [1, 2]	low	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3882	717	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3883	717	13	43	Липаза (C14) - слабоположительно (w), Валин-ариламидаза - слабоположительно (w), Трипсин - слабоположительно (w). [1, 2]	low	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3884	717	10	29	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3885	717	36	133	Ассимиляция d-глюкозы. [1, 2]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3886	717	31	114	Ассимиляция l-арабинозы. [1, 2]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3887	717	32	117	Ассимиляция d-маннозы. [1, 2]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3888	717	28	101	Ассимиляция мальтозы. [1, 2]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3889	718	5	268	Рост при 2% NaCl. [3]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3890	718	10	29	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3891	718	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3892	718	16	54	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3893	718	19	65	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3894	718	30	109	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3895	718	31	113	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3896	718	40	150	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3897	718	32	119	Слабоположительный (w). [3]	low	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3898	718	33	121	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3899	718	41	154	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3900	718	35	130	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3901	718	36	133	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3902	718	38	141	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3903	719	2	6	Неподвижный (N). [5]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3904	719	5	268	Рост при 0-2% NaCl. [5]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3905	719	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3906	719	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3907	719	10	31	Слабоположительный (w). [5]	low	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3908	719	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3909	719	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3910	719	25	90	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3911	719	36	133	Ассимиляция D-глюкозы. [5]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3912	719	31	114	Ассимиляция L-арабинозы. [5]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3913	719	32	117	Ассимиляция D-маннозы. [5]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3914	719	35	130	Ассимиляция D-маннитола. [5]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3915	719	28	101	Ассимиляция мальтозы. [5]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3916	720	5	268	Рост при 0-4% NaCl. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3917	720	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3918	720	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3919	720	9	26	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3920	720	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3921	720	11	34	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3922	720	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3923	720	23	81	Разложение коллоидного хитина. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3924	720	24	85	Разложение карбоксиметилцеллюлозы. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3925	721	5	268	Рост при 0-4% NaCl. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3926	721	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3927	721	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3928	721	9	26	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3929	721	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3930	721	11	34	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3931	721	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3932	721	23	81	Разложение коллоидного хитина. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3933	721	24	85	Разложение карбоксиметилцеллюлозы. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
3934	722	5	268	Рост при 0-1% NaCl. [1]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3935	722	13	43	Цистинол-ариламидаза (+), Трипсин (w), Химотрипсин (+).	low	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3936	722	21	75	Слабоположительный (w). [1]	low	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3937	722	36	133	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3938	722	38	141	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3939	723	2	5	Скользящая подвижность. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3940	723	5	268	Рост при 0-7.0% NaCl. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3941	723	7	17	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3942	723	8	21	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3943	723	9	26	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3944	723	10	30	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3945	723	11	34	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3946	723	13	41	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3947	723	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3948	723	36	133	Ассимиляция D-глюкозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3949	723	28	101	Ассимиляция D-мальтозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3950	723	33	121	Ассимиляция D-трегалозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3951	723	40	149	Ассимиляция D-целлобиозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3952	723	41	153	Ассимиляция сахарозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3953	724	13	43	pNP-Фенил-фосфонат (+), pNP-Фосфорил-холин (+), DL-Лактат (+), Оксоглутарат (+).	low	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3954	724	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3955	724	36	134	Ассимиляция D-глюкозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3956	724	32	118	Ассимиляция D-маннозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3957	724	28	102	Ассимиляция D-мальтозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3958	724	33	122	Ассимиляция D-трегалозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3959	724	40	150	Ассимиляция D-целлобиозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3960	724	41	154	Ассимиляция сахарозы. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3961	725	2	5	Скользящая подвижность. [5]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3962	725	7	17	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3963	725	8	21	Источник: Oh et al. (2011). [5]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3964	725	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [5]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3965	725	12	37	Положителен на щелочную и кислую фосфатазу. [5]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3966	725	18	61	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3967	725	21	74	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3968	725	30	109	Ассимиляция D-фруктозы. [5]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3969	726	2	5	Скользящая подвижность. [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3970	726	5	268	Рост при 0-1% NaCl. [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3971	726	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3972	726	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3973	726	9	26	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3974	726	10	30	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3975	726	11	34	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3976	726	12	37	Положителен на щелочную и кислую фосфатазу. [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3977	726	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3978	726	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3979	726	36	133	Ассимиляция D-глюкозы. [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3980	726	28	101	Ассимиляция мальтозы. [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
3981	727	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3982	727	17	58	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3983	727	20	69	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3984	727	19	65	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3985	727	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3986	727	25	89	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3987	727	36	133	Ассимиляция D-глюкозы. [1]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3988	727	31	114	Ассимиляция L-арабинозы. [1]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3989	727	32	117	Ассимиляция D-маннозы. [1]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3990	727	28	101	Ассимиляция D-мальтозы. [1]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
238	40	8	21	Извлечено из OCR.	high	\N	2025-06-26 02:45:09.04858	2025-06-28 08:41:12.302332
241	40	17	58	Извлечено из OCR.	high	\N	2025-06-26 02:45:09.04858	2025-06-28 08:41:12.302332
243	40	20	69	Извлечено из OCR.	high	\N	2025-06-26 02:45:09.04858	2025-06-28 08:41:12.302332
242	40	19	65	Извлечено из OCR.	high	\N	2025-06-26 02:45:09.04858	2025-06-28 08:41:12.302332
239	40	10	29	Извлечено из OCR.	high	\N	2025-06-26 02:45:09.04858	2025-06-28 08:41:12.302332
245	40	25	90	Извлечено из OCR.	high	\N	2025-06-26 02:45:09.04858	2025-06-28 08:41:12.302332
3997	40	36	133	Ассимиляция D-глюкозы. [1]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3998	40	31	113	Ассимиляция L-арабинозы. [1]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
3999	40	32	118	Ассимиляция D-маннозы. [1]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
257	40	28	101	Ассимиляция D-мальтозы. [1]	high	\N	2025-06-26 02:45:09.04858	2025-06-28 08:41:12.302332
4001	729	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4002	729	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [3]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4003	730	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4004	730	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [3]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4005	731	5	268	Рост при 0-4% NaCl. [4]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4006	731	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4007	731	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4008	731	9	26	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4009	731	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4010	731	11	34	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4011	731	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4012	731	23	81	Разложение коллоидного хитина. [4]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4013	731	24	85	Разложение карбоксиметилцеллюлозы. [4]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
4014	732	2	5	Скользящая подвижность. [1, 2]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4015	732	5	268	Рост при 0-2% NaCl. [1, 2]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4016	732	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4017	732	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4018	732	9	26	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4019	732	10	29	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4020	732	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4021	732	19	65	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4022	732	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4023	732	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4024	732	23	81	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4025	732	36	133	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4026	732	28	101	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4027	733	2	5	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4028	733	5	268	Рост при 0-0.5% NaCl. [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4029	733	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4030	733	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4031	733	9	25	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4032	733	10	29	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4033	733	12	37	Положителен на кислую фосфатазу и нафтол-AS-BI-фосфогидролазу. [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4034	733	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4035	733	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4036	733	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4037	733	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4038	733	19	66	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4039	733	36	134	Ассимиляция D-глюкозы. [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4040	733	28	103	Слабоположительный (w+). [3, 4]	low	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4041	733	35	130	Ассимиляция D-маннитола. [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
4042	734	2	5	Скользящая подвижность. [1]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4043	734	5	268	Рост при 0-1.0% NaCl. [1]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4044	734	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4045	734	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4046	734	9	26	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4047	734	10	29	Источник: Weon et al. (2007). [1]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4048	734	11	34	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4049	734	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4050	734	25	90	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4051	734	27	98	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4052	734	36	133	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4053	734	28	101	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4054	735	2	6	Источник: Ngo et al. (2015). [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4055	735	5	268	Рост при 0-1.0% NaCl. [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4056	735	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4057	735	8	23	Слабоположительный (w). [3]	low	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4058	735	9	25	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4059	735	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4060	735	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4061	735	19	65	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4062	735	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4063	735	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4064	735	23	81	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4065	735	24	85	Гидролиз КМ-целлюлозы. [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4066	735	20	69	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4067	735	28	101	Ассимиляция D-мальтозы. [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4068	736	7	18	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4069	736	2	6	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4070	736	10	30	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4071	736	16	54	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4072	736	19	65	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4073	736	24	85	Гидролиз КМЦ. [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4074	736	20	69	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4075	736	18	61	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4076	736	17	58	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4077	736	13	42	Липаза (C14). [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4078	736	28	102	Ассимиляция D-мальтозы. [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
4085	738	2	5	Скользящая подвижность. [1, 2]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4086	738	5	268	Рост при 0-1.0% NaCl. [1, 2]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4087	738	7	17	Источник: Li et al. (2018). [1, 2]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4088	738	8	21	Источник: Li et al. (2018). [1, 2]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4089	738	9	25	Источник: Li et al. (2018). [1, 2]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4090	738	10	29	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4091	738	18	61	Из примечания к таблице в OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4092	738	13	43	Эстераза (C4) (-), Эстераза липаза (C8) (-), Липаза (C14) (-), Трипсин (+), Химотрипсин (+). [1, 2]	low	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4093	738	33	121	Ассимиляция D-трегалозы. [1, 2]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1105	172	2	5	Скользящая подвижность. [3, 4]	high	\N	2025-06-26 07:25:02.810458	2025-06-28 08:49:51.67424
1891	172	5	268	Рост при 0-2.0% NaCl. [3, 4]	high	\N	2025-06-27 10:41:17.57901	2025-06-28 08:49:51.67424
1107	172	7	17	Извлечено из OCR.	high	\N	2025-06-26 07:25:02.810458	2025-06-28 08:49:51.67424
1106	172	8	21	Извлечено из OCR.	high	\N	2025-06-26 07:25:02.810458	2025-06-28 08:49:51.67424
4098	172	9	26	Источник: Singh et al. (2015). [3, 4]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4099	172	11	34	Источник: Singh et al. (2015). [3, 4]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1113	172	13	43	Эстераза (C4) - слабоположительно (w). [3, 4]	low	\N	2025-06-26 07:25:02.810458	2025-06-28 08:49:51.67424
1109	172	16	53	Извлечено из OCR.	high	\N	2025-06-26 07:25:02.810458	2025-06-28 08:49:51.67424
1108	172	17	57	Извлечено из OCR.	high	\N	2025-06-26 07:25:02.810458	2025-06-28 08:49:51.67424
4103	172	36	133	Ассимиляция D-глюкозы. [3, 4]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1112	172	28	101	Ассимиляция мальтозы. [3, 4]	high	\N	2025-06-26 07:25:02.810458	2025-06-28 08:49:51.67424
4105	740	2	5	Скользящая подвижность. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4106	740	5	268	Рост при 0-7.0% NaCl. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4107	740	7	17	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4108	740	8	21	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4109	740	9	26	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4110	740	11	34	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4111	740	13	41	Извлечено из OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4112	740	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4113	740	36	133	Ассимиляция D-глюкозы. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4114	740	28	101	Ассимиляция D-мальтозы. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4115	740	33	121	Ассимиляция D-трегалозы. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4116	740	40	149	Ассимиляция D-целлобиозы. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4117	740	41	153	Ассимиляция сахарозы. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
4118	741	2	5	Скользящая подвижность. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4119	741	5	268	Рост при 0-2.0% NaCl. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4120	741	7	17	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4121	741	8	21	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4122	741	9	26	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4123	741	10	30	Данные в OCR противоречивы (+/-), первоисточник указывает (-). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4124	741	11	34	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4125	741	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4126	741	12	37	Положителен на щелочную и кислую фосфатазу. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4127	741	16	53	Данные в OCR противоречивы (+/-), первоисточник указывает (+). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4128	741	17	57	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4129	741	18	61	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4130	741	19	65	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4131	741	23	82	Извлечено из OCR.	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4132	741	25	90	Извлечено из OCR.	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4133	741	27	98	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4134	741	36	133	Ассимиляция D-глюкозы. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4135	741	28	101	Ассимиляция D-мальтозы. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4136	741	31	113	Ассимиляция L-арабинозы. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4137	741	32	117	Ассимиляция D-маннозы. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4138	741	33	121	Ассимиляция трегалозы. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4139	741	35	129	Ассимиляция D-маннитола. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4140	741	37	137	Ассимиляция D-ксилозы. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4141	741	40	149	Ассимиляция целлобиозы. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4142	741	41	153	Ассимиляция сахарозы. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
4143	742	2	6	В таблицах OCR указано 'N*' (неподвижный) и '-' (отрицательный). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4144	742	5	268	Рост при 0-2.0% NaCl. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4145	742	7	17	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4146	742	8	21	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4147	742	9	26	В OCR указано '+', но первоисточник указывает '-'. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4148	742	10	31	Слабоположительный (w). [1]	low	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4149	742	11	34	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4150	742	13	41	Положителен на эстеразу (C4), эстеразу липазу (C8) и липазу (C14). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4151	742	12	37	Положителен на щелочную и кислую фосфатазу. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4152	742	16	53	В OCR есть противоречивые данные (+/-), но первоисточник указывает (+). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4153	742	17	57	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4154	742	18	61	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4155	742	19	65	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4156	742	25	90	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4157	742	27	98	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4158	742	36	133	Ассимиляция D-глюкозы. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4159	742	28	101	Ассимиляция мальтозы. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4160	742	31	114	Ассимиляция L-арабинозы. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4161	742	32	117	Ассимиляция D-маннозы. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4162	742	33	121	Ассимиляция трегалозы. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4163	742	35	129	Ассимиляция D-маннитола. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4164	742	34	125	Ассимиляция D-сорбита. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4165	742	41	153	Ассимиляция сахарозы. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
4166	743	2	5	Скользящая подвижность. [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4167	743	5	268	Рост при 0-1.0% NaCl. [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4168	743	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4169	743	8	21	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4170	743	9	26	Источник: Weon et al. (2006). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4171	743	13	41	Положителен на эстеразу (C4) и эстеразу липазу (C8). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4172	743	16	53	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4173	743	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4174	743	18	61	Источник: Weon et al. (2006). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4175	743	19	65	Источник: Weon et al. (2006). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4176	743	20	69	Источник: Weon et al. (2006). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4177	743	23	81	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4178	743	36	133	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4179	743	28	101	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4180	743	31	113	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4181	744	2	5	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4182	744	5	268	Рост при 0-3% NaCl. [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4183	744	7	17	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4184	744	8	23	Слабоположительный (+). [3, 4]	low	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4185	744	9	26	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4186	744	16	54	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4187	744	17	57	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4188	744	18	61	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4189	744	19	65	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4190	744	20	69	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4191	744	23	81	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4192	744	36	133	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
4193	744	28	101	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
\.


--
-- Data for Name: test_results_numeric; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_results_numeric (result_id, strain_id, test_id, value_type, numeric_value, measurement_unit, notes, confidence_level, tested_date, created_at, updated_at) FROM stdin;
353	40	79	minimum	7.0000	pH	Optimal pH range 7-8	high	\N	2025-06-27 10:41:16.493403	2025-06-27 10:51:52.367638
354	40	81	maximum	8.0000	pH	Optimal pH range 7-8	high	\N	2025-06-27 10:41:16.493403	2025-06-27 10:51:52.367638
373	106	76	minimum	15.0000	°C	Growth range 15-37°C	high	\N	2025-06-27 10:41:16.780313	2025-06-27 10:51:52.647616
374	106	78	maximum	37.0000	°C	Growth range 15-37°C	high	\N	2025-06-27 10:41:16.780313	2025-06-27 10:51:52.647616
352	40	77	optimal	30.0000	°C	Извлечено из OCR.	high	\N	2025-06-27 10:41:16.493403	2025-06-28 08:41:12.302332
378	107	79	minimum	6.0000	pH	Growth range 6.0-10.0	high	\N	2025-06-27 10:41:16.780313	2025-06-27 10:51:52.647616
379	107	81	maximum	10.0000	pH	Growth range 6.0-10.0	high	\N	2025-06-27 10:41:16.780313	2025-06-27 10:51:52.647616
381	108	76	minimum	15.0000	°C	Growth range 15-37°C	high	\N	2025-06-27 10:41:16.780313	2025-06-27 10:51:52.647616
382	108	78	maximum	37.0000	°C	Growth range 15-37°C	high	\N	2025-06-27 10:41:16.780313	2025-06-27 10:51:52.647616
403	120	76	minimum	25.0000	°C	Growth range 25-30°C	high	\N	2025-06-27 10:41:17.009519	2025-06-27 10:51:52.872535
404	120	78	maximum	30.0000	°C	Growth range 25-30°C	high	\N	2025-06-27 10:41:17.009519	2025-06-27 10:51:52.872535
405	120	79	minimum	6.8000	pH	Growth range 6.8-7.5	high	\N	2025-06-27 10:41:17.009519	2025-06-27 10:51:52.872535
406	120	81	maximum	7.5000	pH	Growth range 6.8-7.5	high	\N	2025-06-27 10:41:17.009519	2025-06-27 10:51:52.872535
424	134	76	minimum	4.0000	°C	Growth range 4-38°C.	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
425	134	78	maximum	38.0000	°C	Growth range 4-38°C.	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
32	5	44	single	69.4000	%	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
59	19	44	single	69.2000	%	Value is cited from another source in the table.	high	\N	2025-06-26 02:05:40.181	2025-06-27 10:51:52.043039
62	22	5	maximum	1.0000	%	Growth range 0-1%	high	\N	2025-06-26 02:08:43.428969	2025-06-26 02:56:46.572336
60	20	44	single	69.2000	%	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
64	23	5	maximum	2.0000	%	Growth range 0-2%	high	\N	2025-06-26 02:08:43.428969	2025-06-26 02:56:46.572336
61	21	44	single	69.2000	%	Value is cited from another source.	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
63	22	44	single	69.2000	%	Value is cited from another source.	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
67	23	44	single	69.2000	%	\N	high	\N	2025-06-26 02:08:43.428969	2025-06-27 10:51:52.098183
78	43	44	single	70.7000	%	Data from page 8. Page 5 shows 69.6%.	high	\N	2025-06-26 02:51:18.044327	2025-06-27 10:51:52.420486
125	77	44	single	67.7000	%	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
126	81	44	single	67.7000	%	\N	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
127	82	44	single	67.7000	%	Value is cited.	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
130	83	44	single	67.7000	%	Value is cited.	high	\N	2025-06-26 02:56:46.609219	2025-06-27 10:51:52.476509
146	105	44	single	68.2000	%	Value is cited from another source.	high	\N	2025-06-26 06:08:48.097892	2025-06-27 10:51:52.593982
383	108	79	minimum	6.0000	pH	Growth range 6.0-9.0	high	\N	2025-06-27 10:41:16.780313	2025-06-27 10:51:52.647616
426	134	77	optimal	30.0000	°C	\N	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
427	134	79	minimum	6.0000	pH	Growth range 6.0-8.0.	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
428	134	81	maximum	8.0000	pH	Growth range 6.0-8.0.	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
430	138	76	minimum	10.0000	°C	Growth range 10-37°C	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
431	138	78	maximum	37.0000	°C	Growth range 10-37°C	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
375	106	79	minimum	6.0000	pH	Извлечено из диапазона 6.0-9.0 в OCR.	high	\N	2025-06-27 10:41:16.780313	2025-06-28 08:22:56.033373
37	2	5	maximum	1.0000	%	Growth range 0-1%	high	\N	2025-06-26 01:29:11.946964	2025-06-26 02:56:46.559031
376	106	81	maximum	9.0000	pH	Извлечено из диапазона 6.0-9.0 в OCR.	high	\N	2025-06-27 10:41:16.780313	2025-06-28 08:22:56.033373
43	4	5	maximum	7.0000	%	Growth range 0-7%	high	\N	2025-06-26 01:29:11.946964	2025-06-26 02:56:46.559031
45	5	5	maximum	7.0000	%	Growth range 0-7.0%	high	\N	2025-06-26 01:29:11.946964	2025-06-26 02:56:46.559031
54	19	5	maximum	1.0000	%	Growth range 0-1%	high	\N	2025-06-26 02:05:40.181	2025-06-26 02:56:46.56493
49	11	44	single	66.6000	%	Value is cited from another source in the table.	high	\N	2025-06-26 01:39:52.018094	2025-06-27 10:51:51.87673
26	2	44	single	67.1000	%	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
31	4	44	single	63.8000	%	\N	high	\N	2025-06-26 01:25:32.136319	2025-06-27 10:51:51.986718
77	43	5	maximum	4.0000	%	Growth range 0-4%. Page 8 shows 0-2%.	high	\N	2025-06-26 02:51:18.044327	2025-06-26 02:56:46.602843
384	108	81	maximum	9.0000	pH	Growth range 6.0-9.0	high	\N	2025-06-27 10:41:16.780313	2025-06-27 10:51:52.647616
47	11	5	minimum	0.0000	%	Growth range 0-6%	high	\N	2025-06-26 01:39:52.018094	2025-06-26 02:56:46.618982
48	11	5	maximum	6.0000	%	Growth range 0-6%	high	\N	2025-06-26 01:39:52.018094	2025-06-26 02:56:46.618982
145	105	5	maximum	3.0000	%	Growth range 0-3% (refined from multiple tables).	high	\N	2025-06-26 06:08:48.097892	2025-06-26 06:08:48.097892
151	106	5	maximum	1.0000	%	Growth range 0-1%	high	\N	2025-06-26 06:11:46.884141	2025-06-26 06:11:46.884141
155	107	5	maximum	1.0000	%	Growth range 0-1%	high	\N	2025-06-26 06:11:46.884141	2025-06-26 06:11:46.884141
161	108	5	maximum	1.0000	%	Growth range 0-1%. Data from page 70. Page 5 shows a conflicting range of 0-7.0%.	high	\N	2025-06-26 06:11:46.884141	2025-06-26 06:11:46.884141
167	112	5	maximum	2.0000	%	Growth range 0-2%	high	\N	2025-06-26 06:20:20.109378	2025-06-26 06:20:20.109378
186	120	44	single	63.8000	%	Conflicting data: 63.8% on pages 20, 23, 27, 43 vs 67.0% on page 6. The more frequent value was chosen.	low	\N	2025-06-26 06:27:04.328668	2025-06-27 10:51:52.872535
408	127	76	minimum	10.0000	°C	Combined growth range from all tables is 10-40°C.	high	\N	2025-06-27 10:41:17.119192	2025-06-27 10:51:52.978653
409	127	78	maximum	40.0000	°C	Combined growth range from all tables is 10-40°C.	high	\N	2025-06-27 10:41:17.119192	2025-06-27 10:51:52.978653
180	115	5	maximum	2.0000	%	Growth range 0-2%.	high	\N	2025-06-26 06:24:48.508178	2025-06-26 06:24:48.508178
192	127	44	single	69.3000	%	Conflicting data: 69.3% on pages 31, 53 vs 61.7% on pages 48, 79. The more frequently cited value was chosen.	low	\N	2025-06-26 06:34:41.601951	2025-06-27 10:51:52.978653
199	128	44	single	61.7000	%	Value from BacDive and multiple tables in the PDF. Some tables showed a conflicting value of 69.3%.	high	\N	2025-06-26 06:48:31.463937	2025-06-27 10:51:53.033003
205	132	44	single	67.1000	%	Value from BacDive and multiple tables in the PDF. One table showed a conflicting value of 70.3%.	high	\N	2025-06-26 06:52:03.607207	2025-06-27 10:51:53.088789
434	138	81	maximum	7.5000	pH	Growth range 6.0-7.5	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
191	127	5	maximum	7.0000	%	Conflicting data: Ranges of 0-1%, 0-3%, and 0-7% were found. The widest range is reported.	low	\N	2025-06-26 06:34:41.601951	2025-06-26 06:34:41.601951
435	138	80	optimal	7.0000	pH	\N	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
451	170	79	minimum	5.0000	pH	Growth range 5.0-9.0.	high	\N	2025-06-27 10:41:17.473608	2025-06-27 10:51:53.323451
152	106	44	single	70.6000	%	Извлечено из OCR.	high	\N	2025-06-26 06:11:46.884141	2025-06-28 08:22:56.033373
181	115	44	single	70.7000	%	Извлечено из OCR.	high	\N	2025-06-26 06:24:48.508178	2025-06-28 08:31:30.960414
198	128	5	maximum	3.0000	%	Growth range 0-3%.	high	\N	2025-06-26 06:48:31.463937	2025-06-26 06:48:31.463937
204	132	5	maximum	6.0000	%	Growth range 0-6%.	high	\N	2025-06-26 06:52:03.607207	2025-06-26 06:52:03.607207
211	134	5	maximum	0.5000	%	Growth range 0-0.5%.	high	\N	2025-06-26 06:57:10.819485	2025-06-26 06:57:10.819485
355	43	76	minimum	4.0000	°C	Growth range 4-37°C	high	\N	2025-06-27 10:41:16.54551	2025-06-27 10:51:52.420486
356	43	78	maximum	37.0000	°C	Growth range 4-37°C	high	\N	2025-06-27 10:41:16.54551	2025-06-27 10:51:52.420486
357	43	77	optimal	28.0000	°C	\N	high	\N	2025-06-27 10:41:16.54551	2025-06-27 10:51:52.420486
358	43	79	minimum	5.0000	pH	Growth range 5-9	high	\N	2025-06-27 10:41:16.54551	2025-06-27 10:51:52.420486
359	43	81	maximum	9.0000	pH	Growth range 5-9	high	\N	2025-06-27 10:41:16.54551	2025-06-27 10:51:52.420486
360	43	80	optimal	7.0000	pH	\N	high	\N	2025-06-27 10:41:16.54551	2025-06-27 10:51:52.420486
156	107	44	single	68.7000	%	\N	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
162	108	44	single	70.6000	%	Data from page 70. Page 5 shows a conflicting value of 69.4%.	high	\N	2025-06-26 06:11:46.884141	2025-06-27 10:51:52.647616
386	112	76	minimum	15.0000	°C	Growth range 15-37°C	high	\N	2025-06-27 10:41:16.837563	2025-06-27 10:51:52.706755
387	112	78	maximum	37.0000	°C	Growth range 15-37°C	high	\N	2025-06-27 10:41:16.837563	2025-06-27 10:51:52.706755
388	112	79	minimum	5.5000	pH	Growth range 5.5-8.5	high	\N	2025-06-27 10:41:16.837563	2025-06-27 10:51:52.706755
389	112	81	maximum	8.5000	pH	Growth range 5.5-8.5	high	\N	2025-06-27 10:41:16.837563	2025-06-27 10:51:52.706755
168	112	44	single	65.4000	%	Value is consistent across multiple tables and citations.	high	\N	2025-06-26 06:20:20.109378	2025-06-27 10:51:52.706755
175	114	44	single	67.8000	%	\N	high	\N	2025-06-26 06:21:59.494506	2025-06-27 10:51:52.76314
410	127	79	minimum	5.0000	pH	Combined growth range from all tables is 5.0-9.0.	high	\N	2025-06-27 10:41:17.119192	2025-06-27 10:51:52.978653
411	127	81	maximum	9.0000	pH	Combined growth range from all tables is 5.0-9.0.	high	\N	2025-06-27 10:41:17.119192	2025-06-27 10:51:52.978653
212	134	44	single	68.1000	%	Value from BacDive and multiple tables in the PDF.	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
432	138	77	optimal	28.0000	°C	\N	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
433	138	79	minimum	6.0000	pH	Growth range 6.0-7.5	high	\N	2025-06-27 10:41:17.284631	2025-06-27 10:51:53.145016
449	170	76	minimum	20.0000	°C	Growth range 20-37°C.	high	\N	2025-06-27 10:41:17.473608	2025-06-27 10:51:53.323451
450	170	78	maximum	37.0000	°C	Growth range 20-37°C.	high	\N	2025-06-27 10:41:17.473608	2025-06-27 10:51:53.323451
452	170	81	maximum	9.0000	pH	Growth range 5.0-9.0.	high	\N	2025-06-27 10:41:17.473608	2025-06-27 10:51:53.323451
462	173	76	minimum	15.0000	°C	Growth range 15-45°C (from BacDive).	high	\N	2025-06-27 10:41:17.631892	2025-06-27 10:51:53.478592
463	173	78	maximum	45.0000	°C	Growth range 15-45°C (from BacDive).	high	\N	2025-06-27 10:41:17.631892	2025-06-27 10:51:53.478592
464	173	77	optimal	30.0000	°C	From BacDive.	high	\N	2025-06-27 10:41:17.631892	2025-06-27 10:51:53.478592
330	2	76	minimum	15.0000	°C	Growth range 15-37°C	high	\N	2025-06-27 10:41:16.114924	2025-06-27 10:51:51.986718
331	2	78	maximum	37.0000	°C	Growth range 15-37°C	high	\N	2025-06-27 10:41:16.114924	2025-06-27 10:51:51.986718
332	2	79	minimum	6.0000	pH	pH range 6.0-9.0	high	\N	2025-06-27 10:41:16.114924	2025-06-27 10:51:51.986718
333	2	81	maximum	9.0000	pH	pH range 6.0-9.0	high	\N	2025-06-27 10:41:16.114924	2025-06-27 10:51:51.986718
335	4	76	minimum	15.0000	°C	Growth range 15-40°C	high	\N	2025-06-27 10:41:16.114924	2025-06-27 10:51:51.986718
336	4	78	maximum	40.0000	°C	Growth range 15-40°C	high	\N	2025-06-27 10:41:16.114924	2025-06-27 10:51:51.986718
337	4	79	minimum	5.5000	pH	pH range 5.5-9.0	high	\N	2025-06-27 10:41:16.114924	2025-06-27 10:51:51.986718
338	4	81	maximum	9.0000	pH	pH range 5.5-9.0	high	\N	2025-06-27 10:41:16.114924	2025-06-27 10:51:51.986718
224	139	5	maximum	1.0000	%	Growth range 0-1%.	high	\N	2025-06-26 07:07:28.925588	2025-06-26 07:07:28.925588
233	145	5	maximum	2.0000	%	Tolerates up to 2% NaCl (from BacDive).	high	\N	2025-06-26 07:15:30.110978	2025-06-26 07:15:30.110978
238	170	5	maximum	1.0000	%	Growth range 0-1.0%.	high	\N	2025-06-26 07:17:39.437709	2025-06-26 07:17:39.437709
239	170	44	single	69.0000	%	\N	high	\N	2025-06-26 07:17:39.437709	2025-06-27 10:51:53.323451
244	171	5	maximum	0.5000	%	Growth range 0-0.5%.	high	\N	2025-06-26 07:22:26.618307	2025-06-26 07:22:26.618307
248	172	44	single	66.9000	%	Извлечено из OCR.	high	\N	2025-06-26 07:25:02.810458	2025-06-28 08:49:51.67424
255	173	5	maximum	3.0000	%	Tolerates up to 3% NaCl (from BacDive).	high	\N	2025-06-26 07:31:04.56484	2025-06-26 07:31:04.56484
465	173	79	minimum	5.0000	pH	Growth range 5.0-9.0 (from BacDive).	high	\N	2025-06-27 10:41:17.631892	2025-06-27 10:51:53.478592
262	176	44	single	65.7000	%	Value from BacDive and multiple tables in the PDF.	high	\N	2025-06-26 07:33:14.429692	2025-06-27 10:51:53.532828
261	176	5	maximum	2.0000	%	Tolerates up to 2% NaCl.	high	\N	2025-06-26 07:33:14.429692	2025-06-26 07:33:14.429692
265	186	5	maximum	0.5000	%	Growth range 0-0.5%.	high	\N	2025-06-26 07:35:10.644027	2025-06-26 07:35:10.644027
474	186	76	minimum	10.0000	°C	Growth range 10-30°C.	high	\N	2025-06-27 10:41:17.752763	2025-06-27 10:51:53.587976
273	187	44	single	68.0000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:37:24.903408	2025-06-27 10:51:53.642637
272	187	5	maximum	0.5000	%	Growth range 0-0.5%.	high	\N	2025-06-26 07:37:24.903408	2025-06-26 07:37:24.903408
483	191	76	minimum	10.0000	°C	Growth range 10-40°C.	high	\N	2025-06-27 10:41:17.861725	2025-06-27 10:51:53.695488
495	195	76	minimum	10.0000	°C	Growth range 10-30°C.	high	\N	2025-06-27 10:41:17.976415	2025-06-27 10:51:53.802508
279	191	5	maximum	1.0000	%	Tolerates up to 1% NaCl.	high	\N	2025-06-26 07:40:33.583319	2025-06-26 07:40:33.583319
509	200	76	minimum	15.0000	°C	Growth range 15-37°C.	high	\N	2025-06-27 10:41:18.083889	2025-06-27 10:51:53.90944
286	194	5	maximum	1.0000	%	Growth range 0-1%.	high	\N	2025-06-26 07:46:04.762326	2025-06-26 07:46:04.762326
365	83	76	minimum	4.0000	°C	Growth range 4-50°C. Value is cited.	high	\N	2025-06-27 10:41:16.602311	2025-06-27 10:51:52.476509
391	114	76	minimum	10.0000	°C	Growth range 10-37°C	high	\N	2025-06-27 10:41:16.893922	2025-06-27 10:51:52.76314
392	114	78	maximum	37.0000	°C	Growth range 10-37°C	high	\N	2025-06-27 10:41:16.893922	2025-06-27 10:51:52.76314
413	128	76	minimum	10.0000	°C	Growth range 10-37°C.	high	\N	2025-06-27 10:41:17.174644	2025-06-27 10:51:53.033003
414	128	78	maximum	37.0000	°C	Growth range 10-37°C.	high	\N	2025-06-27 10:41:17.174644	2025-06-27 10:51:53.033003
415	128	77	optimal	28.0000	°C	\N	high	\N	2025-06-27 10:41:17.174644	2025-06-27 10:51:53.033003
416	128	79	minimum	6.0000	pH	Growth range 6.0-8.0.	high	\N	2025-06-27 10:41:17.174644	2025-06-27 10:51:53.033003
219	138	44	single	68.2000	%	\N	high	\N	2025-06-26 06:57:10.819485	2025-06-27 10:51:53.145016
437	139	76	minimum	5.0000	°C	Growth range 5-40°C.	high	\N	2025-06-27 10:41:17.341366	2025-06-27 10:51:53.199661
438	139	78	maximum	40.0000	°C	Growth range 5-40°C.	high	\N	2025-06-27 10:41:17.341366	2025-06-27 10:51:53.199661
439	139	79	minimum	4.0000	pH	Growth range 4.0-10.0.	high	\N	2025-06-27 10:41:17.341366	2025-06-27 10:51:53.199661
440	139	81	maximum	10.0000	pH	Growth range 4.0-10.0.	high	\N	2025-06-27 10:41:17.341366	2025-06-27 10:51:53.199661
225	139	44	single	69.0000	%	Value from BacDive and multiple tables in the PDF.	high	\N	2025-06-26 07:07:28.925588	2025-06-27 10:51:53.199661
456	171	79	minimum	6.0000	pH	Growth range 6-8 (from BacDive).	high	\N	2025-06-27 10:41:17.525976	2025-06-27 10:51:53.374602
457	171	81	maximum	8.0000	pH	Growth range 6-8 (from BacDive).	high	\N	2025-06-27 10:41:17.525976	2025-06-27 10:51:53.374602
466	173	81	maximum	9.0000	pH	Growth range 5.0-9.0 (from BacDive).	high	\N	2025-06-27 10:41:17.631892	2025-06-27 10:51:53.478592
467	173	80	optimal	7.0000	pH	From BacDive.	high	\N	2025-06-27 10:41:17.631892	2025-06-27 10:51:53.478592
256	173	44	single	69.3000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:31:04.56484	2025-06-27 10:51:53.478592
475	186	78	maximum	30.0000	°C	Growth range 10-30°C.	high	\N	2025-06-27 10:41:17.752763	2025-06-27 10:51:53.587976
266	186	44	single	68.6000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:35:10.644027	2025-06-27 10:51:53.587976
484	191	78	maximum	40.0000	°C	Growth range 10-40°C.	high	\N	2025-06-27 10:41:17.861725	2025-06-27 10:51:53.695488
485	191	77	optimal	30.0000	°C	Optimal range 28-30°C.	high	\N	2025-06-27 10:41:17.861725	2025-06-27 10:51:53.695488
486	191	79	minimum	4.0000	pH	Growth range 4-9.	high	\N	2025-06-27 10:41:17.861725	2025-06-27 10:51:53.695488
487	191	81	maximum	9.0000	pH	Growth range 4-9.	high	\N	2025-06-27 10:41:17.861725	2025-06-27 10:51:53.695488
496	195	78	maximum	30.0000	°C	Growth range 10-30°C.	high	\N	2025-06-27 10:41:17.976415	2025-06-27 10:51:53.802508
497	195	77	optimal	25.0000	°C	From BacDive.	high	\N	2025-06-27 10:41:17.976415	2025-06-27 10:51:53.802508
498	195	79	minimum	5.5000	pH	Growth range 5.5-8.5.	high	\N	2025-06-27 10:41:17.976415	2025-06-27 10:51:53.802508
499	195	81	maximum	8.5000	pH	Growth range 5.5-8.5.	high	\N	2025-06-27 10:41:17.976415	2025-06-27 10:51:53.802508
500	195	80	optimal	7.0000	pH	From BacDive.	high	\N	2025-06-27 10:41:17.976415	2025-06-27 10:51:53.802508
510	200	78	maximum	37.0000	°C	Growth range 15-37°C.	high	\N	2025-06-27 10:41:18.083889	2025-06-27 10:51:53.90944
511	200	79	minimum	6.0000	pH	Growth range 6-9.	high	\N	2025-06-27 10:41:18.083889	2025-06-27 10:51:53.90944
512	200	81	maximum	9.0000	pH	Growth range 6-9.	high	\N	2025-06-27 10:41:18.083889	2025-06-27 10:51:53.90944
514	203	76	minimum	5.0000	°C	Growth range 5-37°C.	high	\N	2025-06-27 10:41:18.083889	2025-06-27 10:51:53.90944
515	203	78	maximum	37.0000	°C	Growth range 5-37°C.	high	\N	2025-06-27 10:41:18.083889	2025-06-27 10:51:53.90944
454	171	76	minimum	15.0000	°C	Извлечено из диапазона 15-37 в OCR.	high	\N	2025-06-27 10:41:17.525976	2025-06-28 08:22:56.033373
455	171	78	maximum	37.0000	°C	Извлечено из диапазона 15-37 в OCR.	high	\N	2025-06-27 10:41:17.525976	2025-06-28 08:22:56.033373
245	171	44	single	68.7000	%	Извлечено из OCR.	high	\N	2025-06-26 07:22:26.618307	2025-06-28 08:22:56.033373
341	19	79	minimum	5.0000	pH	Growth range 5-9	high	\N	2025-06-27 10:41:16.169451	2025-06-27 10:51:52.043039
366	83	78	maximum	50.0000	°C	Growth range 4-50°C. Value is cited.	high	\N	2025-06-27 10:41:16.602311	2025-06-27 10:51:52.476509
393	114	77	optimal	30.0000	°C	\N	high	\N	2025-06-27 10:41:16.893922	2025-06-27 10:51:52.76314
394	114	79	minimum	6.0000	pH	Growth range 6.0-8.0	high	\N	2025-06-27 10:41:16.893922	2025-06-27 10:51:52.76314
417	128	81	maximum	8.0000	pH	Growth range 6.0-8.0.	high	\N	2025-06-27 10:41:17.174644	2025-06-27 10:51:53.033003
280	191	44	single	68.9000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:40:33.583319	2025-06-27 10:51:53.695488
516	203	79	minimum	4.0000	pH	Growth range 4-9.	high	\N	2025-06-27 10:41:18.083889	2025-06-27 10:51:53.90944
294	195	5	maximum	1.0000	%	Growth range 0-1%.	high	\N	2025-06-26 07:48:31.490817	2025-06-26 07:48:31.490817
302	196	5	maximum	7.0000	%	Growth range 0-7%.	high	\N	2025-06-26 07:50:15.081584	2025-06-26 07:50:15.081584
308	200	5	maximum	0.5000	%	Growth range 0-0.5%.	high	\N	2025-06-26 07:57:19.568773	2025-06-26 07:57:19.568773
320	206	5	maximum	1.0000	%	Tolerates up to 1% NaCl.	high	\N	2025-06-26 07:59:40.869851	2025-06-26 07:59:40.869851
502	196	76	minimum	20.0000	°C	Growth range 20-40°C.	high	\N	2025-06-27 10:41:18.029543	2025-06-27 10:51:53.855935
309	200	44	single	70.7000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
519	206	76	minimum	10.0000	°C	Growth range 10-40°C.	high	\N	2025-06-27 10:41:18.141803	2025-06-27 10:51:53.965488
398	115	76	minimum	4.0000	°C	Извлечено из диапазона 4-30 в OCR.	high	\N	2025-06-27 10:41:16.952343	2025-06-28 08:31:30.960414
399	115	78	maximum	30.0000	°C	Извлечено из диапазона 4-30 в OCR.	high	\N	2025-06-27 10:41:16.952343	2025-06-28 08:31:30.960414
342	19	81	maximum	9.0000	pH	Growth range 5-9	high	\N	2025-06-27 10:41:16.169451	2025-06-27 10:51:52.043039
368	105	76	minimum	10.0000	°C	Growth range 10-37°C (refined from multiple tables).	high	\N	2025-06-27 10:41:16.725117	2025-06-27 10:51:52.593982
369	105	78	maximum	37.0000	°C	Growth range 10-37°C (refined from multiple tables).	high	\N	2025-06-27 10:41:16.725117	2025-06-27 10:51:52.593982
395	114	81	maximum	8.0000	pH	Growth range 6.0-8.0	high	\N	2025-06-27 10:41:16.893922	2025-06-27 10:51:52.76314
396	114	80	optimal	7.0000	pH	\N	high	\N	2025-06-27 10:41:16.893922	2025-06-27 10:51:52.76314
459	172	76	minimum	10.0000	°C	Источник: Singh et al. (2015). [3, 4]	high	\N	2025-06-27 10:41:17.57901	2025-06-28 08:49:51.67424
460	172	78	maximum	28.0000	°C	Источник: Singh et al. (2015). [3, 4]	high	\N	2025-06-27 10:41:17.57901	2025-06-28 08:49:51.67424
419	132	76	minimum	10.0000	°C	Growth range 10-37°C (from BacDive).	high	\N	2025-06-27 10:41:17.231007	2025-06-27 10:51:53.088789
420	132	78	maximum	37.0000	°C	Growth range 10-37°C (from BacDive).	high	\N	2025-06-27 10:41:17.231007	2025-06-27 10:51:53.088789
421	132	79	minimum	6.0000	pH	Growth range 6-9 (from BacDive).	high	\N	2025-06-27 10:41:17.231007	2025-06-27 10:51:53.088789
422	132	81	maximum	9.0000	pH	Growth range 6-9 (from BacDive).	high	\N	2025-06-27 10:41:17.231007	2025-06-27 10:51:53.088789
442	148	76	minimum	28.0000	°C	Optimal growth range 28-30°C	high	\N	2025-06-27 10:41:17.341366	2025-06-27 10:51:53.199661
443	148	78	maximum	30.0000	°C	Optimal growth range 28-30°C	high	\N	2025-06-27 10:41:17.341366	2025-06-27 10:51:53.199661
444	148	80	optimal	7.0000	pH	\N	high	\N	2025-06-27 10:41:17.341366	2025-06-27 10:51:53.199661
445	145	76	minimum	10.0000	°C	Growth range 10-40°C (from BacDive).	high	\N	2025-06-27 10:41:17.41435	2025-06-27 10:51:53.270357
469	176	76	minimum	10.0000	°C	Growth range 10-40°C (from BacDive).	high	\N	2025-06-27 10:41:17.688111	2025-06-27 10:51:53.532828
470	176	78	maximum	40.0000	°C	Growth range 10-40°C (from BacDive).	high	\N	2025-06-27 10:41:17.688111	2025-06-27 10:51:53.532828
471	176	79	minimum	4.0000	pH	Growth range 4-9 (from BacDive).	high	\N	2025-06-27 10:41:17.688111	2025-06-27 10:51:53.532828
472	176	81	maximum	9.0000	pH	Growth range 4-9 (from BacDive).	high	\N	2025-06-27 10:41:17.688111	2025-06-27 10:51:53.532828
477	187	76	minimum	15.0000	°C	Growth range 15-42°C (from BacDive).	high	\N	2025-06-27 10:41:17.80663	2025-06-27 10:51:53.642637
478	187	78	maximum	42.0000	°C	Growth range 15-42°C (from BacDive).	high	\N	2025-06-27 10:41:17.80663	2025-06-27 10:51:53.642637
479	187	77	optimal	28.0000	°C	Optimal range 28-30°C (from BacDive).	high	\N	2025-06-27 10:41:17.80663	2025-06-27 10:51:53.642637
480	187	79	minimum	6.0000	pH	Growth range 6-11.	high	\N	2025-06-27 10:41:17.80663	2025-06-27 10:51:53.642637
489	194	76	minimum	10.0000	°C	Growth range 10-37°C.	high	\N	2025-06-27 10:41:17.916372	2025-06-27 10:51:53.7494
490	194	78	maximum	37.0000	°C	Growth range 10-37°C.	high	\N	2025-06-27 10:41:17.916372	2025-06-27 10:51:53.7494
491	194	77	optimal	28.0000	°C	Optimal range 28-30°C.	high	\N	2025-06-27 10:41:17.916372	2025-06-27 10:51:53.7494
492	194	79	minimum	6.0000	pH	Growth range 6.0-9.0.	high	\N	2025-06-27 10:41:17.916372	2025-06-27 10:51:53.7494
295	195	44	single	69.1000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:48:31.490817	2025-06-27 10:51:53.802508
503	196	78	maximum	40.0000	°C	Growth range 20-40°C.	high	\N	2025-06-27 10:41:18.029543	2025-06-27 10:51:53.855935
504	196	77	optimal	30.0000	°C	\N	high	\N	2025-06-27 10:41:18.029543	2025-06-27 10:51:53.855935
505	196	79	minimum	6.0000	pH	Growth range 6-8.	high	\N	2025-06-27 10:41:18.029543	2025-06-27 10:51:53.855935
506	196	81	maximum	8.0000	pH	Growth range 6-8.	high	\N	2025-06-27 10:41:18.029543	2025-06-27 10:51:53.855935
517	203	81	maximum	9.0000	pH	Growth range 4-9.	high	\N	2025-06-27 10:41:18.083889	2025-06-27 10:51:53.90944
314	203	44	single	62.5000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:57:19.568773	2025-06-27 10:51:53.90944
520	206	78	maximum	40.0000	°C	Growth range 10-40°C.	high	\N	2025-06-27 10:41:18.141803	2025-06-27 10:51:53.965488
521	206	77	optimal	30.0000	°C	Optimal range 28-30°C.	high	\N	2025-06-27 10:41:18.141803	2025-06-27 10:51:53.965488
522	206	79	minimum	4.0000	pH	Growth range 4-9.	high	\N	2025-06-27 10:41:18.141803	2025-06-27 10:51:53.965488
523	206	81	maximum	9.0000	pH	Growth range 4-9.	high	\N	2025-06-27 10:41:18.141803	2025-06-27 10:51:53.965488
321	206	44	single	66.6000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:59:40.869851	2025-06-27 10:51:53.965488
400	115	79	minimum	6.0000	pH	Извлечено из диапазона 6-10 в OCR.	high	\N	2025-06-27 10:41:16.952343	2025-06-28 08:31:30.960414
401	115	81	maximum	10.0000	pH	Извлечено из диапазона 6-10 в OCR.	high	\N	2025-06-27 10:41:16.952343	2025-06-28 08:31:30.960414
343	19	76	minimum	4.0000	°C	Growth range 4-40°C	high	\N	2025-06-27 10:41:16.169451	2025-06-27 10:51:52.043039
344	19	78	maximum	40.0000	°C	Growth range 4-40°C	high	\N	2025-06-27 10:41:16.169451	2025-06-27 10:51:52.043039
349	23	76	minimum	10.0000	°C	Growth range 10-40°C	high	\N	2025-06-27 10:41:16.224177	2025-06-27 10:51:52.098183
350	23	78	maximum	40.0000	°C	Growth range 10-40°C	high	\N	2025-06-27 10:41:16.224177	2025-06-27 10:51:52.098183
370	105	79	minimum	7.0000	pH	Growth range 7-10.	high	\N	2025-06-27 10:41:16.725117	2025-06-27 10:51:52.593982
371	105	81	maximum	10.0000	pH	Growth range 7-10.	high	\N	2025-06-27 10:41:16.725117	2025-06-27 10:51:52.593982
446	145	78	maximum	40.0000	°C	Growth range 10-40°C (from BacDive).	high	\N	2025-06-27 10:41:17.41435	2025-06-27 10:51:53.270357
447	145	79	minimum	6.0000	pH	Growth range 6-9 (from BacDive).	high	\N	2025-06-27 10:41:17.41435	2025-06-27 10:51:53.270357
448	145	81	maximum	9.0000	pH	Growth range 6-9 (from BacDive).	high	\N	2025-06-27 10:41:17.41435	2025-06-27 10:51:53.270357
493	194	81	maximum	9.0000	pH	Growth range 6.0-9.0.	high	\N	2025-06-27 10:41:17.916372	2025-06-27 10:51:53.7494
507	196	80	optimal	7.0000	pH	\N	high	\N	2025-06-27 10:41:18.029543	2025-06-27 10:51:53.855935
481	187	81	maximum	11.0000	pH	Growth range 6-11.	high	\N	2025-06-27 10:41:17.80663	2025-06-27 10:51:53.642637
287	194	44	single	67.9000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:46:04.762326	2025-06-27 10:51:53.7494
303	196	44	single	68.6000	%	Value is consistent between PDF and BacDive.	high	\N	2025-06-26 07:50:15.081584	2025-06-27 10:51:53.855935
931	684	76	minimum	5.0000	°C	Рост отмечен как 'слабый'.	low	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
932	684	78	maximum	30.0000	°C	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
933	684	44	single	63.4000	%	В таблице указано 63.4, в статье Margesin et al. (2018) - 63.35%. [4]	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
934	685	76	minimum	10.0000	°C	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
935	685	77	optimal	30.0000	°C	Исходный источник указывал оптимальный диапазон 25-35°C. Используется среднее значение согласно инструкциям.	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
936	685	78	maximum	35.0000	°C	\N	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
937	685	80	optimal	7.0000	pH	Источник: Singh et al. (2015). [1]	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
938	685	44	single	62.5000	%	Источник: Singh et al. (2015). [1]	high	\N	2025-06-28 02:44:37.959633	2025-06-28 02:44:37.959633
939	686	76	minimum	15.0000	°C	Источник: BacDive. [3]	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
940	686	77	optimal	30.0000	°C	Источник: BacDive. [3]	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
941	686	78	maximum	37.0000	°C	Источник: BacDive. [3]	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
942	686	79	minimum	6.0000	pH	Извлечено из диапазона 6.0-9.0 в OCR.	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
943	686	80	optimal	7.0000	pH	Извлечено из OCR.	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
944	686	81	maximum	9.0000	pH	Извлечено из диапазона 6.0-9.0 в OCR.	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
945	686	44	single	67.1000	%	Источник: Bai et al. (2020). [1, 2]	high	\N	2025-06-28 07:47:08.669393	2025-06-28 07:47:08.669393
946	687	76	minimum	5.0000	°C	Колонии также образовывались при -5°C. [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
947	687	77	optimal	23.0000	°C	Источник: Fukuda et al. (2013). [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
948	687	78	maximum	25.0000	°C	Источник: Fukuda et al. (2013). [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
949	687	79	minimum	6.0000	pH	Извлечено из диапазона 6.0-9.0. [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
950	687	80	optimal	7.5000	pH	Извлечено из диапазона 7.0-8.0. [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
951	687	81	maximum	9.0000	pH	Извлечено из диапазона 6.0-9.0. [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
952	687	44	single	66.1000	%	Источник: Fukuda et al. (2013). [6]	high	\N	2025-06-28 07:49:04.951662	2025-06-28 07:49:04.951662
953	688	77	optimal	28.0000	°C	Извлечено из таблицы 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
954	688	80	optimal	7.5000	pH	Извлечено из диапазона 7-8 в таблице 'Сравнение фенотипических характеристик штаммов R7T и R19Т'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
955	689	44	single	67.4000	%	Извлечено из таблицы 'Биохимические и физиологические характеристики штамма THG-SKA3T'.	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
956	690	44	single	66.0000	%	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
957	691	76	minimum	10.0000	°C	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
958	691	78	maximum	37.0000	°C	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
959	691	79	minimum	6.0000	pH	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
960	691	81	maximum	8.0000	pH	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
961	691	44	single	65.3000	%	\N	high	\N	2025-06-28 07:50:55.242479	2025-06-28 07:50:55.242479
962	692	76	minimum	10.0000	°C	Извлечено из диапазона 10-42 в OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
963	692	77	optimal	30.0000	°C	Извлечено из диапазона 28-30 в OCR и подтверждено Choi et al. (2014). [2, 4]	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
964	692	78	maximum	42.0000	°C	Извлечено из диапазона 10-42 в OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
965	692	79	minimum	5.0000	pH	Извлечено из диапазона 5-11 в OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
966	692	80	optimal	7.0000	pH	Извлечено из OCR и подтверждено Choi et al. (2014). [2, 4]	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
967	692	81	maximum	11.0000	pH	Извлечено из диапазона 5-11 в OCR.	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
968	692	44	single	65.6000	%	Источник: Choi et al. (2014). [2, 7]	high	\N	2025-06-28 07:53:00.30969	2025-06-28 07:53:00.30969
969	693	76	minimum	20.0000	°C	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
970	693	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
971	693	78	maximum	37.0000	°C	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
972	693	79	minimum	6.0000	pH	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
973	693	80	optimal	7.0000	pH	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
974	693	81	maximum	8.0000	pH	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
975	693	44	single	67.0000	%	Источник: Ten et al. (2009). [1]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
976	179	76	minimum	4.0000	°C	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
977	179	77	optimal	30.0000	°C	Источник: BacDive. [13]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
978	179	78	maximum	42.0000	°C	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
979	179	79	minimum	5.0000	pH	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
980	179	80	optimal	7.2500	pH	Оптимальный диапазон 7.0-7.5. [13]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
981	179	81	maximum	10.0000	pH	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
982	179	44	single	65.4000	%	Источник: Srinivasan et al. (2010). [12]	high	\N	2025-06-28 07:55:31.590866	2025-06-28 07:55:31.590866
983	695	76	minimum	10.0000	°C	Источник: Cai et al. (2021). [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
984	695	77	optimal	25.0000	°C	Оптимальный диапазон 20-30°C. [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
985	695	78	maximum	45.0000	°C	Источник: Cai et al. (2021). [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
986	695	79	minimum	5.0000	pH	Источник: Cai et al. (2021). [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
987	695	80	optimal	6.5000	pH	Оптимальный диапазон 6.0-7.0. [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
988	695	81	maximum	10.0000	pH	Источник: Cai et al. (2021). [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
989	695	44	single	68.8000	%	Источник: Cai et al. (2021). [1, 2]	high	\N	2025-06-28 07:58:48.567273	2025-06-28 07:58:48.567273
990	696	76	minimum	4.0000	°C	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
991	696	77	optimal	28.0000	°C	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
992	696	78	maximum	32.0000	°C	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
993	696	79	minimum	5.0000	pH	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
994	696	80	optimal	7.0000	pH	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
995	696	81	maximum	9.0000	pH	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
996	696	44	single	64.8000	%	Источник: Siddiqi & Im (2016). [1, 2]	high	\N	2025-06-28 08:00:51.681277	2025-06-28 08:00:51.681277
997	697	76	minimum	4.0000	°C	Извлечено из диапазона 4-37 в OCR.	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
998	697	78	maximum	37.0000	°C	Извлечено из диапазона 4-37 в OCR.	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
999	697	79	minimum	6.0000	pH	Источник: BacDive. [4]	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
1000	697	81	maximum	9.0000	pH	Источник: BacDive. [4]	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
1001	697	44	single	66.5000	%	Источник: Fang et al. (2020). [2]	high	\N	2025-06-28 08:02:14.256398	2025-06-28 08:02:14.256398
1002	698	76	minimum	18.0000	°C	Извлечено из диапазона 18-28 в OCR.	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
1003	698	77	optimal	28.0000	°C	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
1004	698	78	maximum	28.0000	°C	Извлечено из диапазона 18-28 в OCR.	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
1005	698	79	minimum	5.0000	pH	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
1006	698	80	optimal	7.0000	pH	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
1007	698	81	maximum	9.0000	pH	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
1008	698	44	single	66.3000	%	Источник: Du et al. (2015). [1, 2]	high	\N	2025-06-28 08:04:18.217889	2025-06-28 08:04:18.217889
1016	700	76	minimum	10.0000	°C	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
1017	700	77	optimal	28.0000	°C	Оптимальный диапазон 25-30°C. [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
1018	700	78	maximum	30.0000	°C	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
1019	700	79	minimum	6.0000	pH	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
1020	700	80	optimal	7.0000	pH	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
1021	700	81	maximum	8.0000	pH	Источник: Park et al. (2009). [1, 2]	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
1022	700	44	single	71.5000	%	Извлечено из OCR.	high	\N	2025-06-28 08:08:11.075227	2025-06-28 08:08:11.075227
1023	701	76	minimum	10.0000	°C	Извлечено из диапазона 10-40 в OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1024	701	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [1, 2]	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1025	701	78	maximum	40.0000	°C	Извлечено из диапазона 10-40 в OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1026	701	79	minimum	5.0000	pH	Источник: Kim et al. (2018). [1, 2]	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1027	701	80	optimal	6.5000	pH	Оптимальный диапазон 6.0-7.0. [1, 2]	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1028	701	81	maximum	9.0000	pH	Источник: Kim et al. (2018). [1, 2]	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1029	701	44	single	63.0000	%	Извлечено из OCR.	high	\N	2025-06-28 08:10:22.874785	2025-06-28 08:10:22.874785
1009	699	76	minimum	15.0000	°C	Извлечено из диапазона 15-37 в OCR.	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
1010	699	77	optimal	28.0000	°C	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
1011	699	78	maximum	37.0000	°C	Извлечено из диапазона 15-37 в OCR.	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
1012	699	79	minimum	6.0000	pH	Извлечено из диапазона 6.0-9.0 в OCR.	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
1013	699	80	optimal	7.0000	pH	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
1014	699	81	maximum	9.0000	pH	Извлечено из диапазона 6.0-9.0 в OCR.	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
1015	699	44	single	67.1000	%	Источник: Wang et al. (2011). [1, 2]	high	\N	2025-06-28 08:05:41.237309	2025-06-28 08:17:14.808024
1037	703	76	minimum	4.0000	°C	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1038	703	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1039	703	78	maximum	42.0000	°C	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1040	703	79	minimum	5.0000	pH	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1041	703	80	optimal	7.2500	pH	Оптимальный диапазон 7.0-7.5. [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1042	703	81	maximum	10.5000	pH	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1043	703	44	single	65.4000	%	Источник: Srinivasan et al. (2010). [4]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1044	704	76	minimum	10.0000	°C	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1045	704	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1046	704	78	maximum	37.0000	°C	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1047	704	79	minimum	5.0000	pH	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1048	704	80	optimal	7.0000	pH	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1049	704	81	maximum	9.0000	pH	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1050	704	44	single	69.2000	%	Источник: Yassin et al. (2011). [6]	high	\N	2025-06-28 08:17:14.808024	2025-06-28 08:17:14.808024
1051	705	77	optimal	28.0000	°C	Источник: Bae et al. (2005). [1, 2]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1052	705	80	optimal	7.0000	pH	Источник: Bae et al. (2005). [1, 2]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1053	705	44	single	63.8000	%	Источник: Bae et al. (2005). [1, 2]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1056	171	80	optimal	7.0000	pH	Источник: Yassin et al. (2008). [3, 4]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1058	106	77	optimal	26.5000	°C	Оптимальный диапазон 25-28°C. [5, 6]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1060	106	80	optimal	7.0000	pH	Источник: Jung et al. (2012). [5, 6]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1063	708	77	optimal	28.0000	°C	Источник: Aslam et al. (2009). [7, 8]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1064	708	80	optimal	7.0000	pH	Источник: Aslam et al. (2009). [7, 8]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1065	708	44	single	68.0000	%	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1066	709	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1067	709	80	optimal	7.0000	pH	Источник: Park et al. (2008). [9, 10]	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1068	709	44	single	65.4000	%	Извлечено из OCR.	high	\N	2025-06-28 08:22:56.033373	2025-06-28 08:22:56.033373
1069	710	76	minimum	4.0000	°C	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1070	710	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1071	710	78	maximum	37.0000	°C	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1072	710	79	minimum	5.5000	pH	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1073	710	80	optimal	7.2500	pH	Оптимальный диапазон 7.0-7.5. [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1074	710	81	maximum	9.5000	pH	Источник: Romanenko et al. (2018). [1, 2]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1075	710	44	single	69.3000	%	Извлечено из OCR.	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1076	711	76	minimum	10.0000	°C	Источник: Cai et al. (2021). [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1077	711	77	optimal	25.0000	°C	Оптимальный диапазон 20-30°C. [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1078	711	78	maximum	45.0000	°C	Источник: Cai et al. (2021). [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1079	711	79	minimum	5.0000	pH	Источник: Cai et al. (2021). [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1080	711	80	optimal	6.5000	pH	Оптимальный диапазон 6.0-7.0. [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1081	711	81	maximum	10.0000	pH	Источник: Cai et al. (2021). [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1082	711	44	single	68.8000	%	Источник: Cai et al. (2021). [3, 4]	high	\N	2025-06-28 08:27:25.420929	2025-06-28 08:27:25.420929
1083	712	44	single	68.9000	%	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1084	713	76	minimum	15.0000	°C	Источник: Liu et al. (2013). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1085	713	77	optimal	33.5000	°C	Оптимальный диапазон 25-42°C. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1086	713	78	maximum	42.0000	°C	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1087	713	79	minimum	6.0000	pH	Извлечено из диапазона 6-10 в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1088	713	80	optimal	7.0000	pH	Источник: Liu et al. (2013). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1089	713	81	maximum	10.0000	pH	Извлечено из диапазона 6-10 в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1090	713	44	single	70.2000	%	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1091	714	76	minimum	15.0000	°C	Источник: Liu et al. (2013). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1092	714	77	optimal	33.5000	°C	Оптимальный диапазон 25-42°C. [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1093	714	78	maximum	42.0000	°C	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1094	714	79	minimum	6.0000	pH	Извлечено из диапазона 6-11 в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1095	714	80	optimal	7.0000	pH	Источник: Liu et al. (2013). [3, 4]	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1096	714	81	maximum	11.0000	pH	Извлечено из диапазона 6-11 в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1097	714	44	single	70.6000	%	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1103	716	76	minimum	4.0000	°C	Извлечено из диапазона 4-37 в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1104	716	78	maximum	37.0000	°C	Извлечено из диапазона 4-37 в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1105	716	79	minimum	6.0000	pH	Извлечено из диапазона 6.0-10.0 в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1106	716	81	maximum	10.0000	pH	Извлечено из диапазона 6.0-10.0 в OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1107	716	44	single	67.7000	%	Извлечено из OCR.	high	\N	2025-06-28 08:31:30.960414	2025-06-28 08:31:30.960414
1108	717	44	single	69.0000	%	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1109	718	80	optimal	6.8000	pH	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1110	718	44	single	68.1000	%	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1111	719	44	single	69.7000	%	Извлечено из OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1112	720	76	minimum	14.0000	°C	Извлечено из диапазона 14-38 в OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1113	720	77	optimal	21.5000	°C	Оптимальный диапазон 18-25°C. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1114	720	78	maximum	38.0000	°C	Извлечено из диапазона 14-38 в OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1115	720	79	minimum	4.6000	pH	Извлечено из диапазона 4.6-8.3 в OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1116	720	80	optimal	7.3000	pH	Оптимальный диапазон 6.9-7.7. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1117	720	81	maximum	8.3000	pH	Извлечено из диапазона 4.6-8.3 в OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1118	720	44	single	74.4000	%	Извлечено из OCR (74.4±1.5).	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1119	721	76	minimum	11.0000	°C	Извлечено из диапазона 11-40 в OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1120	721	77	optimal	21.0000	°C	Оптимальный диапазон 16-26°C. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1121	721	78	maximum	40.0000	°C	Извлечено из диапазона 11-40 в OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1122	721	79	minimum	4.6000	pH	Извлечено из диапазона 4.6-8.3 в OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1123	721	80	optimal	6.7500	pH	Оптимальный диапазон 6.2-7.3. [7]	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1124	721	81	maximum	8.3000	pH	Извлечено из диапазона 4.6-8.3 в OCR.	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1125	721	44	single	75.7000	%	Извлечено из OCR (75.7±1.5).	high	\N	2025-06-28 08:33:23.64213	2025-06-28 08:33:23.64213
1126	722	76	minimum	10.0000	°C	Извлечено из диапазона 10-42 в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1127	722	77	optimal	30.0000	°C	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1128	722	78	maximum	42.0000	°C	Извлечено из диапазона 10-42 в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1129	722	79	minimum	5.0000	pH	Извлечено из диапазона 5-11 в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1130	722	80	optimal	7.0000	pH	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1131	722	81	maximum	11.0000	pH	Извлечено из диапазона 5-11 в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1132	723	76	minimum	4.0000	°C	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1133	723	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1134	723	78	maximum	37.0000	°C	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1135	723	79	minimum	5.5000	pH	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1136	723	80	optimal	7.2500	pH	Оптимальный диапазон 7.0-7.5. [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1137	723	81	maximum	9.5000	pH	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1138	723	44	single	69.3000	%	Источник: Romanenko et al. (2018). [3]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1139	725	76	minimum	10.0000	°C	Извлечено из диапазона 10-35 в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1140	725	77	optimal	28.0000	°C	Источник: Oh et al. (2011). [5]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1141	725	78	maximum	35.0000	°C	Извлечено из диапазона 10-35 в OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1142	725	80	optimal	7.0000	pH	Источник: Oh et al. (2011). [5]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1143	725	44	single	66.4000	%	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1144	726	76	minimum	10.0000	°C	Источник: Kim et al. (2018). [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1145	726	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1146	726	78	maximum	40.0000	°C	Источник: Kim et al. (2018). [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1147	726	79	minimum	5.0000	pH	Источник: Kim et al. (2018). [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1148	726	80	optimal	6.5000	pH	Оптимальный диапазон 6.0-7.0. [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1149	726	81	maximum	9.0000	pH	Источник: Kim et al. (2018). [7]	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1150	726	44	single	66.4000	%	Извлечено из OCR.	high	\N	2025-06-28 08:39:02.105974	2025-06-28 08:39:02.105974
1151	727	77	optimal	30.0000	°C	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1152	727	80	optimal	8.0000	pH	Извлечено из OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1154	40	80	optimal	7.5000	pH	Извлечено из диапазона 7-8 в OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1155	731	76	minimum	10.0000	°C	Извлечено из диапазона 10-30 в OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1156	731	77	optimal	21.0000	°C	Оптимальный диапазон 15-27°C. [4]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1157	731	78	maximum	30.0000	°C	Извлечено из диапазона 10-30 в OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1158	731	79	minimum	5.4000	pH	Извлечено из диапазона 5.4-7.6 в OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1159	731	80	optimal	6.1000	pH	Оптимальный диапазон 5.6-6.6. [4]	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1160	731	81	maximum	7.6000	pH	Извлечено из диапазона 5.4-7.6 в OCR.	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1161	731	44	single	75.8000	%	Извлечено из OCR (75.8±1.5).	high	\N	2025-06-28 08:41:12.302332	2025-06-28 08:41:12.302332
1162	732	76	minimum	4.0000	°C	Источник: Lee et al. (2005). [1, 2]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1163	732	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [1, 2]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1164	732	78	maximum	37.0000	°C	Источник: Lee et al. (2005). [1, 2]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1165	732	79	minimum	6.0000	pH	Источник: Lee et al. (2005). [1, 2]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1166	732	80	optimal	7.0000	pH	Источник: Lee et al. (2005). [1, 2]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1167	732	81	maximum	8.0000	pH	Источник: Lee et al. (2005). [1, 2]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1168	732	44	single	68.9000	%	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1169	733	76	minimum	10.0000	°C	Извлечено из диапазона 10-37 в OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1170	733	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1171	733	78	maximum	37.0000	°C	Извлечено из диапазона 10-37 в OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1172	733	79	minimum	6.0000	pH	Источник: Siddiqi & Im (2016). [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1173	733	80	optimal	7.0000	pH	Источник: Siddiqi & Im (2016). [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1174	733	81	maximum	9.0000	pH	Источник: Siddiqi & Im (2016). [3, 4]	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1175	733	44	single	67.8000	%	Извлечено из OCR.	high	\N	2025-06-28 08:43:15.469519	2025-06-28 08:43:15.469519
1176	734	77	optimal	28.0000	°C	Источник: Weon et al. (2007). [1]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1177	734	80	optimal	7.0000	pH	Источник: Weon et al. (2007). [1]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1178	734	44	single	67.3000	%	В первоисточнике указано 66.6%. [1]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1179	735	76	minimum	4.0000	°C	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1180	735	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1181	735	78	maximum	37.0000	°C	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1182	735	79	minimum	5.0000	pH	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1183	735	80	optimal	6.5000	pH	Оптимальный диапазон 6.0-7.0. [3]	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1184	735	81	maximum	9.0000	pH	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1185	735	44	single	66.3000	%	Извлечено из OCR.	high	\N	2025-06-28 08:45:38.897799	2025-06-28 08:45:38.897799
1193	738	76	minimum	4.0000	°C	Извлечено из диапазона 4-32 в OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1194	738	77	optimal	28.0000	°C	Извлечено из OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1195	738	78	maximum	32.0000	°C	Извлечено из диапазона 4-32 в OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1196	738	79	minimum	6.5000	pH	Извлечено из диапазона 6.5-7.5 в OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1197	738	80	optimal	7.0000	pH	Извлечено из OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1198	738	81	maximum	7.5000	pH	Извлечено из диапазона 6.5-7.5 в OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1199	738	44	single	67.1000	%	Извлечено из OCR.	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1201	172	77	optimal	25.0000	°C	Источник: Singh et al. (2015). [3, 4]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1203	172	79	minimum	5.0000	pH	Источник: Singh et al. (2015). [3, 4]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1204	172	80	optimal	6.5000	pH	Оптимальный диапазон 6.0-7.0. [3, 4]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1205	172	81	maximum	8.0000	pH	Источник: Singh et al. (2015). [3, 4]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1207	740	76	minimum	4.0000	°C	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1208	740	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1209	740	78	maximum	37.0000	°C	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1210	740	79	minimum	5.5000	pH	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1211	740	80	optimal	7.2500	pH	Оптимальный диапазон 7.0-7.5. [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1212	740	81	maximum	9.5000	pH	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1213	740	44	single	69.3000	%	Источник: Romanenko et al. (2018). [5, 6]	high	\N	2025-06-28 08:49:51.67424	2025-06-28 08:49:51.67424
1214	741	76	minimum	10.0000	°C	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
1215	741	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
1216	741	78	maximum	40.0000	°C	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
1217	741	79	minimum	6.0000	pH	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
1218	741	80	optimal	7.0000	pH	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
1219	741	81	maximum	9.0000	pH	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
1220	741	44	single	63.5000	%	Источник: Wang et al. (2009). [1, 2]	high	\N	2025-06-28 08:51:38.768394	2025-06-28 08:51:38.768394
1221	742	76	minimum	18.0000	°C	Извлечено из диапазона 18-42 в OCR.	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
1222	742	77	optimal	28.0000	°C	Источник: Luo et al. (2011). [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
1223	742	78	maximum	42.0000	°C	Извлечено из диапазона 18-42 в OCR.	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
1224	742	79	minimum	7.0000	pH	Извлечено из диапазона 7-11 в OCR.	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
1225	742	80	optimal	7.5000	pH	Оптимальный диапазон 7.0-8.0. [1]	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
1226	742	81	maximum	11.0000	pH	Извлечено из диапазона 7-11 в OCR.	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
1227	742	44	single	69.7000	%	Извлечено из OCR.	high	\N	2025-06-28 08:53:23.449789	2025-06-28 08:53:23.449789
1228	743	76	minimum	10.0000	°C	Источник: Weon et al. (2006). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1229	743	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1230	743	78	maximum	42.0000	°C	Источник: Weon et al. (2006). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1231	743	79	minimum	5.0000	pH	Источник: Weon et al. (2006). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1232	743	80	optimal	6.5000	pH	Оптимальный диапазон 6.0-7.0. [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1233	743	81	maximum	9.0000	pH	Источник: Weon et al. (2006). [1, 2]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1234	743	44	single	67.3000	%	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1235	744	76	minimum	10.0000	°C	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1236	744	77	optimal	29.0000	°C	Оптимальный диапазон 28-30°C. [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1237	744	78	maximum	37.0000	°C	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1238	744	79	minimum	6.0000	pH	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1239	744	80	optimal	7.0000	pH	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1240	744	81	maximum	8.0000	pH	Источник: Weon et al. (2007). [3, 4]	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
1241	744	44	single	61.7000	%	Извлечено из OCR.	high	\N	2025-06-28 08:55:22.522263	2025-06-28 08:55:22.522263
\.


--
-- Data for Name: test_results_text; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_results_text (result_id, strain_id, test_id, text_value, notes, confidence_level, tested_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_values; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.test_values (value_id, test_id, value_code, value_name, description, sort_order, created_at) FROM stdin;
1	1	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
2	1	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
3	1	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
4	1	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
5	2	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
6	2	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
7	2	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
8	2	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
13	6	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
14	6	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
15	6	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
16	6	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
17	7	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
18	7	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
19	7	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
20	7	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
21	8	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
22	8	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
23	8	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
24	8	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
25	9	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
26	9	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
27	9	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
28	9	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
29	10	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
30	10	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
31	10	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
32	10	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
33	11	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
34	11	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
35	11	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
36	11	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
37	12	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
38	12	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
39	12	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
40	12	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
41	13	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
42	13	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
43	13	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
44	13	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
45	14	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
46	14	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
47	14	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
48	14	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
49	15	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
50	15	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
51	15	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
52	15	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
53	16	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
54	16	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
55	16	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
56	16	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
57	17	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
58	17	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
59	17	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
60	17	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
61	18	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
62	18	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
63	18	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
64	18	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
65	19	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
66	19	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
67	19	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
68	19	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
69	20	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
70	20	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
71	20	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
72	20	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
73	21	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
74	21	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
75	21	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
76	21	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
77	22	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
78	22	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
79	22	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
80	22	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
81	23	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
82	23	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
83	23	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
84	23	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
85	24	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
86	24	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
87	24	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
88	24	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
89	25	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
90	25	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
91	25	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
92	25	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
93	26	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
94	26	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
95	26	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
96	26	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
97	27	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
98	27	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
99	27	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
100	27	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
101	28	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
102	28	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
103	28	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
104	28	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
105	29	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
106	29	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
107	29	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
108	29	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
109	30	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
110	30	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
111	30	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
112	30	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
113	31	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
114	31	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
115	31	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
116	31	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
117	32	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
118	32	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
119	32	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
120	32	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
121	33	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
122	33	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
123	33	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
124	33	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
125	34	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
126	34	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
127	34	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
128	34	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
129	35	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
130	35	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
131	35	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
132	35	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
133	36	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
134	36	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
135	36	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
136	36	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
137	37	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
138	37	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
139	37	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
140	37	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
141	38	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
142	38	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
143	38	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
144	38	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
145	39	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
146	39	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
147	39	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
148	39	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
149	40	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
150	40	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
151	40	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
152	40	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
153	41	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
154	41	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
155	41	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
156	41	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
157	42	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
158	42	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
159	42	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
160	42	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
161	43	+	Positive	Positive result	1	2025-06-26 01:18:03.850216
162	43	-	Negative	Negative result	2	2025-06-26 01:18:03.850216
163	43	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:18:03.850216
164	43	n.d.	No Data	No data available	4	2025-06-26 01:18:03.850216
165	45	+	Positive	Positive result	1	2025-06-26 01:42:20.613838
166	45	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
167	45	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
168	45	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
169	46	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
170	46	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
171	46	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
172	46	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
173	47	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
174	47	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
175	47	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
176	47	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
177	48	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
178	48	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
179	48	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
180	48	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
181	49	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
182	49	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
183	49	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
184	49	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
185	51	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
186	51	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
187	51	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
188	51	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
189	52	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
190	52	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
191	52	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
192	52	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
193	53	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
194	53	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
195	53	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
196	53	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
197	54	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
198	54	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
199	54	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
200	54	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
201	55	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
202	55	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
203	55	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
204	55	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
205	56	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
206	56	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
207	56	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
208	56	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
209	57	+	Positive	Positive result	1	2025-06-26 01:43:15.305562
210	57	-	Negative	Negative result	2	2025-06-26 01:43:15.305562
211	57	+/-	Intermediate	Intermediate/Variable result	3	2025-06-26 01:43:15.305562
212	57	n.d.	No Data	No data available	4	2025-06-26 01:43:15.305562
214	58	+	Positive	Positive result	1	2025-06-26 02:04:50.109458
215	58	-	Negative	Negative result	2	2025-06-26 02:05:02.097223
216	58	+/-	Intermediate	Intermediate result	3	2025-06-26 02:05:13.052107
217	58	n.d.	No Data	No data available	4	2025-06-26 02:05:25.423318
218	60	+	Positive	Positive result	1	2025-06-26 02:08:31.853531
219	60	-	Negative	Negative result	2	2025-06-26 02:08:31.853531
220	60	+/-	Intermediate	Intermediate result	3	2025-06-26 02:08:31.853531
221	60	n.d.	No Data	No data available	4	2025-06-26 02:08:31.853531
228	62	+	Positive	Positive result	1	2025-06-26 02:44:58.911492
229	63	+	Positive	Positive result	1	2025-06-26 02:44:58.911492
230	64	+	Positive	Positive result	1	2025-06-26 02:44:58.911492
231	65	+	Positive	Positive result	1	2025-06-26 02:44:58.911492
232	66	+	Positive	Positive result	1	2025-06-26 02:44:58.911492
233	67	+	Positive	Positive result	1	2025-06-26 02:44:58.911492
234	62	-	Negative	Negative result	2	2025-06-26 02:44:58.911492
235	63	-	Negative	Negative result	2	2025-06-26 02:44:58.911492
236	64	-	Negative	Negative result	2	2025-06-26 02:44:58.911492
237	65	-	Negative	Negative result	2	2025-06-26 02:44:58.911492
238	66	-	Negative	Negative result	2	2025-06-26 02:44:58.911492
239	67	-	Negative	Negative result	2	2025-06-26 02:44:58.911492
240	62	+/-	Intermediate	Intermediate result	3	2025-06-26 02:44:58.911492
241	63	+/-	Intermediate	Intermediate result	3	2025-06-26 02:44:58.911492
242	64	+/-	Intermediate	Intermediate result	3	2025-06-26 02:44:58.911492
243	65	+/-	Intermediate	Intermediate result	3	2025-06-26 02:44:58.911492
244	66	+/-	Intermediate	Intermediate result	3	2025-06-26 02:44:58.911492
245	67	+/-	Intermediate	Intermediate result	3	2025-06-26 02:44:58.911492
246	62	n.d.	No Data	No data	4	2025-06-26 02:44:58.911492
247	63	n.d.	No Data	No data	4	2025-06-26 02:44:58.911492
248	64	n.d.	No Data	No data	4	2025-06-26 02:44:58.911492
249	65	n.d.	No Data	No data	4	2025-06-26 02:44:58.911492
250	66	n.d.	No Data	No data	4	2025-06-26 02:44:58.911492
251	67	n.d.	No Data	No data	4	2025-06-26 02:44:58.911492
252	68	+	Positive	Positive result	1	2025-06-26 02:51:06.481098
253	69	+	Positive	Positive result	1	2025-06-26 02:51:06.481098
254	68	-	Negative	Negative result	2	2025-06-26 02:51:06.481098
255	69	-	Negative	Negative result	2	2025-06-26 02:51:06.481098
256	68	+/-	Intermediate	Intermediate result	3	2025-06-26 02:51:06.481098
257	69	+/-	Intermediate	Intermediate result	3	2025-06-26 02:51:06.481098
258	68	n.d.	No Data	No data	4	2025-06-26 02:51:06.481098
259	69	n.d.	No Data	No data	4	2025-06-26 02:51:06.481098
260	70	+	Positive	Positive result	1	2025-06-26 03:04:22.409002
261	72	+	Positive	Positive result	1	2025-06-26 03:04:22.409002
262	70	-	Negative	Negative result	2	2025-06-26 03:04:22.409002
263	72	-	Negative	Negative result	2	2025-06-26 03:04:22.409002
264	70	+/-	Intermediate	Intermediate result	3	2025-06-26 03:04:22.409002
265	72	+/-	Intermediate	Intermediate result	3	2025-06-26 03:04:22.409002
266	70	n.d.	No Data	No data	4	2025-06-26 03:04:22.409002
267	72	n.d.	No Data	No data	4	2025-06-26 03:04:22.409002
268	5	+	Positive	\N	1	2025-06-27 09:52:34.91856
269	5	-	Negative	\N	2	2025-06-27 09:52:34.91856
270	5	+/-	Intermediate	\N	3	2025-06-27 09:52:34.91856
271	5	n.d.	No Data	\N	4	2025-06-27 09:52:34.91856
\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: lysobacter; Owner: lysobacter_user
--

COPY lysobacter.tests (test_id, category_id, test_name, test_code, test_type, description, measurement_unit, is_active, sort_order, created_at) FROM stdin;
5	2	Солеустойчивость	salt_tolerance	boolean	Солеустойчивость	\N	t	3	2025-06-26 01:18:03.834738
6	3	Протеолитическая активность	proteolytic_activity	boolean	Протеолитическая активность	\N	t	1	2025-06-26 01:18:03.837221
7	3	Оксидаза	oxidase	boolean	Оксидаза	\N	t	2	2025-06-26 01:18:03.837221
9	3	Уреаза	urease	boolean	Уреаза	\N	t	4	2025-06-26 01:18:03.837221
10	3	Восстановление нитрата	nitrate_reduction	boolean	Восстановление нитрата	\N	t	5	2025-06-26 01:18:03.837221
11	3	Продукция индола	indole_production	boolean	Продукция индола	\N	t	6	2025-06-26 01:18:03.837221
12	3	Фосфатаза	phosphatase	boolean	Фосфатаза	\N	t	7	2025-06-26 01:18:03.837221
13	3	Эстераза	esterase	boolean	Эстераза	\N	t	8	2025-06-26 01:18:03.837221
16	4	Расщепление крахмала	starch	boolean	Расщепление крахмала	\N	t	1	2025-06-26 01:18:03.841146
17	4	Эскулин	aesculin	boolean	Эскулин	\N	t	2	2025-06-26 01:18:03.841146
18	4	Желатин	gelatin	boolean	Желатин	\N	t	3	2025-06-26 01:18:03.841146
19	4	Казеин	casein	boolean	Казеин	\N	t	4	2025-06-26 01:18:03.841146
20	4	Tween 20	tween_20	boolean	Tween 20	\N	t	5	2025-06-26 01:18:03.841146
21	4	Tween 40	tween_40	boolean	Tween 40	\N	t	6	2025-06-26 01:18:03.841146
22	4	Tween 60	tween_60	boolean	Tween 60	\N	t	7	2025-06-26 01:18:03.841146
23	4	Хитин	chitin	boolean	Хитин	\N	t	8	2025-06-26 01:18:03.841146
24	4	Целлюлоза	cellulose	boolean	Целлюлоза	\N	t	9	2025-06-26 01:18:03.841146
25	4	Аргинин-гидролаза	arginine_hydrolase	boolean	Аргинин-гидролаза	\N	t	10	2025-06-26 01:18:03.841146
26	4	Пектин	pectin	boolean	Пектин	\N	t	11	2025-06-26 01:18:03.841146
27	4	Ферментация глюкозы	glucose_fermentation	boolean	Ферментация глюкозы	\N	t	12	2025-06-26 01:18:03.841146
28	5	Мальтоза	maltose	boolean	Мальтоза	\N	t	1	2025-06-26 01:18:03.844786
29	5	Лактоза	lactose	boolean	Лактоза	\N	t	2	2025-06-26 01:18:03.844786
30	5	Фруктоза	fructose	boolean	Фруктоза	\N	t	3	2025-06-26 01:18:03.844786
31	5	Арабиноза	arabinose	boolean	Арабиноза	\N	t	4	2025-06-26 01:18:03.844786
32	5	Манноза	mannose	boolean	Манноза	\N	t	5	2025-06-26 01:18:03.844786
33	5	Трегалоза	trehalose	boolean	Трегалоза	\N	t	6	2025-06-26 01:18:03.844786
34	5	Сорбит	sorbitol	boolean	Сорбит	\N	t	7	2025-06-26 01:18:03.844786
35	5	Маннит	mannitol	boolean	Маннит	\N	t	8	2025-06-26 01:18:03.844786
36	5	Декстроза	dextrose	boolean	Декстроза	\N	t	9	2025-06-26 01:18:03.844786
37	5	Ксиллоза	xylose	boolean	Ксиллоза	\N	t	10	2025-06-26 01:18:03.844786
38	5	Галактоза	galactose	boolean	Галактоза	\N	t	11	2025-06-26 01:18:03.844786
39	5	Дульцитол	dulcitol	boolean	Дульцитол	\N	t	12	2025-06-26 01:18:03.844786
40	5	Целлобиоза	cellobiose	boolean	Целлобиоза	\N	t	13	2025-06-26 01:18:03.844786
41	5	Сахароза	sucrose	boolean	Сахароза	\N	t	14	2025-06-26 01:18:03.844786
42	5	Раффиноза	raffinose	boolean	Раффиноза	\N	t	15	2025-06-26 01:18:03.844786
43	5	Инозитол	inositol	boolean	Инозитол	\N	t	16	2025-06-26 01:18:03.844786
14	14	Целлюлазная активность	cellulase_activity	boolean	Целлюлазная активность	\N	t	9	2025-06-26 01:18:03.837221
15	14	Солюбилизация фосфатов	phosphate_solubilization	boolean	Солюбилизация фосфатов	\N	t	10	2025-06-26 01:18:03.837221
44	14	GC-состав	gc_content	numeric	GC-состав	%	t	1	2025-06-26 01:18:03.848476
45	3	Cysteine Arylamidase	cysteine_arylamidase	boolean	Cysteine arylamidase enzyme activity	\N	f	11	2025-06-26 01:42:11.441169
46	3	Trypsin	trypsin	boolean	Trypsin enzyme activity	\N	f	12	2025-06-26 01:43:15.305562
47	3	Chymotrypsin	chymotrypsin	boolean	Chymotrypsin enzyme activity	\N	f	13	2025-06-26 01:43:15.305562
48	5	Citrate Utilization	citrate_utilization	boolean	Ability to utilize citrate	\N	f	17	2025-06-26 01:43:15.305562
49	4	Tween 80 Breakdown	tween_80	boolean	Ability to break down Tween 80	\N	f	13	2025-06-26 01:43:15.305562
51	2	Growth at pH 9.5	ph_growth_9.5	boolean	Growth at pH 9.5	\N	f	4	2025-06-26 01:43:15.305562
52	2	Growth at pH 10	ph_growth_10	boolean	Growth at pH 10	\N	f	5	2025-06-26 01:43:15.305562
53	2	Growth at pH 11	ph_growth_11	boolean	Growth at pH 11	\N	f	6	2025-06-26 01:43:15.305562
3	2	Temperature	temperature	numeric	Growth temperature range	°C	f	1	2025-06-26 01:18:03.831533
4	2	pH Level	ph_level	numeric	pH range for growth	pH	f	2	2025-06-26 01:18:03.833123
50	14	Genome Size	genome_size	numeric	Genome size (Mb)	Mb	f	2	2025-06-26 01:43:15.305562
1	1	Спорообразование	spore_formation	boolean	Спорообразование	\N	t	1	2025-06-26 01:18:03.826907
2	1	Подвижность	motility	boolean	Подвижность	\N	t	2	2025-06-26 01:18:03.826907
76	2	Температура (мин)	temperature_min	numeric	Температура (мин)	°C	t	0	2025-06-27 09:22:49.359803
77	2	Температура (опт)	temperature_opt	numeric	Температура (опт)	°C	t	0	2025-06-27 09:22:49.359803
78	2	Температура (макс)	temperature_max	numeric	Температура (макс)	°C	t	0	2025-06-27 09:22:49.359803
79	2	pH (мин)	ph_min	numeric	pH (мин)	\N	t	0	2025-06-27 09:22:49.359803
80	2	pH (опт)	ph_opt	numeric	pH (опт)	\N	t	0	2025-06-27 09:22:49.359803
81	2	pH (макс)	ph_max	numeric	pH (макс)	\N	t	0	2025-06-27 09:22:49.359803
8	3	Каталаза	catalase	boolean	Каталаза	\N	t	3	2025-06-26 01:18:03.837221
54	2	Growth at 37°C	temp_growth_37	boolean	Growth at 37°C	\N	f	7	2025-06-26 01:43:15.305562
55	2	Growth at 42°C	temp_growth_42	boolean	Growth at 42°C	\N	f	8	2025-06-26 01:43:15.305562
56	5	Glucose Assimilation	glucose_assimilation	boolean	Assimilation of glucose	\N	f	18	2025-06-26 01:43:15.305562
57	5	Mannose Assimilation	mannose_assimilation	boolean	Assimilation of mannose	\N	f	19	2025-06-26 01:43:15.305562
58	4	Acid Production (Oxidative OF Test)	acid_production_oxidative	boolean	Oxidative acid production in OF test	\N	f	14	2025-06-26 02:04:12.258436
59	1	Cell Size	cell_size	text	Cell size (length x width)	μm	f	3	2025-06-26 02:04:24.297166
60	4	Acid Production from Glycerol	glycerol	boolean	Acid production from glycerol substrate	\N	f	15	2025-06-26 02:08:14.866174
61	1	Colony Color	colony_color	text	Colony color description	\N	f	4	2025-06-26 02:43:44.634201
62	3	Alpha-glucosidase	alpha_glucosidase	boolean	Alpha-glucosidase enzyme activity	\N	f	14	2025-06-26 02:43:44.634201
63	3	Beta-glucosidase	beta_glucosidase	boolean	Beta-glucosidase enzyme activity	\N	f	15	2025-06-26 02:43:44.634201
64	3	Galactosidase	galactosidase	boolean	Galactosidase enzyme activity	\N	f	16	2025-06-26 02:43:44.634201
65	3	N-acetyl-beta-glucosaminidase	n_acetyl_beta_glucosaminidase	boolean	N-acetyl-beta-glucosaminidase activity	\N	f	17	2025-06-26 02:43:44.634201
66	3	Leucine arylamidase	leucine_arylamidase	boolean	Leucine arylamidase activity	\N	f	18	2025-06-26 02:43:44.634201
67	3	Valine arylamidase	valine_arylamidase	boolean	Valine arylamidase activity	\N	f	19	2025-06-26 02:43:44.634201
68	3	Lipase (C14)	lipase_c14	boolean	Lipase C14 activity	\N	f	20	2025-06-26 02:50:46.646217
69	5	N-Acetylglucosamine Assimilation	n_acetyl_glucosamine	boolean	Assimilation of N-acetylglucosamine	\N	f	30	2025-06-26 02:50:46.646217
70	3	Beta-galactosidase	beta_galactosidase	boolean	β-galactosidase enzyme activity	\N	f	21	2025-06-26 03:04:09.844891
72	4	Tyrosine hydrolysis	tyrosine_hydrolysis	boolean	Hydrolysis of tyrosine	\N	f	25	2025-06-26 03:04:09.844891
71	14	Ubiquinone type	ubiquinone_type	text	Major ubiquinone type	\N	f	5	2025-06-26 03:04:09.844891
\.


--
-- Name: audit_log_log_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.audit_log_log_id_seq', 1, false);


--
-- Name: collection_numbers_collection_number_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.collection_numbers_collection_number_id_seq', 66, true);


--
-- Name: data_sources_source_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.data_sources_source_id_seq', 1, false);


--
-- Name: species_species_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.species_species_id_seq', 63, true);


--
-- Name: strains_strain_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.strains_strain_id_seq', 745, true);


--
-- Name: test_categories_category_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_categories_category_id_seq', 24, true);


--
-- Name: test_results_boolean_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_boolean_result_id_seq', 4196, true);


--
-- Name: test_results_numeric_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_numeric_result_id_seq', 1247, true);


--
-- Name: test_results_text_result_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_results_text_result_id_seq', 38, true);


--
-- Name: test_values_value_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.test_values_value_id_seq', 431, true);


--
-- Name: tests_test_id_seq; Type: SEQUENCE SET; Schema: lysobacter; Owner: lysobacter_user
--

SELECT pg_catalog.setval('lysobacter.tests_test_id_seq', 169, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (log_id);


--
-- Name: collection_numbers collection_numbers_collection_code_collection_number_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.collection_numbers
    ADD CONSTRAINT collection_numbers_collection_code_collection_number_key UNIQUE (collection_code, collection_number);


--
-- Name: collection_numbers collection_numbers_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.collection_numbers
    ADD CONSTRAINT collection_numbers_pkey PRIMARY KEY (collection_number_id);


--
-- Name: data_sources data_sources_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.data_sources
    ADD CONSTRAINT data_sources_pkey PRIMARY KEY (source_id);


--
-- Name: species species_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.species
    ADD CONSTRAINT species_pkey PRIMARY KEY (species_id);


--
-- Name: species species_scientific_name_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.species
    ADD CONSTRAINT species_scientific_name_key UNIQUE (scientific_name);


--
-- Name: strain_collections strain_collections_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strain_collections
    ADD CONSTRAINT strain_collections_pkey PRIMARY KEY (strain_id, collection_number_id);


--
-- Name: strains strains_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains
    ADD CONSTRAINT strains_pkey PRIMARY KEY (strain_id);


--
-- Name: strains strains_strain_identifier_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains
    ADD CONSTRAINT strains_strain_identifier_key UNIQUE (strain_identifier);


--
-- Name: test_categories test_categories_category_name_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_categories
    ADD CONSTRAINT test_categories_category_name_key UNIQUE (category_name);


--
-- Name: test_categories test_categories_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_categories
    ADD CONSTRAINT test_categories_pkey PRIMARY KEY (category_id);


--
-- Name: test_results_boolean test_results_boolean_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_pkey PRIMARY KEY (result_id);


--
-- Name: test_results_boolean test_results_boolean_strain_id_test_id_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_strain_id_test_id_key UNIQUE (strain_id, test_id);


--
-- Name: test_results_numeric test_results_numeric_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric
    ADD CONSTRAINT test_results_numeric_pkey PRIMARY KEY (result_id);


--
-- Name: test_results_numeric test_results_numeric_strain_id_test_id_value_type_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric
    ADD CONSTRAINT test_results_numeric_strain_id_test_id_value_type_key UNIQUE (strain_id, test_id, value_type);


--
-- Name: test_results_text test_results_text_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text
    ADD CONSTRAINT test_results_text_pkey PRIMARY KEY (result_id);


--
-- Name: test_results_text test_results_text_strain_id_test_id_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text
    ADD CONSTRAINT test_results_text_strain_id_test_id_key UNIQUE (strain_id, test_id);


--
-- Name: test_values test_values_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_values
    ADD CONSTRAINT test_values_pkey PRIMARY KEY (value_id);


--
-- Name: test_values test_values_test_id_value_code_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_values
    ADD CONSTRAINT test_values_test_id_value_code_key UNIQUE (test_id, value_code);


--
-- Name: tests tests_category_id_test_name_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests
    ADD CONSTRAINT tests_category_id_test_name_key UNIQUE (category_id, test_name);


--
-- Name: tests tests_pkey; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (test_id);


--
-- Name: tests tests_test_code_key; Type: CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests
    ADD CONSTRAINT tests_test_code_key UNIQUE (test_code);


--
-- Name: idx_results_boolean_strain; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_boolean_strain ON lysobacter.test_results_boolean USING btree (strain_id);


--
-- Name: idx_results_boolean_test; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_boolean_test ON lysobacter.test_results_boolean USING btree (test_id);


--
-- Name: idx_results_numeric_strain; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_numeric_strain ON lysobacter.test_results_numeric USING btree (strain_id);


--
-- Name: idx_results_numeric_test; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_numeric_test ON lysobacter.test_results_numeric USING btree (test_id);


--
-- Name: idx_results_text_strain; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_results_text_strain ON lysobacter.test_results_text USING btree (strain_id);


--
-- Name: idx_strains_active; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_active ON lysobacter.strains USING btree (is_active);


--
-- Name: idx_strains_identifier; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_identifier ON lysobacter.strains USING btree (strain_identifier);


--
-- Name: idx_strains_is_duplicate; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_is_duplicate ON lysobacter.strains USING btree (is_duplicate);


--
-- Name: idx_strains_master_strain_id; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_master_strain_id ON lysobacter.strains USING btree (master_strain_id);


--
-- Name: idx_strains_source; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_source ON lysobacter.strains USING btree (source_id);


--
-- Name: idx_strains_species; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_species ON lysobacter.strains USING btree (species_id);


--
-- Name: idx_strains_text_search; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_strains_text_search ON lysobacter.strains USING gin (to_tsvector('english'::regconfig, (((((COALESCE(strain_identifier, ''::character varying))::text || ' '::text) || (COALESCE(scientific_name, ''::character varying))::text) || ' '::text) || COALESCE(description, ''::text))));


--
-- Name: idx_tests_active; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_tests_active ON lysobacter.tests USING btree (is_active);


--
-- Name: idx_tests_category; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_tests_category ON lysobacter.tests USING btree (category_id);


--
-- Name: idx_tests_type; Type: INDEX; Schema: lysobacter; Owner: lysobacter_user
--

CREATE INDEX idx_tests_type ON lysobacter.tests USING btree (test_type);


--
-- Name: v_strains_complete _RETURN; Type: RULE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE OR REPLACE VIEW lysobacter.v_strains_complete AS
 SELECT s.strain_id,
    s.strain_identifier,
    s.scientific_name,
    s.common_name,
    s.description,
    s.isolation_source,
    s.isolation_location,
    s.isolation_date,
    ds.source_name,
    ds.source_type,
    s.gc_content_min,
    s.gc_content_max,
    s.gc_content_optimal,
    s.notes,
    s.is_active,
    s.created_at,
    s.updated_at,
    array_agg(
        CASE
            WHEN (cn.collection_code IS NOT NULL) THEN (((cn.collection_code)::text || ' '::text) || (cn.collection_number)::text)
            ELSE NULL::text
        END) FILTER (WHERE (cn.collection_code IS NOT NULL)) AS collection_numbers
   FROM (((lysobacter.strains s
     LEFT JOIN lysobacter.data_sources ds ON ((s.source_id = ds.source_id)))
     LEFT JOIN lysobacter.strain_collections sc ON ((s.strain_id = sc.strain_id)))
     LEFT JOIN lysobacter.collection_numbers cn ON ((sc.collection_number_id = cn.collection_number_id)))
  GROUP BY s.strain_id, ds.source_name, ds.source_type;


--
-- Name: v_category_statistics _RETURN; Type: RULE; Schema: lysobacter; Owner: lysobacter_user
--

CREATE OR REPLACE VIEW lysobacter.v_category_statistics AS
 SELECT tc.category_name,
    tc.description,
    count(t.test_id) AS total_tests,
    count(
        CASE
            WHEN (t.is_active = true) THEN 1
            ELSE NULL::integer
        END) AS active_tests,
    ((count(DISTINCT trb.strain_id) + count(DISTINCT trn.strain_id)) + count(DISTINCT trt.strain_id)) AS strains_with_data
   FROM ((((lysobacter.test_categories tc
     LEFT JOIN lysobacter.tests t ON ((tc.category_id = t.category_id)))
     LEFT JOIN lysobacter.test_results_boolean trb ON ((t.test_id = trb.test_id)))
     LEFT JOIN lysobacter.test_results_numeric trn ON ((t.test_id = trn.test_id)))
     LEFT JOIN lysobacter.test_results_text trt ON ((t.test_id = trt.test_id)))
  GROUP BY tc.category_id, tc.category_name, tc.description
  ORDER BY tc.sort_order;


--
-- Name: test_results_boolean update_results_boolean_updated_at; Type: TRIGGER; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TRIGGER update_results_boolean_updated_at BEFORE UPDATE ON lysobacter.test_results_boolean FOR EACH ROW EXECUTE FUNCTION lysobacter.update_updated_at_column();


--
-- Name: test_results_numeric update_results_numeric_updated_at; Type: TRIGGER; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TRIGGER update_results_numeric_updated_at BEFORE UPDATE ON lysobacter.test_results_numeric FOR EACH ROW EXECUTE FUNCTION lysobacter.update_updated_at_column();


--
-- Name: strains update_strains_updated_at; Type: TRIGGER; Schema: lysobacter; Owner: lysobacter_user
--

CREATE TRIGGER update_strains_updated_at BEFORE UPDATE ON lysobacter.strains FOR EACH ROW EXECUTE FUNCTION lysobacter.update_updated_at_column();


--
-- Name: strain_collections strain_collections_collection_number_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strain_collections
    ADD CONSTRAINT strain_collections_collection_number_id_fkey FOREIGN KEY (collection_number_id) REFERENCES lysobacter.collection_numbers(collection_number_id);


--
-- Name: strain_collections strain_collections_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strain_collections
    ADD CONSTRAINT strain_collections_strain_id_fkey FOREIGN KEY (strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE CASCADE;


--
-- Name: strains strains_master_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains
    ADD CONSTRAINT strains_master_strain_id_fkey FOREIGN KEY (master_strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE SET NULL;


--
-- Name: strains strains_source_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains
    ADD CONSTRAINT strains_source_id_fkey FOREIGN KEY (source_id) REFERENCES lysobacter.data_sources(source_id);


--
-- Name: strains strains_species_fk; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.strains
    ADD CONSTRAINT strains_species_fk FOREIGN KEY (species_id) REFERENCES lysobacter.species(species_id);


--
-- Name: test_results_boolean test_results_boolean_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_strain_id_fkey FOREIGN KEY (strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE CASCADE;


--
-- Name: test_results_boolean test_results_boolean_test_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_test_id_fkey FOREIGN KEY (test_id) REFERENCES lysobacter.tests(test_id);


--
-- Name: test_results_boolean test_results_boolean_value_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_boolean
    ADD CONSTRAINT test_results_boolean_value_id_fkey FOREIGN KEY (value_id) REFERENCES lysobacter.test_values(value_id);


--
-- Name: test_results_numeric test_results_numeric_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric
    ADD CONSTRAINT test_results_numeric_strain_id_fkey FOREIGN KEY (strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE CASCADE;


--
-- Name: test_results_numeric test_results_numeric_test_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_numeric
    ADD CONSTRAINT test_results_numeric_test_id_fkey FOREIGN KEY (test_id) REFERENCES lysobacter.tests(test_id);


--
-- Name: test_results_text test_results_text_strain_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text
    ADD CONSTRAINT test_results_text_strain_id_fkey FOREIGN KEY (strain_id) REFERENCES lysobacter.strains(strain_id) ON DELETE CASCADE;


--
-- Name: test_results_text test_results_text_test_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_results_text
    ADD CONSTRAINT test_results_text_test_id_fkey FOREIGN KEY (test_id) REFERENCES lysobacter.tests(test_id);


--
-- Name: test_values test_values_test_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.test_values
    ADD CONSTRAINT test_values_test_id_fkey FOREIGN KEY (test_id) REFERENCES lysobacter.tests(test_id) ON DELETE CASCADE;


--
-- Name: tests tests_category_id_fkey; Type: FK CONSTRAINT; Schema: lysobacter; Owner: lysobacter_user
--

ALTER TABLE ONLY lysobacter.tests
    ADD CONSTRAINT tests_category_id_fkey FOREIGN KEY (category_id) REFERENCES lysobacter.test_categories(category_id);


--
-- PostgreSQL database dump complete
--

